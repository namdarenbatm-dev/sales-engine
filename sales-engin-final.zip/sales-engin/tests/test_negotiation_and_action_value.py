from decimal import Decimal

import pytest

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.action_value import ActionValueInput, calculate_action_value
from app.domain.analytics.formulas.negotiation import (
    NegotiationOptionInput,
    calculate_negotiation_option_impact,
)


class TestNegotiationOption:
    def test_normal_case(self):
        r = calculate_negotiation_option_impact(
            NegotiationOptionInput(
                currency="IRR", baseline_unit_price=Decimal("1000"), baseline_volume=Decimal("100"),
                variable_cost_per_unit=Decimal("600"), concession_price_reduction_per_unit=Decimal("50"),
                counterpart_volume_increase_units=Decimal("30"),
                counterpart_payment_days_reduction=Decimal("10"),
                daily_financing_rate=Decimal("0.0005"),
            )
        )
        assert r.baseline_margin_total == Decimal("40000.00")
        assert r.new_margin_total == Decimal("45500.00")
        assert r.margin_impact == Decimal("5500.00")
        assert r.cash_flow_benefit == Decimal("500.00")
        assert r.net_economic_effect == Decimal("6000.00")

    def test_concession_larger_than_price_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_negotiation_option_impact(
                NegotiationOptionInput(
                    currency="IRR", baseline_unit_price=Decimal("100"), baseline_volume=Decimal("10"),
                    variable_cost_per_unit=Decimal("50"),
                    concession_price_reduction_per_unit=Decimal("200"),
                )
            )

    def test_zero_baseline_volume_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_negotiation_option_impact(
                NegotiationOptionInput(
                    currency="IRR", baseline_unit_price=Decimal("100"), baseline_volume=Decimal("0"),
                    variable_cost_per_unit=Decimal("50"),
                    concession_price_reduction_per_unit=Decimal("10"),
                )
            )

    def test_no_counterpart_commitment_still_computes(self):
        r = calculate_negotiation_option_impact(
            NegotiationOptionInput(
                currency="IRR", baseline_unit_price=Decimal("1000"), baseline_volume=Decimal("100"),
                variable_cost_per_unit=Decimal("600"), concession_price_reduction_per_unit=Decimal("50"),
            )
        )
        # بدون تعهد جبرانی، اثر باید منفی باشد (فقط تخفیف بدون جبران)
        assert r.margin_impact == Decimal("-5000.00")
        assert r.cash_flow_benefit == Decimal("0.00")


class TestActionValue:
    def test_normal_case(self):
        r = calculate_action_value(
            ActionValueInput(
                currency="IRR", expected_economic_impact=Decimal("500000"),
                action_cost=Decimal("50000"), risk_cost=Decimal("20000"),
            )
        )
        assert r.action_value == Decimal("430000.00")

    def test_no_action_option_yields_zero_when_all_zero(self):
        r = calculate_action_value(
            ActionValueInput(
                currency="IRR", expected_economic_impact=Decimal("0"),
                action_cost=Decimal("0"), risk_cost=Decimal("0"),
            )
        )
        assert r.action_value == Decimal("0.00")

    def test_negative_action_cost_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_action_value(
                ActionValueInput(
                    currency="IRR", expected_economic_impact=Decimal("100"),
                    action_cost=Decimal("-1"), risk_cost=Decimal("0"),
                )
            )

    def test_negative_value_is_shown_not_hidden(self):
        # اقدام می‌تواند ارزش منفی داشته باشد — نباید پنهان یا صفر نمایش داده شود
        r = calculate_action_value(
            ActionValueInput(
                currency="IRR", expected_economic_impact=Decimal("100"),
                action_cost=Decimal("300"), risk_cost=Decimal("50"),
            )
        )
        assert r.action_value == Decimal("-250.00")
