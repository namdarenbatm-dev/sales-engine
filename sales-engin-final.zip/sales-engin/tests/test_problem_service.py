from app.domain.problem.schemas import ProblemCreateSchema
from app.domain.problem.service import create_problem


class FakeSession:
    def __init__(self):
        self.added = []

    def add(self, obj):
        self.added.append(obj)

    def flush(self):
        pass


def test_create_problem_stamps_tenant_and_logs_audit_event():
    session = FakeSession()
    payload = ProblemCreateSchema(
        business_area_fa="قیمت‌گذاری کانال",
        observed_symptom_fa="ریزش حاشیه سود در نمایندگی‌های استان X",
        target_outcome_fa="بازگرداندن حاشیه سود مشارکت به بالای ۲۰٪",
    )
    problem = create_problem(session, tenant_id="tenant-1", payload=payload)

    assert problem.tenant_id == "tenant-1"
    assert problem.status_fa == "باز"
    # هم رکورد مسئله و هم رویداد ممیزی باید add شده باشند
    assert len(session.added) == 2
    audit_event = session.added[1]
    assert audit_event.event_type == "PROBLEM_CREATED"
    assert audit_event.tenant_id == "tenant-1"
