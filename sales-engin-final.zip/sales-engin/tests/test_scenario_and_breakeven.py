from decimal import Decimal

import pytest

from app.domain.analytics.engine import PricingCoreRequest
from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.breakeven import BreakevenInput, calculate_breakeven_units
from app.domain.analytics.scenario import (
    ScenarioDefinition,
    run_pricing_scenarios,
    run_sensitivity_analysis,
)


def _base_request(**overrides) -> PricingCoreRequest:
    defaults = dict(
        tenant_id="tenant-1", currency="IRR", nominal_unit_price=Decimal("1000"),
        paid_units=Decimal("100"), total_discounts=Decimal("0"), total_rebates=Decimal("0"),
        foc_units=Decimal("0"), variable_cost_per_unit=Decimal("600"),
        minimum_required_margin_pct=Decimal("0.25"), proposed_price=None,
    )
    defaults.update(overrides)
    return PricingCoreRequest(**defaults)


class TestBreakeven:
    def test_normal_case(self):
        r = calculate_breakeven_units(
            BreakevenInput(fixed_cost=Decimal("1000000"), contribution_margin_per_unit=Decimal("300"))
        )
        assert r.breakeven_units == Decimal("3334")  # rounded up

    def test_zero_margin_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_breakeven_units(
                BreakevenInput(fixed_cost=Decimal("1000000"), contribution_margin_per_unit=Decimal("0"))
            )

    def test_negative_fixed_cost_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_breakeven_units(
                BreakevenInput(fixed_cost=Decimal("-1"), contribution_margin_per_unit=Decimal("100"))
            )


class TestScenarioEngine:
    def test_base_scenario_always_included(self):
        outcomes = run_pricing_scenarios(_base_request(), [])
        assert len(outcomes) == 1
        assert outcomes[0].scenario_type == "BASE"

    def test_downside_scenario_reduces_margin(self):
        outcomes = run_pricing_scenarios(
            _base_request(),
            [
                ScenarioDefinition(
                    name_fa="بدبینانه", scenario_type="DOWNSIDE",
                    multipliers={"variable_cost_per_unit": Decimal("1.1")},
                )
            ],
        )
        base_margin = outcomes[0].result.contribution_margin_per_unit
        downside_margin = outcomes[1].result.contribution_margin_per_unit
        assert downside_margin < base_margin

    def test_invalid_field_in_multiplier_raises(self):
        with pytest.raises(ValueError):
            run_pricing_scenarios(
                _base_request(),
                [
                    ScenarioDefinition(
                        name_fa="نامعتبر", scenario_type="CUSTOM",
                        multipliers={"not_a_real_field": Decimal("1.1")},
                    )
                ],
            )

    def test_sensitivity_analysis_varies_effective_price(self):
        results = run_sensitivity_analysis(
            _base_request(), "nominal_unit_price", [Decimal("900"), Decimal("1100")]
        )
        assert results[0][1].effective_unit_price == Decimal("900.00")
        assert results[1][1].effective_unit_price == Decimal("1100.00")

    def test_sensitivity_invalid_field_raises(self):
        with pytest.raises(ValueError):
            run_sensitivity_analysis(_base_request(), "tenant_id", [Decimal("1")])
