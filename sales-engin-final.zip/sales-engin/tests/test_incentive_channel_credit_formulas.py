from decimal import Decimal

import pytest

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.channel import (
    ChannelConflictInput,
    ChannelMarginInput,
    calculate_channel_margin,
    detect_channel_conflict,
)
from app.domain.analytics.formulas.credit import (
    CreditEconomicsInput,
    calculate_credit_adjusted_margin,
)
from app.domain.analytics.formulas.incentives import (
    FocEquivalentInput,
    RebateEquivalentInput,
    calculate_foc_equivalent_unit_cost,
    calculate_rebate_equivalent_price,
)


class TestRebateEquivalent:
    def test_normal_case(self):
        r = calculate_rebate_equivalent_price(
            RebateEquivalentInput(
                currency="IRR", nominal_unit_price=Decimal("1000000"), rebate_rate_pct=Decimal("0.05")
            )
        )
        assert r.rebate_equivalent_unit_price == Decimal("950000.00")

    def test_rate_of_one_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_rebate_equivalent_price(
                RebateEquivalentInput(
                    currency="IRR", nominal_unit_price=Decimal("1000"), rebate_rate_pct=Decimal("1")
                )
            )

    def test_negative_price_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_rebate_equivalent_price(
                RebateEquivalentInput(
                    currency="IRR", nominal_unit_price=Decimal("-1"), rebate_rate_pct=Decimal("0.1")
                )
            )


class TestFocEquivalent:
    def test_normal_case(self):
        r = calculate_foc_equivalent_unit_cost(
            FocEquivalentInput(
                currency="IRR",
                purchased_units=Decimal("100"),
                unit_price=Decimal("1000000"),
                foc_units=Decimal("5"),
            )
        )
        assert r.effective_unit_cost == Decimal("952380.95")
        assert r.total_delivered_units == Decimal("105")

    def test_zero_purchased_units_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_foc_equivalent_unit_cost(
                FocEquivalentInput(
                    currency="IRR",
                    purchased_units=Decimal("0"),
                    unit_price=Decimal("100"),
                    foc_units=Decimal("5"),
                )
            )


class TestChannelMargin:
    def test_normal_case(self):
        r = calculate_channel_margin(
            ChannelMarginInput(currency="IRR", sell_price=Decimal("1000"), cost_to_seller=Decimal("700"))
        )
        assert r.margin_per_unit == Decimal("300.00")
        assert r.margin_pct == Decimal("0.3000")

    def test_negative_cost_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_channel_margin(
                ChannelMarginInput(currency="IRR", sell_price=Decimal("1000"), cost_to_seller=Decimal("-1"))
            )


class TestChannelConflict:
    def test_conflict_detected_when_sub_dealer_cheaper(self):
        r = detect_channel_conflict(
            ChannelConflictInput(
                currency="IRR", price_to_dealer=Decimal("1000"), price_to_sub_dealer=Decimal("900")
            )
        )
        assert r.conflict_detected is True
        assert r.price_gap == Decimal("100.00")

    def test_no_conflict_when_normal_order(self):
        r = detect_channel_conflict(
            ChannelConflictInput(
                currency="IRR", price_to_dealer=Decimal("900"), price_to_sub_dealer=Decimal("1000")
            )
        )
        assert r.conflict_detected is False


class TestCreditEconomics:
    def test_normal_case(self):
        r = calculate_credit_adjusted_margin(
            CreditEconomicsInput(
                currency="IRR",
                incremental_margin=Decimal("500"),
                financing_cost=Decimal("50"),
                expected_credit_loss=Decimal("30"),
                collection_cost=Decimal("10"),
            )
        )
        assert r.net_credit_adjusted_margin == Decimal("410.00")

    def test_missing_field_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_credit_adjusted_margin(
                CreditEconomicsInput(
                    currency="IRR",
                    incremental_margin=Decimal("500"),
                    financing_cost=None,
                    expected_credit_loss=Decimal("30"),
                    collection_cost=Decimal("10"),
                )
            )
