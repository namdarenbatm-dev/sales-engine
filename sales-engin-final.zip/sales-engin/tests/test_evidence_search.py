from app.domain.evidence.search import ClaimRecord, keyword_search

CLAIMS = [
    ClaimRecord("1", "افزایش قیمت بدون تعدیل ارزش، ریزش نرخ نگهداری مشتری را افزایش می‌دهد", "کتاب قیمت‌گذاری استراتژیک", "قوی"),
    ClaimRecord("2", "رقابت شدید کانال باعث کاهش حاشیه سود در سطح نمایندگی می‌شود", "گزارش صنعتی پرداخت", "متوسط"),
    ClaimRecord("3", "وفاداری مشتری با کیفیت خدمات پس از فروش رابطه مستقیم دارد", "مقاله علمی خدمات مشتری", "قوی"),
]


def test_relevant_claim_ranks_first():
    results = keyword_search("کاهش حاشیه سود کانال", CLAIMS)
    assert len(results) == 1
    assert results[0].claim.claim_id == "2"


def test_no_match_returns_empty():
    results = keyword_search("موضوعی کاملاً نامرتبط با فوتبال", CLAIMS)
    assert results == []


def test_empty_query_returns_empty():
    results = keyword_search("", CLAIMS)
    assert results == []


def test_top_n_limits_results():
    many_claims = CLAIMS * 5
    results = keyword_search("کانال", many_claims, top_n=3)
    assert len(results) <= 3
