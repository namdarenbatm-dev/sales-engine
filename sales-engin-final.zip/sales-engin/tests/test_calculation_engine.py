from decimal import Decimal

from app.domain.analytics.engine import PricingCoreRequest, run_pricing_core


def _base_request(**overrides) -> PricingCoreRequest:
    defaults = dict(
        tenant_id="tenant-1",
        currency="IRR",
        nominal_unit_price=Decimal("1000"),
        paid_units=Decimal("100"),
        total_discounts=Decimal("0"),
        total_rebates=Decimal("0"),
        foc_units=Decimal("0"),
        variable_cost_per_unit=Decimal("600"),
        minimum_required_margin_pct=Decimal("0.25"),
        proposed_price=None,
    )
    defaults.update(overrides)
    return PricingCoreRequest(**defaults)


def test_ok_result_includes_reproducible_trace():
    result = run_pricing_core(_base_request())
    assert result.status == "OK"
    assert result.trace.execution_id
    assert result.trace.tenant_id == "tenant-1"
    assert result.trace.formula_version
    assert result.trace.engine_version


def test_two_runs_have_different_execution_ids_but_same_versions():
    r1 = run_pricing_core(_base_request())
    r2 = run_pricing_core(_base_request())
    assert r1.trace.execution_id != r2.trace.execution_id
    assert r1.trace.formula_version == r2.trace.formula_version


def test_proposed_price_above_floor_yields_approve_option_only():
    result = run_pricing_core(_base_request(proposed_price=Decimal("900")))
    codes = {o.option_code for o in result.decision_options}
    assert codes == {"APPROVE_AT_PROPOSED_PRICE"}


def test_proposed_price_below_floor_yields_multiple_non_ranked_options():
    result = run_pricing_core(_base_request(proposed_price=Decimal("700")))
    codes = {o.option_code for o in result.decision_options}
    assert "REJECT_BELOW_FLOOR" in codes
    assert "COUNTER_OFFER_AT_FLOOR" in codes
    assert "REQUIRE_COUNTERPART_COMMITMENT" in codes
    # No option is flagged as "best" — architecture law 20: human decides.
    assert not any(hasattr(o, "is_best") for o in result.decision_options)


def test_no_proposed_price_returns_informational_option_only():
    result = run_pricing_core(_base_request(proposed_price=None))
    codes = {o.option_code for o in result.decision_options}
    assert codes == {"NO_PROPOSED_PRICE"}


def test_missing_critical_data_blocks_with_trace_and_persian_message():
    result = run_pricing_core(_base_request(paid_units=Decimal("0")))
    assert result.status == "BLOCKED"
    assert result.headline_fa == "شواهد ناکافی برای محاسبه قابل اتکا"
    assert result.trace is not None
    assert "paid_units" in result.missing_fields
