"""
تست E2E — مسیر کامل چرخه تصمیم: مسئله → محاسبه هسته قیمت‌گذاری → اقدام → ثبت نتیجه.

این تست از TestClient واقعی FastAPI استفاده می‌کند (نه فقط توابع سرویس مجزا) تا مسیر
درخواست HTTP کامل را تأیید کند. مانند test_api_pricing_flow.py، جلسه دیتابیس با یک
FakeSession جایگزین می‌شود تا بدون نیاز به Postgres واقعی اجرا شود.

توجه: این فایل به fastapi/httpx نیاز دارد و در محیط ساخت (بدون اینترنت برای pip install)
مستقیماً اجرا نشده — باید با `pytest` بعد از `pip install -r requirements.txt` تأیید شود.
"""

import uuid
from contextlib import contextmanager

from fastapi.testclient import TestClient

from app.domain.action import router as action_router_module
from app.domain.decision import router as decision_router_module
from app.domain.problem import router as problem_router_module
from app.main import app

TENANT_HEADER = {"X-Tenant-Id": "tenant-e2e"}


class FakeSession:
    """جلسه ساختگی درون‌حافظه‌ای — کوئری‌های ساده را روی اشیاء افزوده‌شده اجرا می‌کند."""

    def __init__(self):
        self.added = []
        self._by_id: dict[str, object] = {}

    def add(self, obj):
        self.added.append(obj)
        obj_id = getattr(obj, "id", None)
        if obj_id is None:
            obj_id = uuid.uuid4()
            try:
                obj.id = obj_id
            except Exception:
                pass
        self._by_id[str(obj_id)] = obj

    def flush(self):
        pass

    def query(self, model):
        return _FakeQuery([obj for obj in self.added if isinstance(obj, model)])


class _FakeQuery:
    def __init__(self, items):
        self._items = items

    def filter(self, *_args, **_kwargs):
        return self

    def one_or_none(self):
        return self._items[0] if self._items else None

    def all(self):
        return self._items


@contextmanager
def fake_get_session(tenant_id: str | None = None):
    yield FakeSession()


def setup_module(module):
    problem_router_module.get_session = fake_get_session
    decision_router_module.get_session = fake_get_session
    action_router_module.get_session = fake_get_session


client = TestClient(app)


def test_full_decision_lifecycle_problem_to_action_result():
    # ۱. ثبت مسئله
    problem_response = client.post(
        "/api/v1/problems",
        json={
            "business_area_fa": "قیمت‌گذاری کانال",
            "observed_symptom_fa": "ریزش حاشیه سود در نمایندگی‌های استان X",
            "target_outcome_fa": "بازگرداندن حاشیه سود مشارکت به بالای ۲۰٪",
        },
        headers=TENANT_HEADER,
    )
    assert problem_response.status_code == 200
    problem_id = problem_response.json()["id"]

    # ۲. اجرای هسته قیمت‌گذاری، متصل به همان مسئله
    pricing_response = client.post(
        "/api/v1/pricing-core/calculate",
        json={
            "problem_id": problem_id,
            "currency": "IRR",
            "nominal_unit_price": "1000",
            "paid_units": "100",
            "total_discounts": "0",
            "total_rebates": "0",
            "foc_units": "0",
            "variable_cost_per_unit": "600",
            "minimum_required_margin_pct": "0.25",
            "proposed_price": "700",
        },
        headers=TENANT_HEADER,
    )
    assert pricing_response.status_code == 200
    pricing_body = pricing_response.json()
    assert pricing_body["status"] == "OK"
    assert pricing_body["trace"]["problem_id"] == problem_id

    # ۳. ایجاد اقدام از یکی از گزینه‌های تصمیم
    action_response = client.post(
        "/api/v1/actions",
        json={
            "problem_id": problem_id,
            "source_execution_id": pricing_body["trace"]["execution_id"],
            "option_code": "COUNTER_OFFER_AT_FLOOR",
            "action_type_fa": "پیشنهاد متقابل",
            "description_fa": "پیشنهاد قیمت در سطح کف قیمت به نماینده",
            "owner_fa": "مدیر فروش منطقه",
            "expected_result_value": "800",
        },
        headers=TENANT_HEADER,
    )
    assert action_response.status_code == 200
    action_id = action_response.json()["id"]
    assert action_response.json()["problem_id"] == problem_id

    # ۴. ثبت نتیجه واقعی
    result_response = client.post(
        f"/api/v1/actions/{action_id}/result",
        json={"actual_result_value": "550"},
        headers=TENANT_HEADER,
    )
    assert result_response.status_code == 200
    result_body = result_response.json()
    assert result_body["action"]["actual_result_value"] == "550"
    # انحراف ۳۱٫۲۵٪ باید از آستانه ۲۰٪ عبور کند و کاندیدای یادگیری بسازد
    assert result_body["learning_candidate_created"] is True
    assert result_body["variance"]["exceeds_learning_threshold"] is True
