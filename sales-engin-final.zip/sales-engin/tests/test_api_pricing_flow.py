"""
تست یکپارچه API — از HTTP request تا پاسخ، بدون نیاز به PostgreSQL واقعی.

اجرای این فایل نیازمند `pip install -r requirements.txt` است (fastapi, httpx, sqlalchemy).
جلسه دیتابیس واقعی با یک Fake Session جایگزین می‌شود تا این تست بدون وابستگی
به یک Postgres در حال اجرا، منطق مسیر کامل درخواست را تأیید کند؛ تست‌های واقعی
یکپارچگی با Postgres باید در CI با docker-compose اجرا شوند (خارج از این قطعه).
"""

from contextlib import contextmanager

from fastapi.testclient import TestClient

from app.domain.decision import router as decision_router_module
from app.main import app

TENANT_HEADER = {"X-Tenant-Id": "tenant-test-1"}


class FakeSession:
    """جلسه ساختگی که فقط append می‌کند و به دیتابیس واقعی وصل نمی‌شود."""

    def __init__(self):
        self.added = []

    def add(self, obj):
        self.added.append(obj)

    def flush(self):
        pass


@contextmanager
def fake_get_session(tenant_id: str | None = None):
    yield FakeSession()


def setup_module(module):
    decision_router_module.get_session = fake_get_session


client = TestClient(app)


def test_missing_tenant_header_is_rejected():
    response = client.post("/api/v1/pricing-core/calculate", json={})
    assert response.status_code == 400
    assert response.json()["status"] == "REJECTED"


def test_full_pricing_core_flow_ok():
    payload = {
        "currency": "IRR",
        "nominal_unit_price": "1000",
        "paid_units": "100",
        "total_discounts": "0",
        "total_rebates": "0",
        "foc_units": "0",
        "variable_cost_per_unit": "600",
        "minimum_required_margin_pct": "0.25",
        "proposed_price": "700",
    }
    response = client.post(
        "/api/v1/pricing-core/calculate", json=payload, headers=TENANT_HEADER
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "OK"
    assert body["price_floor_effective_unit_price"] == "800.00"
    option_codes = {o["option_code"] for o in body["decision_options"]}
    assert "REJECT_BELOW_FLOOR" in option_codes
    assert "COUNTER_OFFER_AT_FLOOR" in option_codes
    assert body["trace"]["execution_id"]


def test_full_pricing_core_flow_blocked_missing_data():
    payload = {
        "currency": "IRR",
        "nominal_unit_price": "1000",
        "paid_units": "0",
        "variable_cost_per_unit": "600",
        "minimum_required_margin_pct": "0.25",
    }
    response = client.post(
        "/api/v1/pricing-core/calculate", json=payload, headers=TENANT_HEADER
    )
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "BLOCKED"
    assert body["headline_fa"] == "شواهد ناکافی برای محاسبه قابل اتکا"
    assert "paid_units" in body["missing_fields"]


def test_model_registry_lists_pricing_core_models_without_ranking():
    response = client.get("/api/v1/models/pricing-core")
    assert response.status_code == 200
    codes = {m["code"] for m in response.json()}
    assert codes == {"effective_price_v1", "contribution_margin_v1", "price_floor_v1"}
