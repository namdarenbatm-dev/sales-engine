import time

import pytest

from app.domain.identity.security import (
    ExpiredTokenError,
    InvalidTokenError,
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)


class TestPasswordHashing:
    def test_correct_password_verifies(self):
        stored = hash_password("SuperSecret123")
        assert verify_password("SuperSecret123", stored) is True

    def test_wrong_password_rejected(self):
        stored = hash_password("SuperSecret123")
        assert verify_password("wrong-password", stored) is False

    def test_same_password_yields_different_hashes(self):
        # نمک تصادفی — دو هش برای رمز یکسان نباید یکسان باشند
        h1 = hash_password("SuperSecret123")
        h2 = hash_password("SuperSecret123")
        assert h1 != h2
        assert verify_password("SuperSecret123", h1)
        assert verify_password("SuperSecret123", h2)

    def test_malformed_stored_hash_returns_false_not_error(self):
        assert verify_password("anything", "not-a-valid-hash") is False


class TestAccessToken:
    def test_round_trip(self):
        token = create_access_token({"sub": "user-1", "tenant_id": "t1"}, secret="s3cret")
        payload = decode_access_token(token, secret="s3cret")
        assert payload["sub"] == "user-1"
        assert payload["tenant_id"] == "t1"

    def test_wrong_secret_rejected(self):
        token = create_access_token({"sub": "user-1", "tenant_id": "t1"}, secret="s3cret")
        with pytest.raises(InvalidTokenError):
            decode_access_token(token, secret="wrong-secret")

    def test_tampered_payload_rejected(self):
        token = create_access_token({"sub": "user-1", "tenant_id": "t1"}, secret="s3cret")
        header_b64, payload_b64, sig_b64 = token.split(".")
        tampered = f"{header_b64}.{payload_b64}TAMPERED.{sig_b64}"
        with pytest.raises(InvalidTokenError):
            decode_access_token(tampered, secret="s3cret")

    def test_expired_token_rejected(self):
        token = create_access_token(
            {"sub": "user-1", "tenant_id": "t1"}, secret="s3cret", expires_in_seconds=1
        )
        time.sleep(1.5)
        with pytest.raises(ExpiredTokenError):
            decode_access_token(token, secret="s3cret")
