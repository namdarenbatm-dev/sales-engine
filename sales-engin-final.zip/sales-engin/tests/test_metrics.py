from app.core.metrics import record_request, render_prometheus_text, reset_metrics


def setup_function():
    reset_metrics()


def test_counter_increments_per_unique_label_set():
    record_request("GET", "/health", 200, 1.0)
    record_request("GET", "/health", 200, 2.0)
    record_request("GET", "/health", 500, 3.0)

    text = render_prometheus_text()
    assert 'sales_engin_http_requests_total{method="GET",path="/health",status="200"} 2' in text
    assert 'sales_engin_http_requests_total{method="GET",path="/health",status="500"} 1' in text


def test_histogram_sum_and_count_match_recorded_durations():
    record_request("POST", "/x", 200, 10.0)
    record_request("POST", "/x", 200, 20.0)

    text = render_prometheus_text()
    assert 'sales_engin_http_request_duration_ms_sum{method="POST",path="/x",status="200"} 30.0' in text
    assert 'sales_engin_http_request_duration_ms_count{method="POST",path="/x",status="200"} 2' in text


def test_bucket_cumulative_counts_are_monotonic():
    record_request("GET", "/y", 200, 7.0)  # بین ۵ و ۱۰ میلی‌ثانیه

    text = render_prometheus_text()
    assert 'le="5"} 0' in text
    assert 'le="10"} 1' in text
    assert 'le="+Inf"} 1' in text


def test_empty_registry_renders_only_headers():
    text = render_prometheus_text()
    assert "sales_engin_http_requests_total{" not in text
    assert "# HELP" in text
