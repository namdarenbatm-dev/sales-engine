from decimal import Decimal

import pytest

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.attribution import (
    ATTRIBUTION_NOT_IDENTIFIABLE,
    AttributionInput,
    evaluate_attribution,
)
from app.domain.analytics.formulas.variance import VarianceInput, calculate_expected_vs_actual_variance


class TestVariance:
    def test_large_negative_variance_exceeds_threshold(self):
        r = calculate_expected_vs_actual_variance(
            VarianceInput(expected_value=Decimal("1000"), actual_value=Decimal("700"))
        )
        assert r.variance_pct == Decimal("-0.3000")
        assert r.exceeds_learning_threshold is True

    def test_small_variance_does_not_exceed_threshold(self):
        r = calculate_expected_vs_actual_variance(
            VarianceInput(expected_value=Decimal("1000"), actual_value=Decimal("950"))
        )
        assert r.exceeds_learning_threshold is False

    def test_missing_value_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_expected_vs_actual_variance(
                VarianceInput(expected_value=None, actual_value=Decimal("1"))
            )

    def test_zero_expected_value_pct_is_none(self):
        r = calculate_expected_vs_actual_variance(
            VarianceInput(expected_value=Decimal("0"), actual_value=Decimal("100"))
        )
        assert r.variance_pct is None
        assert r.exceeds_learning_threshold is False


class TestAttribution:
    def test_no_control_group_not_identifiable(self):
        r = evaluate_attribution(AttributionInput(actual_kpi_change=Decimal("500")))
        assert r.attribution_level == ATTRIBUTION_NOT_IDENTIFIABLE
        assert r.estimated_incremental_effect is None

    def test_with_control_group_estimates_incremental_effect(self):
        r = evaluate_attribution(
            AttributionInput(actual_kpi_change=Decimal("500"), control_group_kpi_change=Decimal("200"))
        )
        assert r.attribution_level == "ESTIMATED_INCREMENTAL_EFFECT"
        assert r.estimated_incremental_effect == Decimal("300")

    def test_never_claims_certainty_language(self):
        r = evaluate_attribution(
            AttributionInput(actual_kpi_change=Decimal("500"), control_group_kpi_change=Decimal("200"))
        )
        assert "برآورد" in r.explanation_fa  # هرگز کلمه قطعیت به‌کار نمی‌رود
