from decimal import Decimal

import pytest

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import (
    ContributionMarginInput,
    EffectivePriceInput,
    PriceFloorInput,
    calculate_contribution_margin,
    calculate_effective_price,
    calculate_price_floor,
)


class TestEffectivePrice:
    def test_normal_case(self):
        result = calculate_effective_price(
            EffectivePriceInput(
                currency="irr",
                nominal_unit_price=Decimal("1000000"),
                paid_units=Decimal("100"),
                total_discounts=Decimal("2000000"),
                total_rebates=Decimal("1000000"),
                foc_units=Decimal("5"),
            )
        )
        # gross = 100_000_000 ; net = 97_000_000 ; delivered units = 105
        assert result.currency == "IRR"
        assert result.net_revenue == Decimal("97000000.00")
        assert result.effective_unit_price == Decimal("923809.52")  # 97,000,000 / 105 rounded

    def test_zero_units_blocked(self):
        with pytest.raises(InsufficientEvidenceError) as exc_info:
            calculate_effective_price(
                EffectivePriceInput(
                    currency="IRR",
                    nominal_unit_price=Decimal("1000"),
                    paid_units=Decimal("0"),
                    total_discounts=Decimal("0"),
                    total_rebates=Decimal("0"),
                )
            )
        assert "paid_units" in exc_info.value.missing_fields

    def test_negative_price_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_effective_price(
                EffectivePriceInput(
                    currency="IRR",
                    nominal_unit_price=Decimal("-10"),
                    paid_units=Decimal("5"),
                    total_discounts=Decimal("0"),
                    total_rebates=Decimal("0"),
                )
            )

    def test_missing_currency_blocked_with_persian_message(self):
        with pytest.raises(InsufficientEvidenceError) as exc_info:
            calculate_effective_price(
                EffectivePriceInput(
                    currency="",
                    nominal_unit_price=Decimal("1000"),
                    paid_units=Decimal("5"),
                    total_discounts=Decimal("0"),
                    total_rebates=Decimal("0"),
                )
            )
        assert exc_info.value.explanation_fa  # non-empty Persian explanation
        assert "currency" in exc_info.value.missing_fields

    def test_discounts_exceed_revenue_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_effective_price(
                EffectivePriceInput(
                    currency="IRR",
                    nominal_unit_price=Decimal("100"),
                    paid_units=Decimal("1"),
                    total_discounts=Decimal("500"),
                    total_rebates=Decimal("0"),
                )
            )

    def test_no_foc_units_defaults_to_zero(self):
        result = calculate_effective_price(
            EffectivePriceInput(
                currency="IRR",
                nominal_unit_price=Decimal("100"),
                paid_units=Decimal("10"),
                total_discounts=Decimal("0"),
                total_rebates=Decimal("0"),
            )
        )
        assert result.total_delivered_units == Decimal("10")
        assert result.effective_unit_price == Decimal("100.00")


class TestContributionMargin:
    def test_normal_case(self):
        result = calculate_contribution_margin(
            ContributionMarginInput(
                currency="IRR",
                effective_unit_price=Decimal("1000"),
                variable_cost_per_unit=Decimal("600"),
            )
        )
        assert result.contribution_margin_per_unit == Decimal("400.00")
        assert result.contribution_margin_pct == Decimal("0.4000")

    def test_negative_variable_cost_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_contribution_margin(
                ContributionMarginInput(
                    currency="IRR",
                    effective_unit_price=Decimal("1000"),
                    variable_cost_per_unit=Decimal("-1"),
                )
            )

    def test_negative_margin_allowed_but_not_hidden(self):
        # Selling below cost is a valid (bad) business reality — must be shown, not blocked.
        result = calculate_contribution_margin(
            ContributionMarginInput(
                currency="IRR",
                effective_unit_price=Decimal("500"),
                variable_cost_per_unit=Decimal("600"),
            )
        )
        assert result.contribution_margin_per_unit == Decimal("-100.00")

    def test_zero_effective_price_pct_is_none_not_fabricated(self):
        result = calculate_contribution_margin(
            ContributionMarginInput(
                currency="IRR",
                effective_unit_price=Decimal("0"),
                variable_cost_per_unit=Decimal("10"),
            )
        )
        assert result.contribution_margin_pct is None


class TestPriceFloor:
    def test_normal_case(self):
        result = calculate_price_floor(
            PriceFloorInput(
                currency="IRR",
                variable_cost_per_unit=Decimal("600"),
                minimum_required_margin_pct=Decimal("0.25"),
            )
        )
        # 600 / (1 - 0.25) = 800
        assert result.price_floor_effective_unit_price == Decimal("800.00")

    def test_margin_pct_of_one_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_price_floor(
                PriceFloorInput(
                    currency="IRR",
                    variable_cost_per_unit=Decimal("600"),
                    minimum_required_margin_pct=Decimal("1"),
                )
            )

    def test_negative_margin_pct_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_price_floor(
                PriceFloorInput(
                    currency="IRR",
                    variable_cost_per_unit=Decimal("600"),
                    minimum_required_margin_pct=Decimal("-0.1"),
                )
            )

    def test_missing_variable_cost_blocked_with_persian_headline(self):
        with pytest.raises(InsufficientEvidenceError) as exc_info:
            calculate_price_floor(
                PriceFloorInput(
                    currency="IRR",
                    variable_cost_per_unit=None,
                    minimum_required_margin_pct=Decimal("0.2"),
                )
            )
        assert InsufficientEvidenceError.HEADLINE_FA in str(exc_info.value)
