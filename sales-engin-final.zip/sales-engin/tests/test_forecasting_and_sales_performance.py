from decimal import Decimal

import pytest

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.forecasting import (
    ExponentialSmoothingInput,
    MovingAverageInput,
    NaiveForecastInput,
    WeightedMovingAverageInput,
    calculate_exponential_smoothing_forecast,
    calculate_moving_average_forecast,
    calculate_naive_forecast,
    calculate_weighted_moving_average_forecast,
)
from app.domain.analytics.formulas.sales_performance import (
    FunnelStage,
    SalesFunnelInput,
    SalesGrowthInput,
    SalesProductivityInput,
    calculate_sales_funnel,
    calculate_sales_growth,
    calculate_sales_productivity,
)

HIST = [Decimal(x) for x in ["100", "110", "105", "120", "130"]]


class TestSalesGrowth:
    def test_normal_case(self):
        r = calculate_sales_growth(
            SalesGrowthInput(previous_period_value=Decimal("1000"), current_period_value=Decimal("1250"))
        )
        assert r.growth_rate_pct == Decimal("0.2500")

    def test_zero_previous_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_sales_growth(
                SalesGrowthInput(previous_period_value=Decimal("0"), current_period_value=Decimal("10"))
            )


class TestSalesFunnel:
    def test_normal_case(self):
        r = calculate_sales_funnel(
            SalesFunnelInput(
                stages=[
                    FunnelStage("سرنخ", Decimal("1000")),
                    FunnelStage("فرصت", Decimal("300")),
                    FunnelStage("بسته‌شده", Decimal("40")),
                ]
            )
        )
        assert r.overall_conversion_pct == Decimal("0.0400")
        assert len(r.conversions) == 2

    def test_single_stage_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_sales_funnel(SalesFunnelInput(stages=[FunnelStage("سرنخ", Decimal("1000"))]))


class TestSalesProductivity:
    def test_normal_case(self):
        r = calculate_sales_productivity(
            SalesProductivityInput(output_value=Decimal("500000000"), input_value=Decimal("10"))
        )
        assert r.productivity_ratio == Decimal("50000000.00")

    def test_zero_input_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_sales_productivity(
                SalesProductivityInput(output_value=Decimal("100"), input_value=Decimal("0"))
            )


class TestForecasting:
    def test_naive(self):
        r = calculate_naive_forecast(NaiveForecastInput(HIST))
        assert r.forecast_next_period == Decimal("130.00")

    def test_moving_average(self):
        r = calculate_moving_average_forecast(MovingAverageInput(HIST, window=3))
        assert r.forecast_next_period == Decimal("118.33")

    def test_moving_average_insufficient_history_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_moving_average_forecast(MovingAverageInput(HIST[:2], window=3))

    def test_weighted_moving_average(self):
        r = calculate_weighted_moving_average_forecast(
            WeightedMovingAverageInput(HIST, weights=[Decimal("0.2"), Decimal("0.3"), Decimal("0.5")])
        )
        assert r.forecast_next_period == Decimal("122.00")

    def test_weighted_moving_average_bad_weights_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_weighted_moving_average_forecast(
                WeightedMovingAverageInput(HIST, weights=[Decimal("0.5"), Decimal("0.6")])
            )

    def test_exponential_smoothing(self):
        r = calculate_exponential_smoothing_forecast(
            ExponentialSmoothingInput(HIST, alpha=Decimal("0.3"))
        )
        assert r.forecast_next_period == Decimal("114.96")

    def test_exponential_smoothing_alpha_out_of_range_blocked(self):
        with pytest.raises(InsufficientEvidenceError):
            calculate_exponential_smoothing_forecast(
                ExponentialSmoothingInput(HIST, alpha=Decimal("1.5"))
            )
