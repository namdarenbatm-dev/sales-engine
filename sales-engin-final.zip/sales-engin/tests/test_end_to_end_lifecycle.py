"""
تست چرخه کامل (End-to-End، در سطح منطق خالص) —
مسئله → تحلیل قیمت‌گذاری → گزینه تصمیم → اقدام (شبیه‌سازی‌شده) → نتیجه واقعی →
مقایسه با مورد انتظار → (در صورت انحراف بالا) پیشنهاد یادگیری.

این تست به دیتابیس واقعی وابسته نیست؛ زنجیره منطقی واقعی موتورها را از ابتدا تا انتها
تأیید می‌کند، نه فقط یک تابع مجزا را.
"""

from decimal import Decimal

from app.domain.analytics.engine import PricingCoreRequest, run_pricing_core
from app.domain.analytics.formulas.attribution import AttributionInput, evaluate_attribution
from app.domain.analytics.formulas.variance import (
    LEARNING_CANDIDATE_THRESHOLD_PCT,
    VarianceInput,
    calculate_expected_vs_actual_variance,
)


def test_full_lifecycle_from_pricing_decision_to_learning_signal():
    # ۱. تحلیل قیمت‌گذاری برای یک مسئله واقعی
    request = PricingCoreRequest(
        tenant_id="tenant-e2e", currency="IRR", nominal_unit_price=Decimal("1000"),
        paid_units=Decimal("100"), total_discounts=Decimal("0"), total_rebates=Decimal("0"),
        foc_units=Decimal("0"), variable_cost_per_unit=Decimal("600"),
        minimum_required_margin_pct=Decimal("0.25"), proposed_price=Decimal("750"),
    )
    pricing_result = run_pricing_core(request)
    assert pricing_result.status == "OK"

    # ۲. یکی از گزینه‌های تصمیم انتخاب می‌شود (بدون رتبه‌بندی خودکار)
    chosen_option = next(
        o for o in pricing_result.decision_options if o.option_code == "COUNTER_OFFER_AT_FLOOR"
    )
    assert chosen_option.supported_by_evidence is True

    # ۳. اقدام اجرا می‌شود؛ انتظار می‌رود حاشیه سود مشارکت هدف محقق شود
    expected_result_value = pricing_result.contribution_margin_per_unit * request.paid_units

    # ۴. نتیجه واقعی — کمتر از انتظار (مثلاً به‌دلیل مقاومت بازار در برابر افزایش قیمت)
    actual_result_value = expected_result_value * Decimal("0.6")

    variance = calculate_expected_vs_actual_variance(
        VarianceInput(expected_value=expected_result_value, actual_value=actual_result_value)
    )
    assert variance.exceeds_learning_threshold is True
    assert abs(variance.variance_pct) >= LEARNING_CANDIDATE_THRESHOLD_PCT

    # ۵. بدون گروه مقایسه، سنجش سهم عوامل باید صریحاً «غیرقابل‌شناسایی» باشد — نه یک ادعای قطعی
    attribution = evaluate_attribution(AttributionInput(actual_kpi_change=actual_result_value))
    assert attribution.attribution_level == "ATTRIBUTION_NOT_IDENTIFIABLE"


def test_full_lifecycle_small_variance_does_not_trigger_learning_signal():
    request = PricingCoreRequest(
        tenant_id="tenant-e2e", currency="IRR", nominal_unit_price=Decimal("1000"),
        paid_units=Decimal("100"), total_discounts=Decimal("0"), total_rebates=Decimal("0"),
        foc_units=Decimal("0"), variable_cost_per_unit=Decimal("600"),
        minimum_required_margin_pct=Decimal("0.25"),
    )
    pricing_result = run_pricing_core(request)
    expected_result_value = pricing_result.contribution_margin_per_unit * request.paid_units
    actual_result_value = expected_result_value * Decimal("0.97")  # فقط ۳٪ کمتر

    variance = calculate_expected_vs_actual_variance(
        VarianceInput(expected_value=expected_result_value, actual_value=actual_result_value)
    )
    assert variance.exceeds_learning_threshold is False


def test_reproducibility_same_inputs_same_numbers_different_execution_id():
    request = PricingCoreRequest(
        tenant_id="tenant-repro", currency="IRR", nominal_unit_price=Decimal("1000"),
        paid_units=Decimal("100"), total_discounts=Decimal("0"), total_rebates=Decimal("0"),
        foc_units=Decimal("0"), variable_cost_per_unit=Decimal("600"),
        minimum_required_margin_pct=Decimal("0.25"),
    )
    r1 = run_pricing_core(request)
    r2 = run_pricing_core(request)

    assert r1.effective_unit_price == r2.effective_unit_price
    assert r1.contribution_margin_per_unit == r2.contribution_margin_per_unit
    assert r1.price_floor_effective_unit_price == r2.price_floor_effective_unit_price
    assert r1.trace.formula_version == r2.trace.formula_version
    assert r1.trace.execution_id != r2.trace.execution_id  # هر اجرا شناسه یکتای خودش را دارد
