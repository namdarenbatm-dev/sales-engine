from datetime import datetime, timedelta, timezone

from app.domain.identity.lockout import (
    LockoutState,
    MAX_FAILED_ATTEMPTS,
    check_can_attempt_login,
    record_failed_attempt,
    record_successful_login,
)

NOW = datetime.now(timezone.utc)


def test_allowed_before_reaching_max_attempts():
    state = LockoutState(failed_attempts=0, locked_until=None)
    for _ in range(MAX_FAILED_ATTEMPTS - 1):
        assert check_can_attempt_login(state, NOW).allowed is True
        state = record_failed_attempt(state, NOW)
    assert state.locked_until is None


def test_locks_on_reaching_max_attempts():
    state = LockoutState(failed_attempts=MAX_FAILED_ATTEMPTS - 1, locked_until=None)
    state = record_failed_attempt(state, NOW)
    assert state.locked_until is not None
    decision = check_can_attempt_login(state, NOW)
    assert decision.allowed is False
    assert "قفل" in decision.reason_fa


def test_unlocks_after_duration_passes():
    state = LockoutState(failed_attempts=MAX_FAILED_ATTEMPTS, locked_until=NOW + timedelta(minutes=15))
    still_locked = check_can_attempt_login(state, NOW + timedelta(minutes=5))
    assert still_locked.allowed is False
    unlocked = check_can_attempt_login(state, NOW + timedelta(minutes=16))
    assert unlocked.allowed is True


def test_successful_login_resets_state():
    state = LockoutState(failed_attempts=4, locked_until=None)
    reset = record_successful_login(state)
    assert reset.failed_attempts == 0
    assert reset.locked_until is None
