from dataclasses import dataclass, field

from app.domain.problem.diagnostic import get_next_diagnostic_question


@dataclass
class FakeProblem:
    known_facts_fa: list = field(default_factory=list)
    hypotheses_fa: list = field(default_factory=list)
    assumptions_fa: list = field(default_factory=list)
    constraints_fa: list = field(default_factory=list)


def test_empty_problem_asks_for_facts_first():
    status = get_next_diagnostic_question(FakeProblem())
    assert status.sufficient_fa is False
    assert status.next_question.field_fa == "known_facts_fa"


def test_asks_for_hypotheses_after_facts_filled():
    problem = FakeProblem(known_facts_fa=["حاشیه سود کاهش یافته"])
    status = get_next_diagnostic_question(problem)
    assert status.next_question.field_fa == "hypotheses_fa"


def test_asks_for_constraints_last():
    problem = FakeProblem(
        known_facts_fa=["الف"], hypotheses_fa=["ب"], assumptions_fa=["ج"]
    )
    status = get_next_diagnostic_question(problem)
    assert status.next_question.field_fa == "constraints_fa"


def test_sufficient_when_all_filled():
    problem = FakeProblem(
        known_facts_fa=["الف"], hypotheses_fa=["ب"], assumptions_fa=["ج"], constraints_fa=["د"]
    )
    status = get_next_diagnostic_question(problem)
    assert status.sufficient_fa is True
    assert status.next_question is None


def test_prioritizes_least_covered_field_over_fixed_order():
    # واقعیت‌ها و فرضیه‌ها هر دو پوشش دارند؛ فرض‌ها و محدودیت‌ها هنوز خالی‌اند —
    # باید طبق اولویت کسب‌وکاری، اول فرض‌ها پرسیده شود، نه اینکه دوباره واقعیت/فرضیه بپرسد
    problem = FakeProblem(known_facts_fa=["الف"], hypotheses_fa=["ب"])
    status = get_next_diagnostic_question(problem)
    assert status.next_question.field_fa == "assumptions_fa"


def test_coverage_reported_accurately():
    problem = FakeProblem(known_facts_fa=["الف", "ب"], hypotheses_fa=["ج"])
    status = get_next_diagnostic_question(problem)
    assert status.coverage_fa == {
        "known_facts_fa": 2, "hypotheses_fa": 1, "assumptions_fa": 0, "constraints_fa": 0,
    }
