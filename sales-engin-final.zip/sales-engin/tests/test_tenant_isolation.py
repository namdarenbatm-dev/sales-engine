"""
تست ایزولاسیون مستأجر (Tenant Isolation) — قانون معماری ۱۳.

با یک FakeSession درون‌حافظه‌ای تأیید می‌کند که فیلتر tenant_id در سرویس‌ها واقعاً اعمال
می‌شود: رکورد ثبت‌شده توسط یک مستأجر، برای مستأجر دیگر قابل‌خواندن نیست.
"""

from app.domain.problem.schemas import ProblemCreateSchema
from app.domain.problem.service import create_problem, get_problem
from app.domain.problem.models import Problem


class FakeSession:
    def __init__(self):
        self.added: list = []

    def add(self, obj):
        self.added.append(obj)

    def flush(self):
        pass

    def query(self, model):
        return _FakeQuery([obj for obj in self.added if isinstance(obj, model)])


class _FakeQuery:
    def __init__(self, items):
        self._items = items
        self._filters = []

    def filter(self, *conditions):
        # شبیه‌سازی ساده: فقط شرط‌های == روی tenant_id و id را پشتیبانی می‌کند
        filtered = self._items
        for condition in conditions:
            left = condition.left.key
            right = condition.right.value
            filtered = [item for item in filtered if getattr(item, left, None) == right]
        return _FakeQuery(filtered)

    def one_or_none(self):
        return self._items[0] if self._items else None


def test_problem_created_by_one_tenant_not_visible_to_another():
    session = FakeSession()
    payload = ProblemCreateSchema(
        business_area_fa="قیمت‌گذاری", observed_symptom_fa="نمونه", target_outcome_fa="نمونه",
    )
    problem = create_problem(session, tenant_id="tenant-a", payload=payload)

    # همان مستأجر باید بتواند بخواند
    found_same_tenant = get_problem(session, tenant_id="tenant-a", problem_id=problem.id)
    assert found_same_tenant is not None

    # مستأجر دیگر نباید بتواند همان رکورد را بخواند
    found_other_tenant = get_problem(session, tenant_id="tenant-b", problem_id=problem.id)
    assert found_other_tenant is None
