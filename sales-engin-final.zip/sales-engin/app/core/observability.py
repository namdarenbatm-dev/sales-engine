"""
مشاهده‌پذیری حداقلی — Correlation ID + لاگ ساختاریافته JSON.

توجه صادقانه: این جایگزین OpenTelemetry/Prometheus/Grafana کامل بخش ۵۸ سند معماری
نیست. این یک لایه حداقلی است که هر درخواست را با یک correlation_id ردیابی می‌کند و
لاگ‌های JSON قابل‌پردازش توسط هر ابزار جمع‌آوری لاگ (ELK، Loki و...) تولید می‌کند —
پایه‌ای برای اتصال بعدی به OpenTelemetry، نه جایگزین کامل آن.
"""

import json
import logging
import time
import uuid
from collections.abc import Awaitable, Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.core.metrics import record_request

logger = logging.getLogger("sales_engin")
_handler = logging.StreamHandler()
_handler.setFormatter(logging.Formatter("%(message)s"))
logger.addHandler(_handler)
logger.setLevel(logging.INFO)
logger.propagate = False

CORRELATION_ID_HEADER = "X-Correlation-Id"


class ObservabilityMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        correlation_id = request.headers.get(CORRELATION_ID_HEADER) or str(uuid.uuid4())
        tenant_id = request.headers.get("X-Tenant-Id")
        start = time.monotonic()

        try:
            response = await call_next(request)
        except Exception as exc:  # noqa: BLE001 — لاگ کامل و سپس raise مجدد
            duration_ms = round((time.monotonic() - start) * 1000, 2)
            logger.error(
                json.dumps(
                    {
                        "correlation_id": correlation_id, "tenant_id": tenant_id,
                        "method": request.method, "path": request.url.path,
                        "duration_ms": duration_ms, "status": "error",
                        "error": str(exc),
                    },
                    ensure_ascii=False,
                )
            )
            raise

        duration_ms = round((time.monotonic() - start) * 1000, 2)
        response.headers[CORRELATION_ID_HEADER] = correlation_id
        record_request(request.method, request.url.path, response.status_code, duration_ms)
        logger.info(
            json.dumps(
                {
                    "correlation_id": correlation_id, "tenant_id": tenant_id,
                    "method": request.method, "path": request.url.path,
                    "status_code": response.status_code, "duration_ms": duration_ms,
                },
                ensure_ascii=False,
            )
        )
        return response
