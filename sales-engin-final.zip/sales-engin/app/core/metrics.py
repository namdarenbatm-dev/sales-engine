"""
متریک‌های Prometheus-سازگار — نسخه حداقلی و درون‌فرآیندی، بدون کتابخانه prometheus_client.

توجه صادقانه: این جایگزین Prometheus/Grafana واقعی (با persistence، alerting، و جمع‌آوری
چند-نمونه‌ای) نیست. فقط یک شمارنده و هیستوگرام ساده در حافظه است که در endpoint
`/metrics` با فرمت متنی استاندارد Prometheus expose می‌شود — برای اسکرِیپ توسط یک
Prometheus واقعی در استقرار production کافی است، اما بدون آن سرور، خودش چیزی ذخیره
یا نمایش نمی‌دهد.
"""

import threading
from dataclasses import dataclass, field

_LOCK = threading.Lock()

_BUCKET_BOUNDARIES_MS = (5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000)


@dataclass
class _EndpointMetrics:
    count: int = 0
    total_duration_ms: float = 0.0
    bucket_counts: dict[float, int] = field(
        default_factory=lambda: {b: 0 for b in _BUCKET_BOUNDARIES_MS}
    )


_request_metrics: dict[tuple[str, str, int], _EndpointMetrics] = {}


def record_request(method: str, path: str, status_code: int, duration_ms: float) -> None:
    key = (method, path, status_code)
    with _LOCK:
        metrics = _request_metrics.setdefault(key, _EndpointMetrics())
        metrics.count += 1
        metrics.total_duration_ms += duration_ms
        for boundary in _BUCKET_BOUNDARIES_MS:
            if duration_ms <= boundary:
                metrics.bucket_counts[boundary] += 1


def reset_metrics() -> None:
    """فقط برای تست — متریک‌ها را پاک می‌کند."""
    with _LOCK:
        _request_metrics.clear()


def render_prometheus_text() -> str:
    lines = [
        "# HELP sales_engin_http_requests_total Total HTTP requests",
        "# TYPE sales_engin_http_requests_total counter",
    ]
    with _LOCK:
        items = list(_request_metrics.items())

    for (method, path, status_code), metrics in items:
        labels = f'method="{method}",path="{path}",status="{status_code}"'
        lines.append(f"sales_engin_http_requests_total{{{labels}}} {metrics.count}")

    lines.append("# HELP sales_engin_http_request_duration_ms HTTP request duration in milliseconds")
    lines.append("# TYPE sales_engin_http_request_duration_ms histogram")
    for (method, path, status_code), metrics in items:
        labels_base = f'method="{method}",path="{path}",status="{status_code}"'
        cumulative = 0
        for boundary in _BUCKET_BOUNDARIES_MS:
            cumulative = metrics.bucket_counts[boundary]
            lines.append(
                f'sales_engin_http_request_duration_ms_bucket{{{labels_base},le="{boundary}"}} {cumulative}'
            )
        lines.append(
            f'sales_engin_http_request_duration_ms_bucket{{{labels_base},le="+Inf"}} {metrics.count}'
        )
        lines.append(f"sales_engin_http_request_duration_ms_sum{{{labels_base}}} {metrics.total_duration_ms}")
        lines.append(f"sales_engin_http_request_duration_ms_count{{{labels_base}}} {metrics.count}")

    return "\n".join(lines) + "\n"
