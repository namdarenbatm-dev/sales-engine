from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.core.config import settings


class Base(DeclarativeBase):
    """کلاس پایه برای همه مدل‌های SQLAlchemy در سرویس."""


engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


@contextmanager
def get_session(tenant_id: str | None = None) -> Iterator[Session]:
    """
    جلسه دیتابیس — در صورت ارسال tenant_id، متغیر session سطح Postgres
    (`app.current_tenant_id`) را تنظیم می‌کند تا Row-Level Security (RLS) اعمال شود.

    قانون معماری ۱۱/۱۳: حتی اگر یک کوئری در لایه Python فراموش کند tenant_id را فیلتر
    کند، RLS در سطح دیتابیس مانع خواندن/نوشتن روی رکوردهای مستأجر دیگر می‌شود — دفاع
    دو-لایه (defense in depth)، نه اتکای صرف به فیلتر برنامه.
    """
    session = SessionLocal()
    try:
        if tenant_id:
            # از پارامتر bind استفاده می‌شود (نه f-string) تا از SQL injection جلوگیری شود
            session.execute(text("SET LOCAL app.current_tenant_id = :tenant_id"), {"tenant_id": tenant_id})
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


class MissingTenantContextError(Exception):
    """
    قانون معماری ۱۳: No Tenant Context → No Sensitive Query.
    هر عملیات روی داده‌های حساس باید یک tenant_id معتبر داشته باشد.
    """


def require_tenant_id(tenant_id: str | None) -> str:
    if not tenant_id or not tenant_id.strip():
        raise MissingTenantContextError(
            "شناسه مستأجر (tenant) الزامی است و در درخواست ارسال نشده است."
        )
    return tenant_id.strip()

