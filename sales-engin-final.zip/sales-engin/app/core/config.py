from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    تنظیمات پایه اپلیکیشن.
    قانون ۱۳ معماری: بدون Tenant Context هیچ کوئری حساسی اجرا نمی‌شود —
    این تنظیمات نام هدر اجباری برای شناسه مستأجر (tenant) را مشخص می‌کند.
    """

    app_name: str = "Sales Engin — Pricing Core"
    database_url: str = "postgresql+psycopg2://sales_engin:sales_engin@localhost:5432/sales_engin"
    tenant_header_name: str = "X-Tenant-Id"
    formula_engine_version: str = "pricing-core-1.0.0"
    jwt_secret_key: str = "CHANGE-ME-IN-PRODUCTION-USE-A-REAL-SECRETS-MANAGER"
    access_token_expires_seconds: int = 3600

    class Config:
        env_file = ".env"


settings = Settings()
