from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.database import MissingTenantContextError
from app.core.observability import ObservabilityMiddleware
from app.domain.decision.router import router as decision_router
from app.domain.decision.router_stage2 import router as stage2_router
from app.domain.decision.router_stage3 import router as stage3_router
from app.domain.decision.router_stage5 import router as stage5_router
from app.domain.action.router import router as action_router
from app.domain.decision.router_stage6 import router as stage6_router
from app.domain.evidence.router import router as evidence_router
from app.domain.identity.router import router as identity_router
from app.domain.learning.router import router as learning_router
from app.domain.model_registry.router import router as model_registry_router
from app.domain.problem.router import router as problem_router

app = FastAPI(title=settings.app_name)
app.add_middleware(ObservabilityMiddleware)

app.include_router(model_registry_router)
app.include_router(problem_router)
app.include_router(decision_router)
app.include_router(stage2_router)
app.include_router(stage3_router)
app.include_router(stage5_router)
app.include_router(stage6_router)
app.include_router(action_router)
app.include_router(learning_router)
app.include_router(evidence_router)
app.include_router(identity_router)


@app.exception_handler(MissingTenantContextError)
async def missing_tenant_handler(request: Request, exc: MissingTenantContextError) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={
            "status": "REJECTED",
            "headline_fa": "شناسه مستأجر ارسال نشده است",
            "explanation_fa": str(exc),
        },
    )


@app.get("/health")
def health():
    return {"status": "ok", "service": settings.app_name}


@app.get("/metrics")
def metrics():
    from fastapi.responses import PlainTextResponse

    from app.core.metrics import render_prometheus_text

    return PlainTextResponse(render_prometheus_text(), media_type="text/plain; version=0.0.4")
