import enum
import uuid
from datetime import date, datetime, timezone

from sqlalchemy import Date, DateTime, Enum, Numeric, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class ActionStatus(str, enum.Enum):
    CREATED = "ایجادشده"
    PENDING_APPROVAL = "در انتظار تأیید"
    APPROVED = "تأییدشده"
    IN_PROGRESS = "در حال اجرا"
    COMPLETED = "تکمیل‌شده"
    STOPPED = "متوقف‌شده"
    CANCELLED = "لغوشده"


class Action(Base):
    """
    اقدام — از تصمیم تا نتیجه واقعی.

    توجه: در این مرحله، «تصمیم» و «گزینه» به‌عنوان موجودیت‌های کامل و مستقل هنوز ساخته
    نشده‌اند (بخش‌های Decision/Decision Option در سند معماری)؛ به‌جای آن، این جدول به
    problem_id و در صورت وجود execution_id محاسبه‌ای که گزینه از آن آمده، ارجاع می‌دهد.
    """

    __tablename__ = "actions"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    problem_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    source_execution_id: Mapped[str] = mapped_column(String(64), nullable=True)
    option_code: Mapped[str] = mapped_column(String(128), nullable=True)

    action_type_fa: Mapped[str] = mapped_column(String(128), nullable=False)
    description_fa: Mapped[str] = mapped_column(Text, nullable=False)
    owner_fa: Mapped[str] = mapped_column(String(128), nullable=False)
    organizational_unit_fa: Mapped[str] = mapped_column(String(128), nullable=True)

    start_date: Mapped[date] = mapped_column(Date, nullable=True)
    deadline: Mapped[date] = mapped_column(Date, nullable=True)

    kpi_fa: Mapped[str] = mapped_column(String(128), nullable=True)
    baseline_value: Mapped[float] = mapped_column(Numeric(18, 2), nullable=True)
    target_value: Mapped[float] = mapped_column(Numeric(18, 2), nullable=True)

    status: Mapped[ActionStatus] = mapped_column(
        Enum(ActionStatus), nullable=False, default=ActionStatus.CREATED
    )
    execution_cost: Mapped[float] = mapped_column(Numeric(18, 2), nullable=True)
    risk_fa: Mapped[str] = mapped_column(Text, nullable=True)

    expected_result_value: Mapped[float] = mapped_column(Numeric(18, 2), nullable=True)
    actual_result_value: Mapped[float] = mapped_column(Numeric(18, 2), nullable=True)
    measurement_period_start: Mapped[date] = mapped_column(Date, nullable=True)
    measurement_period_end: Mapped[date] = mapped_column(Date, nullable=True)

    source_fa: Mapped[str] = mapped_column(String(128), nullable=True)
    approver_fa: Mapped[str] = mapped_column(String(128), nullable=True)
    approval_date: Mapped[date] = mapped_column(Date, nullable=True)

    # قانون ۱۸: تاریخچه بازنویسی نمی‌شود — هر تغییر وضعیت به این آرایه append می‌شود.
    change_history: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
