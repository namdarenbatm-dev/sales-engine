import uuid

from fastapi import APIRouter, Depends, Header, HTTPException

from app.core.database import get_session, require_tenant_id
from app.domain.identity.dependencies import require_permission
from app.domain.action.schemas import (
    ActionCreateSchema,
    ActionResponseSchema,
    ActionResultRecordSchema,
    ActionResultResponseSchema,
    ActionStatusUpdateSchema,
    AttributionSchema,
    VarianceSchema,
)
from app.domain.action.service import (
    create_action,
    get_action,
    record_action_result,
    update_action_status,
)

router = APIRouter(prefix="/api/v1/actions", tags=["action"])


@router.post("", response_model=ActionResponseSchema)
def create_action_endpoint(
    payload: ActionCreateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ActionResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        action = create_action(session, tenant_id, payload)
        session.flush()
        return ActionResponseSchema.model_validate(action)


@router.get("/{action_id}", response_model=ActionResponseSchema)
def get_action_endpoint(
    action_id: uuid.UUID,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ActionResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        action = get_action(session, tenant_id, action_id)
        if action is None:
            raise HTTPException(status_code=404, detail="اقدام موردنظر یافت نشد.")
        return ActionResponseSchema.model_validate(action)


@router.patch("/{action_id}/status", response_model=ActionResponseSchema)
def update_action_status_endpoint(
    action_id: uuid.UUID,
    payload: ActionStatusUpdateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
    principal=Depends(require_permission("action:approve")),
) -> ActionResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        action = get_action(session, tenant_id, action_id)
        if action is None:
            raise HTTPException(status_code=404, detail="اقدام موردنظر یافت نشد.")
        action = update_action_status(session, tenant_id, action, payload)
        session.flush()
        return ActionResponseSchema.model_validate(action)


@router.post("/{action_id}/result", response_model=ActionResultResponseSchema)
def record_action_result_endpoint(
    action_id: uuid.UUID,
    payload: ActionResultRecordSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ActionResultResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        action = get_action(session, tenant_id, action_id)
        if action is None:
            raise HTTPException(status_code=404, detail="اقدام موردنظر یافت نشد.")
        action, variance_result, attribution_result, learning_created = record_action_result(
            session, tenant_id, action, payload
        )
        session.flush()
        return ActionResultResponseSchema(
            action=ActionResponseSchema.model_validate(action),
            variance=(
                VarianceSchema(
                    variance_absolute=variance_result.variance_absolute,
                    variance_pct=variance_result.variance_pct,
                    exceeds_learning_threshold=variance_result.exceeds_learning_threshold,
                )
                if variance_result
                else None
            ),
            attribution=(
                AttributionSchema(
                    attribution_level=attribution_result.attribution_level,
                    estimated_incremental_effect=attribution_result.estimated_incremental_effect,
                    explanation_fa=attribution_result.explanation_fa,
                )
                if attribution_result
                else None
            ),
            learning_candidate_created=learning_created,
        )
