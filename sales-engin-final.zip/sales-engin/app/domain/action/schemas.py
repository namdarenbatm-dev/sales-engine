import uuid
from datetime import date, datetime
from decimal import Decimal

from pydantic import BaseModel, Field

from app.domain.action.models import ActionStatus


class ActionCreateSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    source_execution_id: str | None = None
    option_code: str | None = None
    action_type_fa: str
    description_fa: str
    owner_fa: str
    organizational_unit_fa: str | None = None
    start_date: date | None = None
    deadline: date | None = None
    kpi_fa: str | None = None
    baseline_value: Decimal | None = None
    target_value: Decimal | None = None
    execution_cost: Decimal | None = None
    risk_fa: str | None = None
    expected_result_value: Decimal | None = None
    source_fa: str | None = None


class ActionResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    problem_id: uuid.UUID | None
    source_execution_id: str | None
    option_code: str | None
    action_type_fa: str
    description_fa: str
    owner_fa: str
    organizational_unit_fa: str | None
    start_date: date | None
    deadline: date | None
    kpi_fa: str | None
    baseline_value: Decimal | None
    target_value: Decimal | None
    status: ActionStatus
    execution_cost: Decimal | None
    risk_fa: str | None
    expected_result_value: Decimal | None
    actual_result_value: Decimal | None
    measurement_period_start: date | None
    measurement_period_end: date | None
    source_fa: str | None
    approver_fa: str | None
    approval_date: date | None
    change_history: list
    created_at: datetime

    class Config:
        from_attributes = True


class ActionStatusUpdateSchema(BaseModel):
    new_status: ActionStatus
    reason_fa: str = Field(..., description="دلیل تغییر وضعیت — بدون بازنویسی تاریخچه قبلی")
    actor_fa: str
    approver_fa: str | None = None


class ActionResultRecordSchema(BaseModel):
    actual_result_value: Decimal
    measurement_period_start: date | None = None
    measurement_period_end: date | None = None
    control_group_kpi_change: Decimal | None = Field(
        default=None,
        description="تغییر KPI در گروه/دوره مقایسه بدون اقدام — برای سنجش سهم عوامل (اختیاری)",
    )


class VarianceSchema(BaseModel):
    variance_absolute: Decimal | None = None
    variance_pct: Decimal | None = None
    exceeds_learning_threshold: bool | None = None


class AttributionSchema(BaseModel):
    attribution_level: str
    estimated_incremental_effect: Decimal | None
    explanation_fa: str


class ActionResultResponseSchema(BaseModel):
    action: ActionResponseSchema
    variance: VarianceSchema | None = None
    attribution: AttributionSchema | None = None
    learning_candidate_created: bool = False
