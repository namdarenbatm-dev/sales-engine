import uuid
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.domain.action.models import Action
from app.domain.action.schemas import ActionCreateSchema, ActionResultRecordSchema, ActionStatusUpdateSchema
from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.attribution import AttributionInput, evaluate_attribution
from app.domain.analytics.formulas.variance import VarianceInput, calculate_expected_vs_actual_variance
from app.domain.audit.service import log_event
from app.domain.learning.service import create_learning_candidate


def create_action(session: Session, tenant_id: str, payload: ActionCreateSchema) -> Action:
    action = Action(
        tenant_id=tenant_id,
        problem_id=payload.problem_id,
        source_execution_id=payload.source_execution_id,
        option_code=payload.option_code,
        action_type_fa=payload.action_type_fa,
        description_fa=payload.description_fa,
        owner_fa=payload.owner_fa,
        organizational_unit_fa=payload.organizational_unit_fa,
        start_date=payload.start_date,
        deadline=payload.deadline,
        kpi_fa=payload.kpi_fa,
        baseline_value=payload.baseline_value,
        target_value=payload.target_value,
        execution_cost=payload.execution_cost,
        risk_fa=payload.risk_fa,
        expected_result_value=payload.expected_result_value,
        source_fa=payload.source_fa,
        change_history=[
            {"at": datetime.now(timezone.utc).isoformat(), "event": "CREATED", "by": payload.owner_fa}
        ],
    )
    session.add(action)
    session.flush()
    log_event(
        session, tenant_id=tenant_id, event_type="ACTION_CREATED",
        payload={"action_id": str(action.id), "action_type_fa": action.action_type_fa},
        notes_fa="اقدام جدید ثبت شد.",
    )
    return action


def get_action(session: Session, tenant_id: str, action_id: uuid.UUID) -> Action | None:
    return session.query(Action).filter(Action.id == action_id, Action.tenant_id == tenant_id).one_or_none()


def update_action_status(
    session: Session, tenant_id: str, action: Action, payload: ActionStatusUpdateSchema
) -> Action:
    previous_status = action.status
    action.status = payload.new_status
    if payload.approver_fa:
        action.approver_fa = payload.approver_fa
    history = list(action.change_history or [])
    history.append(
        {
            "at": datetime.now(timezone.utc).isoformat(),
            "event": "STATUS_CHANGED",
            "from": previous_status.value if previous_status else None,
            "to": payload.new_status.value,
            "reason_fa": payload.reason_fa,
            "by": payload.actor_fa,
        }
    )
    action.change_history = history
    session.add(action)
    session.flush()
    log_event(
        session, tenant_id=tenant_id, event_type="ACTION_STATUS_CHANGED",
        payload={"action_id": str(action.id), "from": previous_status.value if previous_status else None,
                  "to": payload.new_status.value},
        notes_fa=payload.reason_fa,
    )
    return action


def record_action_result(
    session: Session, tenant_id: str, action: Action, payload: ActionResultRecordSchema
):
    action.actual_result_value = payload.actual_result_value
    action.measurement_period_start = payload.measurement_period_start
    action.measurement_period_end = payload.measurement_period_end
    history = list(action.change_history or [])
    history.append(
        {
            "at": datetime.now(timezone.utc).isoformat(),
            "event": "RESULT_RECORDED",
            "actual_result_value": str(payload.actual_result_value),
        }
    )
    action.change_history = history
    session.add(action)
    session.flush()
    log_event(
        session, tenant_id=tenant_id, event_type="ACTION_RESULT_RECORDED",
        payload={"action_id": str(action.id), "actual_result_value": str(payload.actual_result_value)},
    )

    variance_result = None
    learning_candidate_created = False
    if action.expected_result_value is not None:
        try:
            variance_result = calculate_expected_vs_actual_variance(
                VarianceInput(
                    expected_value=action.expected_result_value, actual_value=action.actual_result_value
                )
            )
        except InsufficientEvidenceError:
            variance_result = None

        if variance_result and variance_result.exceeds_learning_threshold:
            create_learning_candidate(
                session, tenant_id=tenant_id, source_action_id=action.id, model_code=None,
                variance_pct=variance_result.variance_pct,
                hypothesis_fa=(
                    f"نتیجه واقعی اقدام «{action.action_type_fa}» با انحراف "
                    f"{variance_result.variance_pct} نسبت به مقدار مورد انتظار متفاوت بود؛ "
                    "این ممکن است نشانه نیاز به بازبینی فرض‌های مدل مرتبط باشد."
                ),
            )
            learning_candidate_created = True

    attribution_result = None
    if payload.control_group_kpi_change is not None and action.baseline_value is not None:
        actual_kpi_change = action.actual_result_value - action.baseline_value
        attribution_result = evaluate_attribution(
            AttributionInput(
                actual_kpi_change=actual_kpi_change,
                control_group_kpi_change=payload.control_group_kpi_change,
            )
        )
    elif action.baseline_value is not None:
        attribution_result = evaluate_attribution(
            AttributionInput(
                actual_kpi_change=action.actual_result_value - action.baseline_value,
                control_group_kpi_change=None,
            )
        )

    return action, variance_result, attribution_result, learning_candidate_created
