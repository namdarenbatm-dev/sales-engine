import uuid
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class RoleCreateSchema(BaseModel):
    code: str = Field(..., description="مثلاً sales_manager، finance_manager")
    name_fa: str
    permission_codes: list[str] = Field(default_factory=list)


class RoleResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    code: str
    name_fa: str
    permission_codes: list[str]

    class Config:
        from_attributes = True


class UserCreateSchema(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)
    display_name_fa: str
    role_id: uuid.UUID | None = None


class UserResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    email: EmailStr
    display_name_fa: str
    role_id: uuid.UUID | None
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class LoginRequestSchema(BaseModel):
    email: EmailStr
    password: str


class TokenResponseSchema(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in_seconds: int
