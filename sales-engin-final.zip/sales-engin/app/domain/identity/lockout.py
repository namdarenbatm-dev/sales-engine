"""
سیاست قفل حساب پس از تلاش‌های ناموفق ورود — قانون معماری ۴۲ (سخت‌سازی امنیتی).

منطق خالص و بدون وابستگی به دیتابیس/فریم‌ورک — تا مستقیماً در همین محیط قابل تأیید باشد.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

MAX_FAILED_ATTEMPTS = 5
LOCKOUT_DURATION_MINUTES = 15


@dataclass(frozen=True)
class LockoutState:
    failed_attempts: int
    locked_until: datetime | None


@dataclass(frozen=True)
class LoginAttemptDecision:
    allowed: bool
    reason_fa: str | None
    new_state: LockoutState


def check_can_attempt_login(state: LockoutState, now: datetime) -> LoginAttemptDecision:
    if state.locked_until is not None and now < state.locked_until:
        remaining_minutes = max(1, int((state.locked_until - now).total_seconds() // 60) + 1)
        return LoginAttemptDecision(
            allowed=False,
            reason_fa=f"حساب به‌دلیل تلاش‌های ناموفق قفل شده است؛ حدود {remaining_minutes} دقیقه دیگر دوباره تلاش کنید.",
            new_state=state,
        )
    return LoginAttemptDecision(allowed=True, reason_fa=None, new_state=state)


def record_failed_attempt(state: LockoutState, now: datetime) -> LockoutState:
    new_count = state.failed_attempts + 1
    locked_until = state.locked_until
    if new_count >= MAX_FAILED_ATTEMPTS:
        locked_until = now + timedelta(minutes=LOCKOUT_DURATION_MINUTES)
    return LockoutState(failed_attempts=new_count, locked_until=locked_until)


def record_successful_login(state: LockoutState) -> LockoutState:  # noqa: ARG001
    return LockoutState(failed_attempts=0, locked_until=None)
