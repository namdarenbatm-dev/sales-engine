"""
وابستگی RBAC — قانون معماری ۱۴: No Authorization → No Action.

این وابستگی برای اقدام‌های حساس/پرتأثیر استفاده می‌شود (فعلاً: تغییر وضعیت اقدام،
بازبینی کاندیدای یادگیری). سایر endpointهای این نسخه هنوز به این لایه مجهز نشده‌اند —
این یک محدودیت شناخته‌شده است، نه رفتار نهایی مطلوب.
"""

from dataclasses import dataclass

from fastapi import Header, HTTPException

from app.core.config import settings
from app.domain.identity.security import ExpiredTokenError, InvalidTokenError, decode_access_token


@dataclass(frozen=True)
class AuthenticatedPrincipal:
    user_id: str
    tenant_id: str
    email: str
    permissions: list[str]


def get_current_principal(
    authorization: str | None = Header(default=None),
) -> AuthenticatedPrincipal:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="توکن دسترسی ارسال نشده است.")

    token = authorization.split(" ", 1)[1].strip()
    try:
        payload = decode_access_token(token, secret=settings.jwt_secret_key)
    except ExpiredTokenError:
        raise HTTPException(status_code=401, detail="توکن منقضی شده است؛ دوباره وارد شوید.")
    except InvalidTokenError:
        raise HTTPException(status_code=401, detail="توکن نامعتبر است.")

    return AuthenticatedPrincipal(
        user_id=payload["sub"], tenant_id=payload["tenant_id"], email=payload["email"],
        permissions=payload.get("permissions", []),
    )


def require_permission(permission_code: str):
    def _dependency(
        authorization: str | None = Header(default=None),
        x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
    ) -> AuthenticatedPrincipal:
        principal = get_current_principal(authorization)
        if x_tenant_id and x_tenant_id.strip() != principal.tenant_id:
            raise HTTPException(
                status_code=403,
                detail="مستأجر توکن با مستأجر درخواست مطابقت ندارد.",
            )
        if permission_code not in principal.permissions:
            raise HTTPException(
                status_code=403,
                detail=f"دسترسی «{permission_code}» برای این کاربر مجاز نیست.",
            )
        return principal

    return _dependency
