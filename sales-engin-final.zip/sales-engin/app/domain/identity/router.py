from fastapi import APIRouter, Header, HTTPException

from app.core.database import get_session, require_tenant_id
from app.domain.identity.schemas import (
    LoginRequestSchema,
    RoleCreateSchema,
    RoleResponseSchema,
    TokenResponseSchema,
    UserCreateSchema,
    UserResponseSchema,
)
from app.domain.identity.service import (
    AccountLockedError,
    AuthenticationError,
    authenticate_user,
    create_role,
    create_user,
    get_user_role_permissions,
    issue_token_for_user,
)
from app.core.config import settings

router = APIRouter(prefix="/api/v1/identity", tags=["identity"])


@router.post("/roles", response_model=RoleResponseSchema)
def create_role_endpoint(
    payload: RoleCreateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> RoleResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        role = create_role(session, tenant_id, payload)
        session.flush()
        return RoleResponseSchema.model_validate(role)


@router.post("/users", response_model=UserResponseSchema)
def create_user_endpoint(
    payload: UserCreateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> UserResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        try:
            user = create_user(session, tenant_id, payload)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        session.flush()
        return UserResponseSchema.model_validate(user)


@router.post("/auth/login", response_model=TokenResponseSchema)
def login_endpoint(
    payload: LoginRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> TokenResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        try:
            user = authenticate_user(session, tenant_id, payload.email, payload.password)
        except AccountLockedError as exc:
            raise HTTPException(status_code=423, detail=str(exc))
        except AuthenticationError as exc:
            raise HTTPException(status_code=401, detail=str(exc))
        permissions = get_user_role_permissions(session, user)
        token = issue_token_for_user(user, permissions)
        return TokenResponseSchema(
            access_token=token, expires_in_seconds=settings.access_token_expires_seconds
        )
