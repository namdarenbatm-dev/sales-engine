import uuid
from datetime import datetime, timezone

from sqlalchemy.orm import Session

from app.core.config import settings
from app.domain.audit.service import log_event
from app.domain.identity.lockout import (
    LockoutState,
    check_can_attempt_login,
    record_failed_attempt,
    record_successful_login,
)
from app.domain.identity.models import Role, User
from app.domain.identity.schemas import RoleCreateSchema, UserCreateSchema
from app.domain.identity.security import create_access_token, hash_password, verify_password


class AuthenticationError(Exception):
    pass


class AccountLockedError(Exception):
    pass


def create_role(session: Session, tenant_id: str, payload: RoleCreateSchema) -> Role:
    role = Role(
        tenant_id=tenant_id, code=payload.code, name_fa=payload.name_fa,
        permission_codes=payload.permission_codes,
    )
    session.add(role)
    session.flush()
    log_event(session, tenant_id=tenant_id, event_type="ROLE_CREATED",
               payload={"role_id": str(role.id), "code": role.code})
    return role


def create_user(session: Session, tenant_id: str, payload: UserCreateSchema) -> User:
    existing = (
        session.query(User)
        .filter(User.tenant_id == tenant_id, User.email == payload.email)
        .one_or_none()
    )
    if existing is not None:
        raise ValueError("کاربری با این ایمیل در این مستأجر از قبل وجود دارد.")

    user = User(
        tenant_id=tenant_id, email=payload.email, hashed_password=hash_password(payload.password),
        display_name_fa=payload.display_name_fa, role_id=payload.role_id,
    )
    session.add(user)
    session.flush()
    log_event(session, tenant_id=tenant_id, event_type="USER_CREATED",
               payload={"user_id": str(user.id), "email": user.email})
    return user


def authenticate_user(session: Session, tenant_id: str, email: str, password: str) -> User:
    user = (
        session.query(User)
        .filter(User.tenant_id == tenant_id, User.email == email, User.is_active.is_(True))
        .one_or_none()
    )
    if user is None:
        raise AuthenticationError("ایمیل یا رمز عبور نادرست است.")

    now = datetime.now(timezone.utc)
    state = LockoutState(failed_attempts=user.failed_login_attempts, locked_until=user.locked_until)
    decision = check_can_attempt_login(state, now)
    if not decision.allowed:
        log_event(session, tenant_id=tenant_id, event_type="LOGIN_BLOCKED_LOCKOUT",
                   payload={"user_id": str(user.id)}, notes_fa=decision.reason_fa)
        raise AccountLockedError(decision.reason_fa)

    if not verify_password(password, user.hashed_password):
        new_state = record_failed_attempt(state, now)
        user.failed_login_attempts = new_state.failed_attempts
        user.locked_until = new_state.locked_until
        session.add(user)
        session.flush()
        log_event(session, tenant_id=tenant_id, event_type="LOGIN_FAILED",
                   payload={"user_id": str(user.id), "failed_attempts": new_state.failed_attempts})
        raise AuthenticationError("ایمیل یا رمز عبور نادرست است.")

    reset_state = record_successful_login(state)
    user.failed_login_attempts = reset_state.failed_attempts
    user.locked_until = reset_state.locked_until
    session.add(user)
    session.flush()
    log_event(session, tenant_id=tenant_id, event_type="LOGIN_SUCCEEDED", payload={"user_id": str(user.id)})
    return user


def get_user_role_permissions(session: Session, user: User) -> list[str]:
    if user.role_id is None:
        return []
    role = session.query(Role).filter(Role.id == user.role_id).one_or_none()
    return list(role.permission_codes) if role else []


def issue_token_for_user(user: User, permission_codes: list[str]) -> str:
    return create_access_token(
        claims={
            "sub": str(user.id), "tenant_id": user.tenant_id, "email": user.email,
            "permissions": permission_codes,
        },
        secret=settings.jwt_secret_key,
        expires_in_seconds=settings.access_token_expires_seconds,
    )
