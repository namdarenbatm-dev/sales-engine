"""
هویت و امنیت — رمزنگاری رمز عبور (PBKDF2-HMAC-SHA256) و توکن دسترسی حداقلی سازگار با JWT
(HS256)، هر دو فقط با کتابخانه استاندارد پایتون — بدون وابستگی خارجی رمزنگاری.

توجه صادقانه: این یک پیاده‌سازی حداقلی Zero Trust/Secrets Management کامل بخش ۴۲ سند
معماری نیست. کلید امضای توکن از تنظیمات محیطی خوانده می‌شود و باید در استقرار واقعی
از یک مدیریت اسرار واقعی (مثل Vault/KMS) تأمین شود، نه از یک متغیر ساده در فایل .env.
"""

import base64
import hashlib
import hmac
import json
import secrets
import time
from typing import Any

_PBKDF2_ITERATIONS = 260_000
_PBKDF2_ALGORITHM = "pbkdf2_sha256"


def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), _PBKDF2_ITERATIONS)
    return f"{_PBKDF2_ALGORITHM}${_PBKDF2_ITERATIONS}${salt}${derived.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algorithm, iterations_str, salt, hash_hex = stored_hash.split("$")
    except ValueError:
        return False
    if algorithm != _PBKDF2_ALGORITHM:
        return False
    iterations = int(iterations_str)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), iterations)
    return hmac.compare_digest(derived.hex(), hash_hex)


class InvalidTokenError(Exception):
    pass


class ExpiredTokenError(Exception):
    pass


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    padding = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + padding)


def create_access_token(claims: dict[str, Any], secret: str, expires_in_seconds: int = 3600) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    payload = {**claims, "iat": now, "exp": now + expires_in_seconds}

    header_b64 = _b64url_encode(json.dumps(header, separators=(",", ":")).encode("utf-8"))
    payload_b64 = _b64url_encode(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    signature_b64 = _b64url_encode(signature)

    return f"{header_b64}.{payload_b64}.{signature_b64}"


def decode_access_token(token: str, secret: str) -> dict[str, Any]:
    try:
        header_b64, payload_b64, signature_b64 = token.split(".")
    except ValueError:
        raise InvalidTokenError("قالب توکن نامعتبر است.")

    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    expected_signature = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    actual_signature = _b64url_decode(signature_b64)

    if not hmac.compare_digest(expected_signature, actual_signature):
        raise InvalidTokenError("امضای توکن معتبر نیست.")

    payload = json.loads(_b64url_decode(payload_b64))
    if payload.get("exp") is not None and int(time.time()) >= payload["exp"]:
        raise ExpiredTokenError("توکن منقضی شده است.")

    return payload
