import uuid

from sqlalchemy.orm import Session

from app.domain.audit.service import log_event
from app.domain.evidence.models import Claim, FormulaRegistryEntry, Source
from app.domain.evidence.schemas import (
    ClaimCreateSchema,
    FormulaRegistryEntryCreateSchema,
    SourceCreateSchema,
)
from app.domain.evidence.search import ClaimRecord, keyword_search


def create_source(session: Session, tenant_id: str, payload: SourceCreateSchema) -> Source:
    source = Source(
        tenant_id=tenant_id, title_fa=payload.title_fa, author_fa=payload.author_fa,
        publication_year=payload.publication_year, source_type_fa=payload.source_type_fa,
        reference_fa=payload.reference_fa,
    )
    session.add(source)
    session.flush()
    log_event(session, tenant_id=tenant_id, event_type="EVIDENCE_SOURCE_CREATED",
               payload={"source_id": str(source.id), "title_fa": source.title_fa})
    return source


def create_claim(session: Session, tenant_id: str, payload: ClaimCreateSchema) -> Claim:
    claim = Claim(
        tenant_id=tenant_id, source_id=payload.source_id, claim_text_fa=payload.claim_text_fa,
        evidence_level_fa=payload.evidence_level_fa, related_model_code=payload.related_model_code,
    )
    session.add(claim)
    session.flush()
    log_event(session, tenant_id=tenant_id, event_type="EVIDENCE_CLAIM_CREATED",
               payload={"claim_id": str(claim.id), "source_id": str(claim.source_id)})
    return claim


def create_formula_registry_entry(
    session: Session, tenant_id: str, payload: FormulaRegistryEntryCreateSchema
) -> FormulaRegistryEntry:
    entry = FormulaRegistryEntry(
        tenant_id=tenant_id, formula_code=payload.formula_code, version=payload.version,
        description_fa=payload.description_fa, primary_source_id=payload.primary_source_id,
    )
    session.add(entry)
    session.flush()
    log_event(session, tenant_id=tenant_id, event_type="FORMULA_REGISTRY_ENTRY_CREATED",
               payload={"formula_code": entry.formula_code, "version": entry.version})
    return entry


def search_claims(session: Session, tenant_id: str, query_fa: str, top_n: int = 10):
    rows = (
        session.query(Claim, Source)
        .join(Source, Claim.source_id == Source.id)
        .filter(Claim.tenant_id == tenant_id)
        .all()
    )
    records = [
        ClaimRecord(
            claim_id=str(claim.id), claim_text_fa=claim.claim_text_fa,
            source_title_fa=source.title_fa, evidence_level_fa=claim.evidence_level_fa,
        )
        for claim, source in rows
    ]
    return keyword_search(query_fa, records, top_n=top_n)
