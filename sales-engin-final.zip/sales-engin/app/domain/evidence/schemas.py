import uuid
from datetime import datetime

from pydantic import BaseModel, Field


class SourceCreateSchema(BaseModel):
    title_fa: str
    author_fa: str | None = None
    publication_year: int | None = None
    source_type_fa: str = "دانش سازمانی"
    reference_fa: str | None = None


class SourceResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    title_fa: str
    author_fa: str | None
    publication_year: int | None
    source_type_fa: str
    reference_fa: str | None
    created_at: datetime

    class Config:
        from_attributes = True


class ClaimCreateSchema(BaseModel):
    source_id: uuid.UUID
    claim_text_fa: str
    evidence_level_fa: str = "متوسط"
    related_model_code: str | None = None


class ClaimResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    source_id: uuid.UUID
    claim_text_fa: str
    evidence_level_fa: str
    related_model_code: str | None
    created_at: datetime

    class Config:
        from_attributes = True


class EvidenceSearchResultItemSchema(BaseModel):
    claim_id: uuid.UUID
    claim_text_fa: str
    source_title_fa: str
    evidence_level_fa: str
    score: int


class EvidenceSearchResponseSchema(BaseModel):
    query_fa: str
    results: list[EvidenceSearchResultItemSchema]
    disclaimer_fa: str = Field(
        default=(
            "این جستجو بر پایه تطبیق کلیدواژه ساده است، نه بازیابی معنایی پیشرفته؛ نتایج فقط "
            "استناد به ادعاهای ثبت‌شده در سیستم هستند، نه تولید ادعای جدید."
        )
    )


class FormulaRegistryEntryCreateSchema(BaseModel):
    formula_code: str
    version: str
    description_fa: str
    primary_source_id: uuid.UUID | None = None


class FormulaRegistryEntryResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    formula_code: str
    version: str
    description_fa: str
    primary_source_id: uuid.UUID | None
    created_at: datetime

    class Config:
        from_attributes = True
