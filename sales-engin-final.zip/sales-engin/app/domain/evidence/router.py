from fastapi import APIRouter, Depends, Header, Query

from app.core.database import get_session, require_tenant_id
from app.domain.identity.dependencies import require_permission
from app.domain.evidence.schemas import (
    ClaimCreateSchema,
    ClaimResponseSchema,
    EvidenceSearchResponseSchema,
    EvidenceSearchResultItemSchema,
    FormulaRegistryEntryCreateSchema,
    FormulaRegistryEntryResponseSchema,
    SourceCreateSchema,
    SourceResponseSchema,
)
from app.domain.evidence.service import (
    create_claim,
    create_formula_registry_entry,
    create_source,
    search_claims,
)

router = APIRouter(prefix="/api/v1/evidence", tags=["evidence"])


@router.post("/sources", response_model=SourceResponseSchema)
def create_source_endpoint(
    payload: SourceCreateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> SourceResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        source = create_source(session, tenant_id, payload)
        session.flush()
        return SourceResponseSchema.model_validate(source)


@router.post("/claims", response_model=ClaimResponseSchema)
def create_claim_endpoint(
    payload: ClaimCreateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ClaimResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        claim = create_claim(session, tenant_id, payload)
        session.flush()
        return ClaimResponseSchema.model_validate(claim)


@router.post("/formula-registry", response_model=FormulaRegistryEntryResponseSchema)
def create_formula_registry_entry_endpoint(
    payload: FormulaRegistryEntryCreateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
    principal=Depends(require_permission("evidence:manage-formula-registry")),
) -> FormulaRegistryEntryResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        entry = create_formula_registry_entry(session, tenant_id, payload)
        session.flush()
        return FormulaRegistryEntryResponseSchema.model_validate(entry)


@router.get("/search", response_model=EvidenceSearchResponseSchema)
def search_evidence_endpoint(
    q: str = Query(..., description="عبارت جستجو به فارسی"),
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> EvidenceSearchResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        scored = search_claims(session, tenant_id, q)
        return EvidenceSearchResponseSchema(
            query_fa=q,
            results=[
                EvidenceSearchResultItemSchema(
                    claim_id=sc.claim.claim_id, claim_text_fa=sc.claim.claim_text_fa,
                    source_title_fa=sc.claim.source_title_fa,
                    evidence_level_fa=sc.claim.evidence_level_fa, score=sc.score,
                )
                for sc in scored
            ],
        )
