import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Source(Base):
    """
    منبع علمی/سازمانی — بخش اول از زنجیره شواهد آکادمیک (Academic Evidence Trace).
    """

    __tablename__ = "sources"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    title_fa: Mapped[str] = mapped_column(String(256), nullable=False)
    author_fa: Mapped[str] = mapped_column(String(256), nullable=True)
    publication_year: Mapped[int] = mapped_column(Integer, nullable=True)
    source_type_fa: Mapped[str] = mapped_column(
        String(64), nullable=False, default="دانش سازمانی"
    )  # مثلاً: مقاله علمی، کتاب مدیریتی، گزارش صنعتی، دانش سازمانی
    reference_fa: Mapped[str] = mapped_column(Text, nullable=True)  # لینک یا ارجاع کامل
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )


class Claim(Base):
    """
    ادعا/گزاره مستخرج از یک منبع، با سطح شواهد مشخص.
    قانون معماری ۸: Citation is not Data Evidence — یک ادعا با منبع، جایگزین داده واقعی
    برای محاسبات مالی نیست؛ صرفاً پشتوانه نظری/تجربی یک مدل یا فرض را نشان می‌دهد.
    """

    __tablename__ = "claims"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    source_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("sources.id"), nullable=False
    )
    claim_text_fa: Mapped[str] = mapped_column(Text, nullable=False)
    evidence_level_fa: Mapped[str] = mapped_column(
        String(32), nullable=False, default="متوسط"
    )  # قوی / متوسط / ضعیف
    related_model_code: Mapped[str] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )


class FormulaRegistryEntry(Base):
    """
    ثبت رسمی فرمول — بخش دوم از سیستم شواهد، مستقل از زنجیره تصمیم.
    """

    __tablename__ = "formula_registry_entries"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    formula_code: Mapped[str] = mapped_column(String(64), nullable=False)
    version: Mapped[str] = mapped_column(String(32), nullable=False)
    description_fa: Mapped[str] = mapped_column(Text, nullable=False)
    primary_source_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("sources.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
