"""
جستجوی شواهد — نسخه ساده‌شده.

توجه صادقانه: این پیاده‌سازی یک بازیابی ترکیبی واقعی (کلیدواژه + معنایی + گراف) طبق بخش
۳۸ سند معماری نیست؛ صرفاً تطبیق کلیدواژه‌ای ساده روی متن ادعاها (claims) است. هیچ embedding
یا مدل زبانی در تولید نتایج جستجو دخالت ندارد — نتایج، بازیابی قطعی از داده‌های ثبت‌شده‌اند،
نه تولیدشده. این با قانون ۸ (Citation is not Data Evidence) سازگار است: خروجی صرفاً استناد
به رکوردهای موجود است، نه تولید ادعای جدید.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class ClaimRecord:
    claim_id: str
    claim_text_fa: str
    source_title_fa: str
    evidence_level_fa: str


@dataclass(frozen=True)
class ScoredClaim:
    claim: ClaimRecord
    score: int


_STOPWORDS_FA = {
    "با", "در", "از", "را", "به", "و", "که", "این", "آن", "برای", "بر", "تا",
    "یا", "هم", "نیز", "پس", "بی", "چه", "می", "است", "بود", "شد",
}


def _tokenize_fa(text: str) -> set[str]:
    # جداسازی ساده بر اساس فاصله + حذف حروف ربط پرتکرار — بدون ریشه‌یابی کامل (ساده‌سازی آگاهانه)
    tokens = {token.strip() for token in text.split() if token.strip()}
    return tokens - _STOPWORDS_FA


def keyword_search(query_fa: str, claims: list[ClaimRecord], top_n: int = 10) -> list[ScoredClaim]:
    query_tokens = _tokenize_fa(query_fa)
    if not query_tokens:
        return []

    scored: list[ScoredClaim] = []
    for claim in claims:
        claim_tokens = _tokenize_fa(claim.claim_text_fa) | _tokenize_fa(claim.source_title_fa)
        overlap = len(query_tokens & claim_tokens)
        if overlap > 0:
            scored.append(ScoredClaim(claim=claim, score=overlap))

    scored.sort(key=lambda sc: sc.score, reverse=True)
    return scored[:top_n]
