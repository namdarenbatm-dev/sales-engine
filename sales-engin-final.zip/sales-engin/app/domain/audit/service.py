from datetime import datetime, timezone
from typing import Any

from sqlalchemy.orm import Session

from app.domain.audit.models import AuditEvent


def log_event(
    session: Session,
    *,
    tenant_id: str,
    event_type: str,
    payload: dict[str, Any],
    execution_id: str | None = None,
    actor: str = "system",
    notes_fa: str | None = None,
) -> AuditEvent:
    """
    ثبت یک رویداد ممیزی. این تابع هرگز رویداد موجود را ویرایش نمی‌کند — فقط رکورد جدید می‌سازد.
    """
    event = AuditEvent(
        tenant_id=tenant_id,
        event_type=event_type,
        execution_id=execution_id,
        actor=actor,
        payload=payload,
        created_at=datetime.now(timezone.utc),
        notes_fa=notes_fa,
    )
    session.add(event)
    session.flush()
    return event
