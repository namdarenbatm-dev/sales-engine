"""
موتور تحلیلی (Analytical Engine) — هسته قیمت‌گذاری.

قانون معماری ۱۶: No Reproducibility → No High-Impact Production Result.
هر اجرای محاسبه یک execution_id یکتا و یک CalculationTrace کامل تولید می‌کند که شامل
نسخه فرمول، نسخه موتور، و تمام ورودی‌های خام است — تا هر نتیجه در آینده قابل بازتولید باشد.
"""

import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import (
    FORMULA_VERSION,
    ContributionMarginInput,
    EffectivePriceInput,
    PriceFloorInput,
    calculate_contribution_margin,
    calculate_effective_price,
    calculate_price_floor,
)

ENGINE_VERSION = "pricing-core-engine-1.0.0"


@dataclass(frozen=True)
class PricingCoreRequest:
    tenant_id: str
    currency: str
    nominal_unit_price: Decimal
    paid_units: Decimal
    total_discounts: Decimal
    total_rebates: Decimal
    foc_units: Decimal
    variable_cost_per_unit: Decimal
    minimum_required_margin_pct: Decimal
    proposed_price: Decimal | None = None
    problem_id: str | None = None


@dataclass(frozen=True)
class CalculationTrace:
    execution_id: str
    engine_version: str
    formula_version: str
    executed_at: str
    tenant_id: str
    raw_inputs: dict[str, Any]
    problem_id: str | None = None


@dataclass(frozen=True)
class BlockedResult:
    status: str = field(default="BLOCKED", init=False)
    headline_fa: str = field(init=False)
    explanation_fa: str = ""
    missing_fields: list[str] = field(default_factory=list)
    trace: CalculationTrace | None = None

    def __post_init__(self):
        object.__setattr__(self, "headline_fa", InsufficientEvidenceError.HEADLINE_FA)


@dataclass(frozen=True)
class DecisionOption:
    option_code: str
    label_fa: str
    rationale_fa: str
    risk_fa: str | None
    supported_by_evidence: bool


@dataclass(frozen=True)
class PricingCoreResult:
    status: str
    currency: str
    effective_unit_price: Decimal
    contribution_margin_per_unit: Decimal
    contribution_margin_pct: Decimal | None
    price_floor_effective_unit_price: Decimal
    decision_options: list[DecisionOption]
    trace: CalculationTrace


def _serializable_inputs(request: PricingCoreRequest) -> dict[str, Any]:
    raw = asdict(request)
    return {k: (str(v) if isinstance(v, Decimal) else v) for k, v in raw.items()}


def _build_trace(request: PricingCoreRequest) -> CalculationTrace:
    return CalculationTrace(
        execution_id=str(uuid.uuid4()),
        engine_version=ENGINE_VERSION,
        formula_version=FORMULA_VERSION,
        executed_at=datetime.now(timezone.utc).isoformat(),
        tenant_id=request.tenant_id,
        raw_inputs=_serializable_inputs(request),
        problem_id=request.problem_id,
    )


def _build_decision_options(
    request: PricingCoreRequest,
    price_floor: Decimal,
    contribution_margin_pct: Decimal | None,
) -> list[DecisionOption]:
    """
    تولید گزینه‌های تصمیم — بدون اعلام «بهترین گزینه» (قانون ۲۰: تصمیم نهایی با انسان است).
    """
    options: list[DecisionOption] = []

    if request.proposed_price is None:
        options.append(
            DecisionOption(
                option_code="NO_PROPOSED_PRICE",
                label_fa="قیمت پیشنهادی مشخص نشده است",
                rationale_fa="کف قیمت و حاشیه سود محاسبه شد، اما قیمتی برای مقایسه پیشنهاد نشده است.",
                risk_fa=None,
                supported_by_evidence=True,
            )
        )
        return options

    if request.proposed_price >= price_floor:
        options.append(
            DecisionOption(
                option_code="APPROVE_AT_PROPOSED_PRICE",
                label_fa="تأیید قیمت پیشنهادی",
                rationale_fa=(
                    f"قیمت پیشنهادی ({request.proposed_price}) بالاتر یا برابر کف قیمت "
                    f"({price_floor}) است."
                ),
                risk_fa=None,
                supported_by_evidence=True,
            )
        )
    else:
        gap = price_floor - request.proposed_price
        options.append(
            DecisionOption(
                option_code="REJECT_BELOW_FLOOR",
                label_fa="رد قیمت پیشنهادی (زیر کف قیمت)",
                rationale_fa=(
                    f"قیمت پیشنهادی ({request.proposed_price}) به‌اندازه {gap} واحد پول "
                    f"زیر کف قیمت ({price_floor}) است."
                ),
                risk_fa="در صورت تأیید، حاشیه سود مشارکت کمتر از حداقل سیاستی تعیین‌شده خواهد بود.",
                supported_by_evidence=True,
            )
        )
        options.append(
            DecisionOption(
                option_code="COUNTER_OFFER_AT_FLOOR",
                label_fa="پیشنهاد متقابل در سطح کف قیمت",
                rationale_fa=f"پیشنهاد قیمت جدید در سطح کف قیمت محاسبه‌شده ({price_floor}).",
                risk_fa="ممکن است طرف مقابل این پیشنهاد را نپذیرد (اثر بر نرخ تبدیل بررسی نشده است).",
                supported_by_evidence=True,
            )
        )
        options.append(
            DecisionOption(
                option_code="REQUIRE_COUNTERPART_COMMITMENT",
                label_fa="تأیید مشروط به تعهد متقابل",
                rationale_fa=(
                    "تأیید قیمت پیشنهادی صرفاً در صورت دریافت یک تعهد جبرانی از طرف مقابل "
                    "(مثلاً افزایش حجم خرید یا تسریع پرداخت) — این گزینه نیازمند ورودی مذاکره است "
                    "که در این قطعه هنوز پیاده‌سازی نشده."
                ),
                risk_fa=None,
                supported_by_evidence=False,
            )
        )

    return options


def run_pricing_core(request: PricingCoreRequest) -> PricingCoreResult | BlockedResult:
    trace = _build_trace(request)

    try:
        effective_price_result = calculate_effective_price(
            EffectivePriceInput(
                currency=request.currency,
                nominal_unit_price=request.nominal_unit_price,
                paid_units=request.paid_units,
                total_discounts=request.total_discounts,
                total_rebates=request.total_rebates,
                foc_units=request.foc_units,
            )
        )

        contribution_margin_result = calculate_contribution_margin(
            ContributionMarginInput(
                currency=effective_price_result.currency,
                effective_unit_price=effective_price_result.effective_unit_price,
                variable_cost_per_unit=request.variable_cost_per_unit,
            )
        )

        price_floor_result = calculate_price_floor(
            PriceFloorInput(
                currency=effective_price_result.currency,
                variable_cost_per_unit=request.variable_cost_per_unit,
                minimum_required_margin_pct=request.minimum_required_margin_pct,
            )
        )

    except InsufficientEvidenceError as exc:
        return BlockedResult(
            explanation_fa=exc.explanation_fa,
            missing_fields=exc.missing_fields,
            trace=trace,
        )

    decision_options = _build_decision_options(
        request=request,
        price_floor=price_floor_result.price_floor_effective_unit_price,
        contribution_margin_pct=contribution_margin_result.contribution_margin_pct,
    )

    return PricingCoreResult(
        status="OK",
        currency=effective_price_result.currency,
        effective_unit_price=effective_price_result.effective_unit_price,
        contribution_margin_per_unit=contribution_margin_result.contribution_margin_per_unit,
        contribution_margin_pct=contribution_margin_result.contribution_margin_pct,
        price_floor_effective_unit_price=price_floor_result.price_floor_effective_unit_price,
        decision_options=decision_options,
        trace=trace,
    )
