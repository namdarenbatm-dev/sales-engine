class InsufficientEvidenceError(Exception):
    """
    محافظ دقت کاذب (False Precision Guard) — قانون معماری ۱۲:
    No Data → No False Precision.

    این خطا هرگز نباید با یک عدد جایگزین (مثلاً صفر یا میانگین فرضی) پوشانده شود.
    پیام کاربرپسند فارسی، همراه با فهرست دقیق فیلدهای ناقص/نامعتبر، در attribute ها موجود است.
    """

    HEADLINE_FA = "شواهد ناکافی برای محاسبه قابل اتکا"

    def __init__(self, missing_fields: list[str], explanation_fa: str):
        self.missing_fields = missing_fields
        self.explanation_fa = explanation_fa
        super().__init__(f"{self.HEADLINE_FA}: {explanation_fa} (fields={missing_fields})")
