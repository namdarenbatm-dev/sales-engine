"""
هسته قیمت‌گذاری — قانون معماری ۲: LLM محاسبه نمی‌کند.

همه محاسبات این فایل با decimal.Decimal انجام می‌شود (نه float)، تا اعداد مالی
دچار خطای گرد کردن باینری نشوند. هیچ مقدار مالی معتبری در این فایل حدس زده نمی‌شود:
هر داده ناقص یا نامعتبر باعث بلاک‌شدن محاسبه (InsufficientEvidenceError) می‌شود.
"""

from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError

MONEY_QUANT = Decimal("0.01")
RATE_QUANT = Decimal("0.0001")

FORMULA_VERSION = "pricing-formulas-1.0.0"


def _q_money(value: Decimal) -> Decimal:
    return value.quantize(MONEY_QUANT, rounding=ROUND_HALF_UP)


def _q_rate(value: Decimal) -> Decimal:
    return value.quantize(RATE_QUANT, rounding=ROUND_HALF_UP)


@dataclass(frozen=True)
class EffectivePriceInput:
    currency: str
    nominal_unit_price: Decimal
    paid_units: Decimal
    total_discounts: Decimal
    total_rebates: Decimal
    foc_units: Decimal = Decimal("0")


@dataclass(frozen=True)
class EffectivePriceResult:
    currency: str
    effective_unit_price: Decimal
    net_revenue: Decimal
    total_delivered_units: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_effective_price(data: EffectivePriceInput) -> EffectivePriceResult:
    missing: list[str] = []

    if not data.currency or not data.currency.strip():
        missing.append("currency")
    if data.paid_units is None:
        missing.append("paid_units")
    elif data.paid_units <= 0:
        raise InsufficientEvidenceError(
            missing_fields=["paid_units"],
            explanation_fa="تعداد واحد فروخته‌شده باید بزرگ‌تر از صفر باشد؛ مقدار نامعتبر است.",
        )
    if data.nominal_unit_price is None:
        missing.append("nominal_unit_price")
    elif data.nominal_unit_price < 0:
        raise InsufficientEvidenceError(
            missing_fields=["nominal_unit_price"],
            explanation_fa="قیمت اسمی نمی‌تواند منفی باشد.",
        )
    if data.total_discounts is None:
        missing.append("total_discounts")
    elif data.total_discounts < 0:
        raise InsufficientEvidenceError(
            missing_fields=["total_discounts"],
            explanation_fa="جمع تخفیف نمی‌تواند منفی باشد.",
        )
    if data.total_rebates is None:
        missing.append("total_rebates")
    elif data.total_rebates < 0:
        raise InsufficientEvidenceError(
            missing_fields=["total_rebates"],
            explanation_fa="جمع پاداش فروش (rebate) نمی‌تواند منفی باشد.",
        )
    if data.foc_units is None or data.foc_units < 0:
        missing.append("foc_units")

    if missing:
        raise InsufficientEvidenceError(
            missing_fields=missing,
            explanation_fa=(
                "برای محاسبه قیمت مؤثر، اطلاعات زیر لازم است و در دسترس نیست یا نامعتبر است: "
                + "، ".join(missing)
            ),
        )

    total_delivered_units = data.paid_units + data.foc_units
    if total_delivered_units <= 0:
        raise InsufficientEvidenceError(
            missing_fields=["paid_units", "foc_units"],
            explanation_fa="جمع واحدهای تحویلی (فروخته‌شده + رایگان) باید بزرگ‌تر از صفر باشد.",
        )

    gross_revenue = data.nominal_unit_price * data.paid_units
    net_revenue = gross_revenue - data.total_discounts - data.total_rebates

    if net_revenue < 0:
        raise InsufficientEvidenceError(
            missing_fields=["total_discounts", "total_rebates"],
            explanation_fa=(
                "جمع تخفیف و پاداش فروش از کل فروش ناخالص بیشتر است؛ این وضعیت غیرمنطقی است و "
                "قبل از محاسبه باید توسط کاربر بررسی شود."
            ),
        )

    effective_unit_price = net_revenue / total_delivered_units

    return EffectivePriceResult(
        currency=data.currency.strip().upper(),
        effective_unit_price=_q_money(effective_unit_price),
        net_revenue=_q_money(net_revenue),
        total_delivered_units=total_delivered_units,
    )


@dataclass(frozen=True)
class ContributionMarginInput:
    currency: str
    effective_unit_price: Decimal
    variable_cost_per_unit: Decimal


@dataclass(frozen=True)
class ContributionMarginResult:
    currency: str
    contribution_margin_per_unit: Decimal
    contribution_margin_pct: Decimal | None
    formula_version: str = FORMULA_VERSION


def calculate_contribution_margin(data: ContributionMarginInput) -> ContributionMarginResult:
    missing: list[str] = []
    if data.currency is None or not data.currency.strip():
        missing.append("currency")
    if data.effective_unit_price is None:
        missing.append("effective_unit_price")
    if data.variable_cost_per_unit is None:
        missing.append("variable_cost_per_unit")
    elif data.variable_cost_per_unit < 0:
        raise InsufficientEvidenceError(
            missing_fields=["variable_cost_per_unit"],
            explanation_fa="هزینه متغیر هر واحد نمی‌تواند منفی باشد.",
        )

    if missing:
        raise InsufficientEvidenceError(
            missing_fields=missing,
            explanation_fa=(
                "برای محاسبه حاشیه سود مشارکت، اطلاعات زیر لازم است: " + "، ".join(missing)
            ),
        )

    cm_per_unit = data.effective_unit_price - data.variable_cost_per_unit
    cm_pct = (
        _q_rate(cm_per_unit / data.effective_unit_price)
        if data.effective_unit_price > 0
        else None
    )

    return ContributionMarginResult(
        currency=data.currency.strip().upper(),
        contribution_margin_per_unit=_q_money(cm_per_unit),
        contribution_margin_pct=cm_pct,
    )


@dataclass(frozen=True)
class PriceFloorInput:
    currency: str
    variable_cost_per_unit: Decimal
    minimum_required_margin_pct: Decimal  # e.g. 0.15 = 15%


@dataclass(frozen=True)
class PriceFloorResult:
    currency: str
    price_floor_effective_unit_price: Decimal
    minimum_required_margin_pct: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_price_floor(data: PriceFloorInput) -> PriceFloorResult:
    missing: list[str] = []
    if data.currency is None or not data.currency.strip():
        missing.append("currency")
    if data.variable_cost_per_unit is None:
        missing.append("variable_cost_per_unit")
    elif data.variable_cost_per_unit < 0:
        raise InsufficientEvidenceError(
            missing_fields=["variable_cost_per_unit"],
            explanation_fa="هزینه متغیر هر واحد نمی‌تواند منفی باشد.",
        )
    if data.minimum_required_margin_pct is None:
        missing.append("minimum_required_margin_pct")
    elif not (Decimal("0") <= data.minimum_required_margin_pct < Decimal("1")):
        raise InsufficientEvidenceError(
            missing_fields=["minimum_required_margin_pct"],
            explanation_fa=(
                "حداقل درصد حاشیه سود قابل‌قبول باید بین صفر و یک (مثلاً ۰٫۱۵ برای ۱۵٪) باشد؛ "
                "این مقدار یک «فرض سیاستی» است، نه یک واقعیت داده‌ای، و باید توسط مدیر فروش تأیید شود."
            ),
        )

    if missing:
        raise InsufficientEvidenceError(
            missing_fields=missing,
            explanation_fa="برای محاسبه کف قیمت، اطلاعات زیر لازم است: " + "، ".join(missing),
        )

    price_floor = data.variable_cost_per_unit / (Decimal("1") - data.minimum_required_margin_pct)

    return PriceFloorResult(
        currency=data.currency.strip().upper(),
        price_floor_effective_unit_price=_q_money(price_floor),
        minimum_required_margin_pct=data.minimum_required_margin_pct,
    )
