"""
موتور ارزش اقدام — قانون معماری ۳۲:
ارزش اقدام مورد انتظار = اثر اقتصادی مورد انتظار − هزینه اقدام − هزینه/اثر ریسک.
اگر داده کافی نباشد، عدد ساختگی تولید نمی‌شود.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_money


@dataclass(frozen=True)
class ActionValueInput:
    currency: str
    expected_economic_impact: Decimal
    action_cost: Decimal
    risk_cost: Decimal


@dataclass(frozen=True)
class ActionValueResult:
    currency: str
    action_value: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_action_value(data: ActionValueInput) -> ActionValueResult:
    missing: list[str] = []
    if not data.currency or not data.currency.strip():
        missing.append("currency")
    if data.expected_economic_impact is None:
        missing.append("expected_economic_impact")
    if data.action_cost is None:
        missing.append("action_cost")
    elif data.action_cost < 0:
        raise InsufficientEvidenceError(["action_cost"], "هزینه اقدام نمی‌تواند منفی باشد.")
    if data.risk_cost is None:
        missing.append("risk_cost")
    elif data.risk_cost < 0:
        raise InsufficientEvidenceError(["risk_cost"], "هزینه/اثر ریسک نمی‌تواند منفی باشد.")

    if missing:
        raise InsufficientEvidenceError(
            missing, "برای محاسبه ارزش اقدام، اطلاعات زیر لازم است: " + "، ".join(missing)
        )

    value = data.expected_economic_impact - data.action_cost - data.risk_cost
    return ActionValueResult(currency=data.currency.strip().upper(), action_value=_q_money(value))
