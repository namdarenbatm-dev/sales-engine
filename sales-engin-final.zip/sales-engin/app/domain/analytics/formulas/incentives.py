"""
پاداش فروش (Rebate) و کالای رایگان همراه خرید (FOC) — قانون معماری ۲: بدون محاسبه در LLM.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_money, _q_rate


@dataclass(frozen=True)
class RebateEquivalentInput:
    currency: str
    nominal_unit_price: Decimal
    rebate_rate_pct: Decimal  # مثلاً 0.05 برای پاداش فروش ۵٪ مشروط


@dataclass(frozen=True)
class RebateEquivalentResult:
    currency: str
    rebate_equivalent_unit_price: Decimal
    rebate_amount_per_unit: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_rebate_equivalent_price(data: RebateEquivalentInput) -> RebateEquivalentResult:
    missing: list[str] = []
    if not data.currency or not data.currency.strip():
        missing.append("currency")
    if data.nominal_unit_price is None:
        missing.append("nominal_unit_price")
    elif data.nominal_unit_price < 0:
        raise InsufficientEvidenceError(["nominal_unit_price"], "قیمت اسمی نمی‌تواند منفی باشد.")
    if data.rebate_rate_pct is None:
        missing.append("rebate_rate_pct")
    elif not (Decimal("0") <= data.rebate_rate_pct < Decimal("1")):
        raise InsufficientEvidenceError(
            ["rebate_rate_pct"],
            "نرخ پاداش فروش باید بین صفر و یک باشد (مثلاً ۰٫۰۵ برای ۵٪)؛ این مقدار یک شرط تجاری "
            "است و باید محقق‌شدنش (Unresolved Rebate Condition) پیش از محاسبه تأیید شود.",
        )

    if missing:
        raise InsufficientEvidenceError(
            missing, "برای محاسبه معادل پاداش فروش، اطلاعات زیر لازم است: " + "، ".join(missing)
        )

    rebate_amount = data.nominal_unit_price * data.rebate_rate_pct
    equivalent_price = data.nominal_unit_price - rebate_amount

    return RebateEquivalentResult(
        currency=data.currency.strip().upper(),
        rebate_equivalent_unit_price=_q_money(equivalent_price),
        rebate_amount_per_unit=_q_money(rebate_amount),
    )


@dataclass(frozen=True)
class FocEquivalentInput:
    currency: str
    purchased_units: Decimal
    unit_price: Decimal
    foc_units: Decimal


@dataclass(frozen=True)
class FocEquivalentResult:
    currency: str
    effective_unit_cost: Decimal
    total_delivered_units: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_foc_equivalent_unit_cost(data: FocEquivalentInput) -> FocEquivalentResult:
    missing: list[str] = []
    if not data.currency or not data.currency.strip():
        missing.append("currency")
    if data.purchased_units is None:
        missing.append("purchased_units")
    elif data.purchased_units <= 0:
        raise InsufficientEvidenceError(
            ["purchased_units"], "تعداد واحد خریداری‌شده باید بزرگ‌تر از صفر باشد."
        )
    if data.unit_price is None:
        missing.append("unit_price")
    elif data.unit_price < 0:
        raise InsufficientEvidenceError(["unit_price"], "قیمت واحد نمی‌تواند منفی باشد.")
    if data.foc_units is None or data.foc_units < 0:
        missing.append("foc_units")

    if missing:
        raise InsufficientEvidenceError(
            missing,
            "برای محاسبه هزینه مؤثر واحد در شرایط کالای رایگان همراه خرید، اطلاعات زیر لازم است: "
            + "، ".join(missing),
        )

    total_delivered = data.purchased_units + data.foc_units
    total_paid = data.purchased_units * data.unit_price
    effective_unit_cost = total_paid / total_delivered

    return FocEquivalentResult(
        currency=data.currency.strip().upper(),
        effective_unit_cost=_q_money(effective_unit_cost),
        total_delivered_units=total_delivered,
    )
