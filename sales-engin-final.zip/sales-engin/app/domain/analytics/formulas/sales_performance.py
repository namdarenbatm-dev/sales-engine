"""
عملکرد فروش: روند/رشد، قیف فروش، بهره‌وری فروش.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_rate


@dataclass(frozen=True)
class SalesGrowthInput:
    previous_period_value: Decimal
    current_period_value: Decimal


@dataclass(frozen=True)
class SalesGrowthResult:
    growth_rate_pct: Decimal
    absolute_change: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_sales_growth(data: SalesGrowthInput) -> SalesGrowthResult:
    missing: list[str] = []
    if data.previous_period_value is None:
        missing.append("previous_period_value")
    if data.current_period_value is None:
        missing.append("current_period_value")
    if missing:
        raise InsufficientEvidenceError(
            missing, "برای محاسبه رشد فروش، اطلاعات زیر لازم است: " + "، ".join(missing)
        )
    if data.previous_period_value == 0:
        raise InsufficientEvidenceError(
            ["previous_period_value"],
            "مقدار دوره قبل صفر است؛ درصد رشد از صفر قابل‌محاسبه و بی‌معنی است.",
        )

    change = data.current_period_value - data.previous_period_value
    growth_rate = _q_rate(change / data.previous_period_value)

    return SalesGrowthResult(growth_rate_pct=growth_rate, absolute_change=change)


@dataclass(frozen=True)
class FunnelStage:
    stage_name_fa: str
    count: Decimal


@dataclass(frozen=True)
class SalesFunnelInput:
    stages: list[FunnelStage]  # ترتیب از بالای قیف به پایین


@dataclass(frozen=True)
class FunnelStageConversion:
    from_stage_fa: str
    to_stage_fa: str
    conversion_rate_pct: Decimal | None


@dataclass(frozen=True)
class SalesFunnelResult:
    conversions: list[FunnelStageConversion]
    overall_conversion_pct: Decimal | None
    formula_version: str = FORMULA_VERSION


def calculate_sales_funnel(data: SalesFunnelInput) -> SalesFunnelResult:
    if not data.stages or len(data.stages) < 2:
        raise InsufficientEvidenceError(
            ["stages"], "برای محاسبه قیف فروش، حداقل دو مرحله با تعداد مشخص لازم است."
        )
    for stage in data.stages:
        if stage.count is None or stage.count < 0:
            raise InsufficientEvidenceError(
                ["stages"], f"تعداد مرحله «{stage.stage_name_fa}» نامعتبر است."
            )

    conversions: list[FunnelStageConversion] = []
    for i in range(len(data.stages) - 1):
        current, nxt = data.stages[i], data.stages[i + 1]
        rate = _q_rate(nxt.count / current.count) if current.count > 0 else None
        conversions.append(
            FunnelStageConversion(
                from_stage_fa=current.stage_name_fa, to_stage_fa=nxt.stage_name_fa,
                conversion_rate_pct=rate,
            )
        )

    first, last = data.stages[0], data.stages[-1]
    overall = _q_rate(last.count / first.count) if first.count > 0 else None

    return SalesFunnelResult(conversions=conversions, overall_conversion_pct=overall)


@dataclass(frozen=True)
class SalesProductivityInput:
    output_value: Decimal  # مثلاً جمع فروش
    input_value: Decimal  # مثلاً تعداد نمایندگان فروش یا تعداد تماس‌ها


@dataclass(frozen=True)
class SalesProductivityResult:
    productivity_ratio: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_sales_productivity(data: SalesProductivityInput) -> SalesProductivityResult:
    missing: list[str] = []
    if data.output_value is None:
        missing.append("output_value")
    if data.input_value is None:
        missing.append("input_value")
    elif data.input_value <= 0:
        raise InsufficientEvidenceError(
            ["input_value"], "مخرج بهره‌وری (مثلاً تعداد نماینده) باید بزرگ‌تر از صفر باشد."
        )
    if missing:
        raise InsufficientEvidenceError(
            missing, "برای محاسبه بهره‌وری فروش، اطلاعات زیر لازم است: " + "، ".join(missing)
        )

    ratio = (data.output_value / data.input_value).quantize(Decimal("0.01"))
    return SalesProductivityResult(productivity_ratio=ratio)
