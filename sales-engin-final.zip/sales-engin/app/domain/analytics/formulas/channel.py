"""
اقتصاد کانال: حاشیه کانال و تعارض کانال.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_money, _q_rate


@dataclass(frozen=True)
class ChannelMarginInput:
    currency: str
    sell_price: Decimal
    cost_to_seller: Decimal


@dataclass(frozen=True)
class ChannelMarginResult:
    currency: str
    margin_per_unit: Decimal
    margin_pct: Decimal | None
    formula_version: str = FORMULA_VERSION


def calculate_channel_margin(data: ChannelMarginInput) -> ChannelMarginResult:
    missing: list[str] = []
    if not data.currency or not data.currency.strip():
        missing.append("currency")
    if data.sell_price is None:
        missing.append("sell_price")
    if data.cost_to_seller is None:
        missing.append("cost_to_seller")
    elif data.cost_to_seller < 0:
        raise InsufficientEvidenceError(["cost_to_seller"], "هزینه نمی‌تواند منفی باشد.")

    if missing:
        raise InsufficientEvidenceError(
            missing, "برای محاسبه حاشیه کانال، اطلاعات زیر لازم است: " + "، ".join(missing)
        )

    margin = data.sell_price - data.cost_to_seller
    margin_pct = _q_rate(margin / data.sell_price) if data.sell_price > 0 else None

    return ChannelMarginResult(
        currency=data.currency.strip().upper(),
        margin_per_unit=_q_money(margin),
        margin_pct=margin_pct,
    )


@dataclass(frozen=True)
class ChannelConflictInput:
    currency: str
    price_to_dealer: Decimal
    price_to_sub_dealer: Decimal


@dataclass(frozen=True)
class ChannelConflictResult:
    currency: str
    conflict_detected: bool
    price_gap: Decimal
    explanation_fa: str
    formula_version: str = FORMULA_VERSION


def detect_channel_conflict(data: ChannelConflictInput) -> ChannelConflictResult:
    missing: list[str] = []
    if not data.currency or not data.currency.strip():
        missing.append("currency")
    if data.price_to_dealer is None:
        missing.append("price_to_dealer")
    if data.price_to_sub_dealer is None:
        missing.append("price_to_sub_dealer")

    if missing:
        raise InsufficientEvidenceError(
            missing, "برای تشخیص تعارض کانال، اطلاعات زیر لازم است: " + "، ".join(missing)
        )

    gap = data.price_to_dealer - data.price_to_sub_dealer
    conflict = gap > 0  # نماینده فرعی ارزان‌تر از نماینده اصلی می‌خرد → ریسک نشتی کانال

    explanation = (
        "قیمت به زیرنماینده پایین‌تر از قیمت به نماینده اصلی است؛ این وضعیت می‌تواند باعث "
        "نشتی قیمت و تعارض کانال شود."
        if conflict
        else "شکاف قیمتی بین نماینده اصلی و زیرنماینده در جهت معمول بازار است."
    )

    return ChannelConflictResult(
        currency=data.currency.strip().upper(),
        conflict_detected=conflict,
        price_gap=_q_money(gap),
        explanation_fa=explanation,
    )
