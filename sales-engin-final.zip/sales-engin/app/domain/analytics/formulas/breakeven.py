"""
نقطه سربه‌سر (Break-Even) — مبتنی بر حاشیه سود مشارکت.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION


@dataclass(frozen=True)
class BreakevenInput:
    fixed_cost: Decimal
    contribution_margin_per_unit: Decimal


@dataclass(frozen=True)
class BreakevenResult:
    breakeven_units: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_breakeven_units(data: BreakevenInput) -> BreakevenResult:
    missing: list[str] = []
    if data.fixed_cost is None:
        missing.append("fixed_cost")
    elif data.fixed_cost < 0:
        raise InsufficientEvidenceError(["fixed_cost"], "هزینه ثابت نمی‌تواند منفی باشد.")
    if data.contribution_margin_per_unit is None:
        missing.append("contribution_margin_per_unit")
    if missing:
        raise InsufficientEvidenceError(
            missing, "برای محاسبه نقطه سربه‌سر، اطلاعات زیر لازم است: " + "، ".join(missing)
        )
    if data.contribution_margin_per_unit <= 0:
        raise InsufficientEvidenceError(
            ["contribution_margin_per_unit"],
            "حاشیه سود مشارکت هر واحد صفر یا منفی است؛ در این شرایط با افزایش حجم فروش به "
            "سربه‌سر نمی‌رسید — مسئله در قیمت یا هزینه است، نه در حجم.",
        )

    units = (data.fixed_cost / data.contribution_margin_per_unit).quantize(Decimal("1"), rounding="ROUND_CEILING")
    return BreakevenResult(breakeven_units=units)
