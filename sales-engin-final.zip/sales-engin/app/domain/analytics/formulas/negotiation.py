"""
موتور مذاکره B2B — قانون معماری ۳۰: بدون اعلام «برنده مذاکره»؛ فقط اثر اقتصادی گزینه را
با در نظر گرفتن تعهد جبرانی طرف مقابل ارزیابی می‌کند. سیستم مذاکره‌کننده را جایگزین نمی‌کند.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_money


@dataclass(frozen=True)
class NegotiationOptionInput:
    currency: str
    baseline_unit_price: Decimal
    baseline_volume: Decimal
    variable_cost_per_unit: Decimal
    concession_price_reduction_per_unit: Decimal
    counterpart_volume_increase_units: Decimal = Decimal("0")
    counterpart_payment_days_reduction: Decimal = Decimal("0")
    daily_financing_rate: Decimal = Decimal("0")


@dataclass(frozen=True)
class NegotiationOptionResult:
    currency: str
    baseline_margin_total: Decimal
    new_margin_total: Decimal
    margin_impact: Decimal
    cash_flow_benefit: Decimal
    net_economic_effect: Decimal
    formula_version: str = FORMULA_VERSION


def calculate_negotiation_option_impact(
    data: NegotiationOptionInput,
) -> NegotiationOptionResult:
    missing: list[str] = []
    if not data.currency or not data.currency.strip():
        missing.append("currency")
    for field_name in [
        "baseline_unit_price", "baseline_volume", "variable_cost_per_unit",
        "concession_price_reduction_per_unit",
    ]:
        if getattr(data, field_name) is None:
            missing.append(field_name)
    if missing:
        raise InsufficientEvidenceError(
            missing, "برای ارزیابی گزینه مذاکره، اطلاعات زیر لازم است: " + "، ".join(missing)
        )
    if data.baseline_volume <= 0:
        raise InsufficientEvidenceError(
            ["baseline_volume"], "حجم پایه معامله باید بزرگ‌تر از صفر باشد."
        )
    if data.variable_cost_per_unit < 0:
        raise InsufficientEvidenceError(
            ["variable_cost_per_unit"], "هزینه متغیر هر واحد نمی‌تواند منفی باشد."
        )

    new_unit_price = data.baseline_unit_price - data.concession_price_reduction_per_unit
    if new_unit_price < 0:
        raise InsufficientEvidenceError(
            ["concession_price_reduction_per_unit"],
            "تخفیف پیشنهادی از قیمت پایه بیشتر است؛ قیمت جدید منفی می‌شود.",
        )

    new_volume = data.baseline_volume + data.counterpart_volume_increase_units

    baseline_margin_total = (data.baseline_unit_price - data.variable_cost_per_unit) * data.baseline_volume
    new_margin_total = (new_unit_price - data.variable_cost_per_unit) * new_volume
    margin_impact = new_margin_total - baseline_margin_total

    cash_flow_benefit = (
        data.baseline_unit_price
        * data.baseline_volume
        * data.daily_financing_rate
        * data.counterpart_payment_days_reduction
    )

    net_effect = margin_impact + cash_flow_benefit

    return NegotiationOptionResult(
        currency=data.currency.strip().upper(),
        baseline_margin_total=_q_money(baseline_margin_total),
        new_margin_total=_q_money(new_margin_total),
        margin_impact=_q_money(margin_impact),
        cash_flow_benefit=_q_money(cash_flow_benefit),
        net_economic_effect=_q_money(net_effect),
    )
