"""
مقایسه مورد انتظار با واقعی — قانون معماری ۶ و ۷: پیش‌بینی، واقعیت نیست و نتیجه، سهم عامل نیست.
این ماژول صرفاً واریانس را محاسبه و در صورت عبور از آستانه، «پیشنهاد بازبینی» می‌دهد —
هرگز به‌خودی‌خود مدلی را تغییر نمی‌دهد (قانون ۱۹).
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_rate

LEARNING_CANDIDATE_THRESHOLD_PCT = Decimal("0.20")  # ۲۰٪ انحراف — آستانه پیشنهاد بازبینی


@dataclass(frozen=True)
class VarianceInput:
    expected_value: Decimal
    actual_value: Decimal


@dataclass(frozen=True)
class VarianceResult:
    variance_absolute: Decimal
    variance_pct: Decimal | None
    exceeds_learning_threshold: bool
    formula_version: str = FORMULA_VERSION


def calculate_expected_vs_actual_variance(data: VarianceInput) -> VarianceResult:
    missing: list[str] = []
    if data.expected_value is None:
        missing.append("expected_value")
    if data.actual_value is None:
        missing.append("actual_value")
    if missing:
        raise InsufficientEvidenceError(
            missing, "برای مقایسه مورد انتظار با واقعی، اطلاعات زیر لازم است: " + "، ".join(missing)
        )

    variance_absolute = data.actual_value - data.expected_value
    variance_pct = (
        _q_rate(variance_absolute / data.expected_value) if data.expected_value != 0 else None
    )
    exceeds = (
        abs(variance_pct) >= LEARNING_CANDIDATE_THRESHOLD_PCT if variance_pct is not None else False
    )

    return VarianceResult(
        variance_absolute=variance_absolute.quantize(Decimal("0.01")),
        variance_pct=variance_pct,
        exceeds_learning_threshold=exceeds,
    )
