"""
سنجش سهم عوامل (Attribution) — قانون معماری ۳۵:
صرفِ هم‌زمانی «اقدام انجام شد» و «KPI تغییر کرد» به‌معنای رابطه علّی نیست.

بدون یک گروه مقایسه (کنترل) یا خط مبنای معتبر، این ماژول هرگز اثر را به اقدام نسبت نمی‌دهد؛
به‌جای آن ATTRIBUTION_NOT_IDENTIFIABLE برمی‌گرداند.
"""

from dataclasses import dataclass
from decimal import Decimal

ATTRIBUTION_NOT_IDENTIFIABLE = "ATTRIBUTION_NOT_IDENTIFIABLE"


@dataclass(frozen=True)
class AttributionInput:
    actual_kpi_change: Decimal
    control_group_kpi_change: Decimal | None = None  # تغییر KPI در گروه/دوره مقایسه بدون اقدام


@dataclass(frozen=True)
class AttributionResult:
    attribution_level: str  # "ESTIMATED_INCREMENTAL_EFFECT" یا ATTRIBUTION_NOT_IDENTIFIABLE
    estimated_incremental_effect: Decimal | None
    explanation_fa: str


def evaluate_attribution(data: AttributionInput) -> AttributionResult:
    if data.control_group_kpi_change is None:
        return AttributionResult(
            attribution_level=ATTRIBUTION_NOT_IDENTIFIABLE,
            estimated_incremental_effect=None,
            explanation_fa=(
                "بدون یک گروه/دوره مقایسه (کنترل) که همان اقدام روی آن انجام نشده باشد، "
                "نمی‌توان گفت این تغییر KPI ناشی از اقدام بوده یا از عوامل دیگر بازار. "
                "هم‌زمانی اقدام و تغییر KPI، اثبات رابطه علّی نیست."
            ),
        )

    incremental_effect = data.actual_kpi_change - data.control_group_kpi_change
    return AttributionResult(
        attribution_level="ESTIMATED_INCREMENTAL_EFFECT",
        estimated_incremental_effect=incremental_effect,
        explanation_fa=(
            "این عدد یک برآورد اثر افزایشی (تفاضل نسبت به گروه مقایسه) است، نه یک اندازه‌گیری "
            "قطعی علّیت. عوامل مداخله‌گر دیگر ممکن است هنوز اثرگذار بوده باشند."
        ),
    )
