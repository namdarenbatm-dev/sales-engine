"""
پیش‌بینی — قانون معماری ۶: Forecast is not Actual.
همه خروجی‌ها باید همیشه به‌عنوان «پیش‌بینی» و نه «واقعیت» به کاربر نمایش داده شوند.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_money


@dataclass(frozen=True)
class NaiveForecastInput:
    historical_values: list[Decimal]  # قدیمی‌ترین اول، جدیدترین آخر


@dataclass(frozen=True)
class ForecastResult:
    forecast_next_period: Decimal
    method_fa: str
    formula_version: str = FORMULA_VERSION


def _require_non_empty(values: list[Decimal] | None, min_len: int = 1) -> None:
    if not values or len(values) < min_len:
        raise InsufficientEvidenceError(
            ["historical_values"],
            f"برای این روش پیش‌بینی، حداقل {min_len} دوره داده تاریخی لازم است.",
        )


def calculate_naive_forecast(data: NaiveForecastInput) -> ForecastResult:
    _require_non_empty(data.historical_values, min_len=1)
    return ForecastResult(
        forecast_next_period=_q_money(data.historical_values[-1]),
        method_fa="پیش‌بینی ساده (آخرین مقدار مشاهده‌شده)",
    )


@dataclass(frozen=True)
class MovingAverageInput:
    historical_values: list[Decimal]
    window: int


def calculate_moving_average_forecast(data: MovingAverageInput) -> ForecastResult:
    if data.window is None or data.window < 1:
        raise InsufficientEvidenceError(
            ["window"], "طول پنجره میانگین متحرک باید حداقل ۱ باشد."
        )
    _require_non_empty(data.historical_values, min_len=data.window)

    window_values = data.historical_values[-data.window :]
    average = sum(window_values) / Decimal(len(window_values))

    return ForecastResult(
        forecast_next_period=_q_money(average),
        method_fa=f"میانگین متحرک ساده (پنجره {data.window} دوره)",
    )


@dataclass(frozen=True)
class WeightedMovingAverageInput:
    historical_values: list[Decimal]
    weights: list[Decimal]  # از قدیمی‌ترین به جدیدترین، مجموع باید ۱ باشد


def calculate_weighted_moving_average_forecast(
    data: WeightedMovingAverageInput,
) -> ForecastResult:
    if not data.weights:
        raise InsufficientEvidenceError(["weights"], "وزن‌های میانگین متحرک وزنی مشخص نشده است.")
    weight_sum = sum(data.weights)
    if abs(weight_sum - Decimal("1")) > Decimal("0.0001"):
        raise InsufficientEvidenceError(
            ["weights"], f"مجموع وزن‌ها باید برابر ۱ باشد؛ مقدار فعلی: {weight_sum}."
        )
    _require_non_empty(data.historical_values, min_len=len(data.weights))

    window_values = data.historical_values[-len(data.weights) :]
    weighted_sum = sum(v * w for v, w in zip(window_values, data.weights))

    return ForecastResult(
        forecast_next_period=_q_money(weighted_sum),
        method_fa=f"میانگین متحرک وزنی ({len(data.weights)} دوره)",
    )


@dataclass(frozen=True)
class ExponentialSmoothingInput:
    historical_values: list[Decimal]
    alpha: Decimal  # ضریب هموارسازی، بین صفر و یک


def calculate_exponential_smoothing_forecast(
    data: ExponentialSmoothingInput,
) -> ForecastResult:
    if data.alpha is None or not (Decimal("0") < data.alpha <= Decimal("1")):
        raise InsufficientEvidenceError(
            ["alpha"], "ضریب هموارسازی (alpha) باید بین صفر (نامحسوس) و یک باشد."
        )
    _require_non_empty(data.historical_values, min_len=2)

    forecast = data.historical_values[0]
    for actual in data.historical_values[1:]:
        forecast = data.alpha * actual + (Decimal("1") - data.alpha) * forecast

    return ForecastResult(
        forecast_next_period=_q_money(forecast),
        method_fa=f"هموارسازی نمایی (alpha={data.alpha})",
    )
