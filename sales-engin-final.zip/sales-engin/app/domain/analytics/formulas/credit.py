"""
اقتصاد اعتبار (Credit Economics) — هرگز به‌عنوان یقین کامل نمایش داده نمی‌شود.
"""

from dataclasses import dataclass
from decimal import Decimal

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.pricing import FORMULA_VERSION, _q_money


@dataclass(frozen=True)
class CreditEconomicsInput:
    currency: str
    incremental_margin: Decimal
    financing_cost: Decimal
    expected_credit_loss: Decimal
    collection_cost: Decimal


@dataclass(frozen=True)
class CreditEconomicsResult:
    currency: str
    net_credit_adjusted_margin: Decimal
    explanation_fa: str
    formula_version: str = FORMULA_VERSION


def calculate_credit_adjusted_margin(data: CreditEconomicsInput) -> CreditEconomicsResult:
    missing: list[str] = []
    for field_name in [
        "incremental_margin",
        "financing_cost",
        "expected_credit_loss",
        "collection_cost",
    ]:
        if getattr(data, field_name) is None:
            missing.append(field_name)
    if not data.currency or not data.currency.strip():
        missing.append("currency")

    if missing:
        raise InsufficientEvidenceError(
            missing,
            "اقتصاد اعتبار ناقص است — بدون اطلاعات زیر، محاسبه به‌صورت قطعیت کاذب نمایش داده "
            "نمی‌شود: " + "، ".join(missing),
        )

    net_margin = (
        data.incremental_margin
        - data.financing_cost
        - data.expected_credit_loss
        - data.collection_cost
    )

    return CreditEconomicsResult(
        currency=data.currency.strip().upper(),
        net_credit_adjusted_margin=_q_money(net_margin),
        explanation_fa=(
            "این عدد بر پایه فرض‌های ورودی (هزینه تأمین مالی، زیان اعتباری مورد انتظار و هزینه "
            "وصول) محاسبه شده و یک قطعیت نیست؛ در صورت تغییر رفتار پرداخت مشتری، باید بازبینی شود."
        ),
    )
