"""
موتور سناریو — قانون معماری: Scenario ≠ Simulation، و هیچ سناریویی «بهترین» اعلام نمی‌شود.

این پیاده‌سازی سناریوها را با اعمال ضریب روی فیلدهای عددی مشخص یک PricingCoreRequest
و اجرای دوباره موتور واقعی محاسبه می‌سازد — نه با حدس زدن نتیجه.
"""

import dataclasses
from dataclasses import dataclass
from decimal import Decimal
from typing import Literal

from app.domain.analytics.engine import PricingCoreRequest, PricingCoreResult, run_pricing_core
from app.domain.analytics.engine import BlockedResult

ScenarioType = Literal["BASE", "UPSIDE", "DOWNSIDE", "STRESS", "CUSTOM"]

# فیلدهایی که مجاز به تعدیل سناریویی هستند (فقط فیلدهای عددی معنادار برای این مدل)
_ADJUSTABLE_FIELDS = {
    "nominal_unit_price",
    "paid_units",
    "total_discounts",
    "total_rebates",
    "variable_cost_per_unit",
}


@dataclass(frozen=True)
class ScenarioDefinition:
    name_fa: str
    scenario_type: ScenarioType
    multipliers: dict[str, Decimal]  # مثلاً {"paid_units": Decimal("0.8")} یعنی ۸۰٪ حالت پایه


@dataclass(frozen=True)
class ScenarioOutcome:
    name_fa: str
    scenario_type: ScenarioType
    result: PricingCoreResult | BlockedResult


def _apply_multipliers(
    base_request: PricingCoreRequest, multipliers: dict[str, Decimal]
) -> PricingCoreRequest:
    unknown = set(multipliers) - _ADJUSTABLE_FIELDS
    if unknown:
        raise ValueError(f"فیلدهای غیرمجاز برای تعدیل سناریو: {sorted(unknown)}")

    updates = {
        field: getattr(base_request, field) * multiplier for field, multiplier in multipliers.items()
    }
    return dataclasses.replace(base_request, **updates)


def run_pricing_scenarios(
    base_request: PricingCoreRequest, scenarios: list[ScenarioDefinition]
) -> list[ScenarioOutcome]:
    """
    همیشه سناریوی پایه (بدون تعدیل) را هم اجرا و برمی‌گرداند تا مقایسه ممکن باشد.
    خروجی یک فهرست است، نه یک عدد واحد — هیچ سناریویی به‌عنوان «واقعیت آینده» علامت‌گذاری نمی‌شود.
    """
    outcomes: list[ScenarioOutcome] = [
        ScenarioOutcome(name_fa="پایه", scenario_type="BASE", result=run_pricing_core(base_request))
    ]

    for scenario in scenarios:
        adjusted_request = _apply_multipliers(base_request, scenario.multipliers)
        outcomes.append(
            ScenarioOutcome(
                name_fa=scenario.name_fa,
                scenario_type=scenario.scenario_type,
                result=run_pricing_core(adjusted_request),
            )
        )

    return outcomes


def run_sensitivity_analysis(
    base_request: PricingCoreRequest, field: str, test_values: list[Decimal]
) -> list[tuple[Decimal, PricingCoreResult | BlockedResult]]:
    """
    تحلیل حساسیت: یک فیلد را روی مقادیر مشخص تغییر می‌دهد و اثر را روی نتیجه کامل نشان می‌دهد.
    """
    if field not in _ADJUSTABLE_FIELDS:
        raise ValueError(f"فیلد «{field}» برای تحلیل حساسیت مجاز نیست.")

    results: list[tuple[Decimal, PricingCoreResult | BlockedResult]] = []
    for value in test_values:
        adjusted_request = dataclasses.replace(base_request, **{field: value})
        results.append((value, run_pricing_core(adjusted_request)))
    return results
