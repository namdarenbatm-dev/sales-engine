import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

ENGINE_VERSION = "channel-incentive-engine-1.0.0"


@dataclass(frozen=True)
class SimpleTrace:
    execution_id: str
    engine_version: str
    formula_version: str
    executed_at: str
    tenant_id: str
    problem_id: str | None
    raw_inputs: dict[str, Any]


def serialize_inputs(data_obj: Any) -> dict[str, Any]:
    raw = asdict(data_obj)
    return {k: (str(v) if isinstance(v, Decimal) else v) for k, v in raw.items()}


def build_simple_trace(
    tenant_id: str,
    problem_id: str | None,
    formula_version: str,
    raw_inputs: dict[str, Any],
) -> SimpleTrace:
    return SimpleTrace(
        execution_id=str(uuid.uuid4()),
        engine_version=ENGINE_VERSION,
        formula_version=formula_version,
        executed_at=datetime.now(timezone.utc).isoformat(),
        tenant_id=tenant_id,
        problem_id=problem_id,
        raw_inputs=raw_inputs,
    )
