import uuid

from fastapi import APIRouter, Depends, Header, HTTPException

from app.core.database import get_session, require_tenant_id
from app.domain.identity.dependencies import require_permission
from app.domain.learning.schemas import LearningCandidateResponseSchema, LearningCandidateReviewSchema
from app.domain.learning.service import (
    get_learning_candidate,
    list_learning_candidates,
    review_learning_candidate,
)

router = APIRouter(prefix="/api/v1/learning-candidates", tags=["learning"])


@router.get("", response_model=list[LearningCandidateResponseSchema])
def list_candidates(
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> list[LearningCandidateResponseSchema]:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        candidates = list_learning_candidates(session, tenant_id)
        return [LearningCandidateResponseSchema.model_validate(c) for c in candidates]


@router.post("/{candidate_id}/review", response_model=LearningCandidateResponseSchema)
def review_candidate(
    candidate_id: uuid.UUID,
    payload: LearningCandidateReviewSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
    principal=Depends(require_permission("learning:review")),
) -> LearningCandidateResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        candidate = get_learning_candidate(session, tenant_id, candidate_id)
        if candidate is None:
            raise HTTPException(status_code=404, detail="کاندیدای یادگیری یافت نشد.")
        candidate = review_learning_candidate(session, tenant_id, candidate, payload)
        session.flush()
        return LearningCandidateResponseSchema.model_validate(candidate)
