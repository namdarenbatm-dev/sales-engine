import uuid
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel

from app.domain.learning.models import LearningCandidateStatus


class LearningCandidateResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    source_action_id: uuid.UUID | None
    model_code: str | None
    variance_pct: Decimal
    hypothesis_fa: str
    status: LearningCandidateStatus
    reviewer_fa: str | None
    created_at: datetime

    class Config:
        from_attributes = True


class LearningCandidateReviewSchema(BaseModel):
    new_status: LearningCandidateStatus
    reviewer_fa: str
    notes_fa: str | None = None
