import enum
import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, Enum, Numeric, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class LearningCandidateStatus(str, enum.Enum):
    PROPOSED = "پیشنهادشده"
    VALIDATED = "تأییدشده(اعتبارسنجی)"
    REJECTED = "ردشده"
    APPLIED = "اعمال‌شده"  # فقط با تأیید انسانی صریح؛ هرگز خودکار


class LearningCandidate(Base):
    """
    کاندیدای یادگیری — قانون معماری ۱۹: یادگیری هرگز مدل تولید را به‌صورت خودکار تغییر نمی‌دهد.

    این رکورد صرفاً یک «پیشنهاد بازبینی» است که باید توسط یک انسان اعتبارسنجی و تأیید شود؛
    هیچ فرایند خودکاری status را به APPLIED تغییر نمی‌دهد.
    """

    __tablename__ = "learning_candidates"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    source_action_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=True)
    model_code: Mapped[str] = mapped_column(String(64), nullable=True)
    variance_pct: Mapped[float] = mapped_column(Numeric(10, 4), nullable=False)
    hypothesis_fa: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[LearningCandidateStatus] = mapped_column(
        Enum(LearningCandidateStatus), nullable=False, default=LearningCandidateStatus.PROPOSED
    )
    reviewer_fa: Mapped[str] = mapped_column(String(128), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
