import uuid

from sqlalchemy.orm import Session

from app.domain.audit.service import log_event
from app.domain.learning.models import LearningCandidate, LearningCandidateStatus
from app.domain.learning.schemas import LearningCandidateReviewSchema


def create_learning_candidate(
    session: Session,
    tenant_id: str,
    source_action_id: uuid.UUID | None,
    model_code: str | None,
    variance_pct,
    hypothesis_fa: str,
) -> LearningCandidate:
    candidate = LearningCandidate(
        tenant_id=tenant_id,
        source_action_id=source_action_id,
        model_code=model_code,
        variance_pct=variance_pct,
        hypothesis_fa=hypothesis_fa,
        status=LearningCandidateStatus.PROPOSED,
    )
    session.add(candidate)
    session.flush()
    log_event(
        session, tenant_id=tenant_id, event_type="LEARNING_CANDIDATE_PROPOSED",
        payload={"learning_candidate_id": str(candidate.id), "variance_pct": str(variance_pct)},
        notes_fa="یک کاندیدای یادگیری به‌صورت خودکار پیشنهاد شد (نیازمند بازبینی انسانی).",
    )
    return candidate


def get_learning_candidate(
    session: Session, tenant_id: str, candidate_id: uuid.UUID
) -> LearningCandidate | None:
    return (
        session.query(LearningCandidate)
        .filter(LearningCandidate.id == candidate_id, LearningCandidate.tenant_id == tenant_id)
        .one_or_none()
    )


def list_learning_candidates(session: Session, tenant_id: str) -> list[LearningCandidate]:
    return session.query(LearningCandidate).filter(LearningCandidate.tenant_id == tenant_id).all()


def review_learning_candidate(
    session: Session,
    tenant_id: str,
    candidate: LearningCandidate,
    payload: LearningCandidateReviewSchema,
) -> LearningCandidate:
    """
    قانون معماری ۱۹: این تنها مسیری است که وضعیت کاندیدای یادگیری تغییر می‌کند — همیشه با
    فراخوانی صریح یک انسان (reviewer_fa الزامی است)، هرگز به‌صورت خودکار توسط سیستم.
    """
    candidate.status = payload.new_status
    candidate.reviewer_fa = payload.reviewer_fa
    session.add(candidate)
    session.flush()
    log_event(
        session, tenant_id=tenant_id, event_type="LEARNING_CANDIDATE_REVIEWED",
        payload={
            "learning_candidate_id": str(candidate.id), "new_status": payload.new_status.value,
            "reviewer_fa": payload.reviewer_fa,
        },
        notes_fa=payload.notes_fa,
    )
    return candidate
