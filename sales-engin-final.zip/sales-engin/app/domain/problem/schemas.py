import uuid
from datetime import date, datetime

from pydantic import BaseModel, Field


class ProblemCreateSchema(BaseModel):
    business_area_fa: str = Field(..., description="حوزه کسب‌وکار، مثلاً «قیمت‌گذاری کانال»")
    observed_symptom_fa: str = Field(..., description="علامت مشاهده‌شده")
    target_outcome_fa: str = Field(..., description="نتیجه مطلوب")
    channel_fa: str | None = None
    product_fa: str | None = None
    customer_group_fa: str | None = None
    period_start: date | None = None
    period_end: date | None = None


class ProblemResponseSchema(BaseModel):
    id: uuid.UUID
    tenant_id: str
    business_area_fa: str
    observed_symptom_fa: str
    target_outcome_fa: str
    channel_fa: str | None
    product_fa: str | None
    customer_group_fa: str | None
    period_start: date | None
    period_end: date | None
    status_fa: str
    known_facts_fa: list[str]
    hypotheses_fa: list[str]
    assumptions_fa: list[str]
    constraints_fa: list[str]
    created_at: datetime

    class Config:
        from_attributes = True


class DiagnosticEntrySchema(BaseModel):
    field_fa: str = Field(
        ..., description="یکی از: known_facts_fa، hypotheses_fa، assumptions_fa، constraints_fa"
    )
    text_fa: str


class DiagnosticQuestionSchema(BaseModel):
    field_fa: str
    question_fa: str


class DiagnosticStatusSchema(BaseModel):
    sufficient_fa: bool
    next_question: DiagnosticQuestionSchema | None
    explanation_fa: str
    coverage_fa: dict[str, int] = {}
