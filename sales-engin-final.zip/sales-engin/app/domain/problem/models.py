import uuid
from datetime import date, datetime, timezone

from sqlalchemy import Date, DateTime, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class Problem(Base):
    """
    نمایش ساختاریافته مسئله (Problem Representation).

    نسخه این مرحله: فرض/فرضیه/واقعیت/محدودیت به‌صورت آرایه متنی ساده (JSONB) نگه‌داری می‌شوند.
    موتور تشخیص پویا هنوز مبتنی بر «information gain» واقعی نیست؛ صرفاً یک ترتیب اولویت
    قانون‌محور و ثابت است (`app/domain/problem/diagnostic.py`) — این یک ساده‌سازی آگاهانه است،
    نه پیاده‌سازی کامل بخش ۱۳ سند معماری.
    """

    __tablename__ = "problems"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    business_area_fa: Mapped[str] = mapped_column(String(128), nullable=False)
    observed_symptom_fa: Mapped[str] = mapped_column(Text, nullable=False)
    target_outcome_fa: Mapped[str] = mapped_column(Text, nullable=False)
    channel_fa: Mapped[str] = mapped_column(String(128), nullable=True)
    product_fa: Mapped[str] = mapped_column(String(128), nullable=True)
    customer_group_fa: Mapped[str] = mapped_column(String(128), nullable=True)
    period_start: Mapped[date] = mapped_column(Date, nullable=True)
    period_end: Mapped[date] = mapped_column(Date, nullable=True)
    status_fa: Mapped[str] = mapped_column(String(64), nullable=False, default="باز")
    known_facts_fa: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    hypotheses_fa: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    assumptions_fa: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    constraints_fa: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
