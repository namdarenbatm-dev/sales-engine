import uuid

from fastapi import APIRouter, Header, HTTPException

from app.core.database import get_session, require_tenant_id
from app.domain.problem.diagnostic import get_next_diagnostic_question
from app.domain.problem.schemas import (
    DiagnosticEntrySchema,
    DiagnosticStatusSchema,
    ProblemCreateSchema,
    ProblemResponseSchema,
)
from app.domain.problem.service import (
    InvalidDiagnosticFieldError,
    add_diagnostic_entry,
    create_problem,
    get_problem,
)

router = APIRouter(prefix="/api/v1/problems", tags=["problem"])


@router.post("", response_model=ProblemResponseSchema)
def create_problem_endpoint(
    payload: ProblemCreateSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ProblemResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        problem = create_problem(session, tenant_id, payload)
        session.flush()
        return ProblemResponseSchema.model_validate(problem)


@router.get("/{problem_id}", response_model=ProblemResponseSchema)
def get_problem_endpoint(
    problem_id: uuid.UUID,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ProblemResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        problem = get_problem(session, tenant_id, problem_id)
        if problem is None:
            raise HTTPException(status_code=404, detail="مسئله موردنظر یافت نشد.")
        return ProblemResponseSchema.model_validate(problem)


@router.post("/{problem_id}/diagnostic-entries", response_model=ProblemResponseSchema)
def add_diagnostic_entry_endpoint(
    problem_id: uuid.UUID,
    payload: DiagnosticEntrySchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ProblemResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        problem = get_problem(session, tenant_id, problem_id)
        if problem is None:
            raise HTTPException(status_code=404, detail="مسئله موردنظر یافت نشد.")
        try:
            problem = add_diagnostic_entry(session, tenant_id, problem, payload)
        except InvalidDiagnosticFieldError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        session.flush()
        return ProblemResponseSchema.model_validate(problem)


@router.get("/{problem_id}/next-diagnostic-question", response_model=DiagnosticStatusSchema)
def next_diagnostic_question_endpoint(
    problem_id: uuid.UUID,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> DiagnosticStatusSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        problem = get_problem(session, tenant_id, problem_id)
        if problem is None:
            raise HTTPException(status_code=404, detail="مسئله موردنظر یافت نشد.")
        status = get_next_diagnostic_question(problem)
        return DiagnosticStatusSchema(
            sufficient_fa=status.sufficient_fa,
            next_question=(
                {"field_fa": status.next_question.field_fa, "question_fa": status.next_question.question_fa}
                if status.next_question
                else None
            ),
            explanation_fa=status.explanation_fa,
            coverage_fa=status.coverage_fa,
        )
