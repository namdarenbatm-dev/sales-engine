"""
موتور تشخیص پویا — نسخه بهبودیافته (هنوز information gain واقعی نیست).

تفاوت با نسخه قبلی: به‌جای ترتیب ثابت «همیشه اول واقعیت، بعد فرضیه، ...»، این نسخه هر بار
فیلدی را می‌پرسد که کمترین تعداد ورودی را دارد (پوشش متوازن‌تر)، و در تساوی از همان
اولویت کسب‌وکاری قبلی استفاده می‌کند. «کافی بودن» یعنی هر بخش حداقل به تعداد آستانه
مشخص ورودی داشته باشد، نه صرفاً یک مورد.

توجه صادقانه: این هنوز محاسبه واقعی information gain (کاهش عدم قطعیت بر اساس داده) نیست؛
صرفاً یک ساده‌سازی «پوشش متوازن» است.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app.domain.problem.models import Problem

# ترتیب اولویت پرسش‌ها به‌عنوان tie-breaker — از مهم‌ترین به کم‌اهمیت‌ترین
_QUESTION_PRIORITY = [
    ("known_facts_fa", "چه واقعیت‌های مشخص و قابل‌اندازه‌گیری دیگری درباره این وضعیت می‌دانید؟"),
    ("hypotheses_fa", "فرضیه دیگری درباره علت احتمالی این وضعیت دارید؟"),
    ("assumptions_fa", "فرض دیگری (نه واقعیت قطعی) در تحلیل این مسئله لحاظ کرده‌اید؟"),
    ("constraints_fa", "محدودیت دیگری (بودجه، زمان، سیاست شرکت) بر گزینه‌های ممکن اثر می‌گذارد؟"),
]

# حداقل تعداد ورودی در هر بخش تا «کافی» تلقی شود
SUFFICIENCY_THRESHOLD_PER_FIELD = 1


@dataclass(frozen=True)
class DiagnosticQuestion:
    field_fa: str
    question_fa: str


@dataclass(frozen=True)
class DiagnosticStatus:
    sufficient_fa: bool
    next_question: DiagnosticQuestion | None
    explanation_fa: str
    coverage_fa: dict[str, int]


def get_next_diagnostic_question(problem: "Problem") -> DiagnosticStatus:
    counts = {field_name: len(getattr(problem, field_name) or []) for field_name, _ in _QUESTION_PRIORITY}

    below_threshold = [
        (field_name, question_fa)
        for field_name, question_fa in _QUESTION_PRIORITY
        if counts[field_name] < SUFFICIENCY_THRESHOLD_PER_FIELD
    ]

    if below_threshold:
        # اول بر اساس کمترین تعداد فعلی (پوشش متوازن)، سپس بر اساس اولویت کسب‌وکاری
        priority_rank = {name: i for i, (name, _) in enumerate(_QUESTION_PRIORITY)}
        below_threshold.sort(key=lambda item: (counts[item[0]], priority_rank[item[0]]))
        field_name, question_fa = below_threshold[0]
        return DiagnosticStatus(
            sufficient_fa=False,
            next_question=DiagnosticQuestion(field_fa=field_name, question_fa=question_fa),
            explanation_fa="اطلاعات کافی برای این بخش هنوز ثبت نشده است.",
            coverage_fa=counts,
        )

    return DiagnosticStatus(
        sufficient_fa=True,
        next_question=None,
        explanation_fa=(
            "هر بخش (واقعیت، فرضیه، فرض، محدودیت) حداقل یک ورودی دارد. این به‌معنای «تشخیص "
            "کامل» نیست — فقط یعنی حداقل ساختار اولیه به‌صورت متوازن تکمیل شده."
        ),
        coverage_fa=counts,
    )
