import uuid

from sqlalchemy.orm import Session

from app.domain.audit.service import log_event
from app.domain.problem.models import Problem
from app.domain.problem.schemas import DiagnosticEntrySchema, ProblemCreateSchema

_VALID_DIAGNOSTIC_FIELDS = {
    "known_facts_fa",
    "hypotheses_fa",
    "assumptions_fa",
    "constraints_fa",
}


class InvalidDiagnosticFieldError(Exception):
    pass


def create_problem(session: Session, tenant_id: str, payload: ProblemCreateSchema) -> Problem:
    problem = Problem(
        tenant_id=tenant_id,
        business_area_fa=payload.business_area_fa,
        observed_symptom_fa=payload.observed_symptom_fa,
        target_outcome_fa=payload.target_outcome_fa,
        channel_fa=payload.channel_fa,
        product_fa=payload.product_fa,
        customer_group_fa=payload.customer_group_fa,
        period_start=payload.period_start,
        period_end=payload.period_end,
        known_facts_fa=[],
        hypotheses_fa=[],
        assumptions_fa=[],
        constraints_fa=[],
    )
    session.add(problem)
    session.flush()

    log_event(
        session,
        tenant_id=tenant_id,
        event_type="PROBLEM_CREATED",
        payload={"problem_id": str(problem.id), "business_area_fa": problem.business_area_fa},
        notes_fa="مسئله جدید ثبت شد.",
    )
    return problem


def get_problem(session: Session, tenant_id: str, problem_id: uuid.UUID) -> Problem | None:
    return (
        session.query(Problem)
        .filter(Problem.id == problem_id, Problem.tenant_id == tenant_id)
        .one_or_none()
    )


def add_diagnostic_entry(
    session: Session, tenant_id: str, problem: Problem, entry: DiagnosticEntrySchema
) -> Problem:
    """
    افزودن یک واقعیت/فرضیه/فرض/محدودیت به مسئله.

    توجه: خود رکورد Problem آپدیت می‌شود (این جدول ممیزی append-only نیست)، اما هر افزودن
    به‌عنوان یک رویداد جداگانه و بدون‌بازگشت در audit_events ثبت می‌شود — قانون ۱۸ درباره
    خود رویداد ممیزی نقض نمی‌شود.
    """
    if entry.field_fa not in _VALID_DIAGNOSTIC_FIELDS:
        raise InvalidDiagnosticFieldError(
            f"فیلد «{entry.field_fa}» معتبر نیست. مقادیر مجاز: {sorted(_VALID_DIAGNOSTIC_FIELDS)}"
        )

    current_list = list(getattr(problem, entry.field_fa) or [])
    current_list.append(entry.text_fa)
    setattr(problem, entry.field_fa, current_list)
    session.add(problem)
    session.flush()

    log_event(
        session,
        tenant_id=tenant_id,
        event_type="PROBLEM_DIAGNOSTIC_ENTRY_ADDED",
        payload={"problem_id": str(problem.id), "field_fa": entry.field_fa, "text_fa": entry.text_fa},
        notes_fa="یک واقعیت/فرضیه/فرض/محدودیت جدید به مسئله افزوده شد.",
    )
    return problem
