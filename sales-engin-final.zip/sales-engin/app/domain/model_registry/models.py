import enum
import uuid

from sqlalchemy import Enum, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class ModelStatus(str, enum.Enum):
    CANDIDATE = "CANDIDATE"
    VALIDATED = "VALIDATED"
    PRODUCTION_READY = "PRODUCTION_READY"
    REJECTED = "REJECTED"
    DEPRECATED = "DEPRECATED"


class AnalyticalModel(Base):
    """
    ثبت مدل تحلیلی (Model Registry).
    این جدول «حقیقت علمی» را نمایش نمی‌دهد — فقط شرایط تناسب یک مدل با یک مسئله را
    ثبت می‌کند (طبق قانون UX بخش ۱۶: عدم نمایش «بهترین مدل» به‌عنوان حقیقت عینی).
    """

    __tablename__ = "analytical_models"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    name_fa: Mapped[str] = mapped_column(String(128), nullable=False)
    name_en: Mapped[str] = mapped_column(String(128), nullable=False)
    family: Mapped[str] = mapped_column(String(64), nullable=False)
    version: Mapped[str] = mapped_column(String(32), nullable=False)
    status: Mapped[ModelStatus] = mapped_column(Enum(ModelStatus), nullable=False, default=ModelStatus.CANDIDATE)
    required_data_fa: Mapped[str] = mapped_column(Text, nullable=False)
    assumptions_fa: Mapped[str] = mapped_column(Text, nullable=False)
    limitations_fa: Mapped[str] = mapped_column(Text, nullable=False)
