from fastapi import APIRouter

from app.domain.model_registry.registry_data import PRICING_CORE_MODELS

router = APIRouter(prefix="/api/v1/models", tags=["model-registry"])


@router.get("/pricing-core")
def list_pricing_core_models():
    """
    فهرست مدل‌های قابل انتخاب برای مسائل قیمت‌گذاری — بدون رتبه‌بندی «بهترین مدل».
    هر مدل با شرایط تناسب، داده لازم، فرض‌ها و محدودیت‌های خودش نمایش داده می‌شود.
    """
    return [
        {
            "code": m["code"],
            "name_fa": m["name_fa"],
            "name_en": m["name_en"],
            "status": m["status"].value,
            "required_data_fa": m["required_data_fa"],
            "assumptions_fa": m["assumptions_fa"],
            "limitations_fa": m["limitations_fa"],
        }
        for m in PRICING_CORE_MODELS
    ]
