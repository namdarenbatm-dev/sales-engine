from sqlalchemy.orm import Session

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.channel import (
    ChannelConflictInput,
    ChannelMarginInput,
    calculate_channel_margin,
    detect_channel_conflict,
)
from app.domain.analytics.formulas.credit import (
    CreditEconomicsInput,
    calculate_credit_adjusted_margin,
)
from app.domain.analytics.formulas.incentives import (
    FocEquivalentInput,
    RebateEquivalentInput,
    calculate_foc_equivalent_unit_cost,
    calculate_rebate_equivalent_price,
)
from app.domain.analytics.trace_utils import build_simple_trace, serialize_inputs
from app.domain.audit.service import log_event
from app.domain.decision.schemas_stage2 import (
    ChannelConflictRequestSchema,
    ChannelConflictResponseSchema,
    ChannelMarginRequestSchema,
    ChannelMarginResponseSchema,
    CreditEconomicsRequestSchema,
    CreditEconomicsResponseSchema,
    FocEquivalentRequestSchema,
    FocEquivalentResponseSchema,
    RebateEquivalentRequestSchema,
    RebateEquivalentResponseSchema,
    TraceSchema,
)


def _trace_schema(trace) -> TraceSchema:
    return TraceSchema(
        execution_id=trace.execution_id,
        engine_version=trace.engine_version,
        formula_version=trace.formula_version,
        executed_at=trace.executed_at,
        problem_id=trace.problem_id,
    )


def execute_rebate_equivalent(
    session: Session, tenant_id: str, payload: RebateEquivalentRequestSchema
) -> RebateEquivalentResponseSchema:
    data = RebateEquivalentInput(
        currency=payload.currency,
        nominal_unit_price=payload.nominal_unit_price,
        rebate_rate_pct=payload.rebate_rate_pct,
    )
    problem_id = str(payload.problem_id) if payload.problem_id else None
    trace = build_simple_trace(tenant_id, problem_id, "pricing-formulas-1.0.0", serialize_inputs(data))

    try:
        result = calculate_rebate_equivalent_price(data)
    except InsufficientEvidenceError as exc:
        log_event(
            session, tenant_id=tenant_id, event_type="REBATE_EQUIVALENT_BLOCKED",
            execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
            notes_fa=exc.explanation_fa,
        )
        return RebateEquivalentResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )

    log_event(
        session, tenant_id=tenant_id, event_type="REBATE_EQUIVALENT_EXECUTED",
        execution_id=trace.execution_id,
        payload={"rebate_equivalent_unit_price": str(result.rebate_equivalent_unit_price)},
    )
    return RebateEquivalentResponseSchema(
        status="OK", currency=result.currency,
        rebate_equivalent_unit_price=result.rebate_equivalent_unit_price,
        rebate_amount_per_unit=result.rebate_amount_per_unit,
        trace=_trace_schema(trace),
    )


def execute_foc_equivalent(
    session: Session, tenant_id: str, payload: FocEquivalentRequestSchema
) -> FocEquivalentResponseSchema:
    data = FocEquivalentInput(
        currency=payload.currency,
        purchased_units=payload.purchased_units,
        unit_price=payload.unit_price,
        foc_units=payload.foc_units,
    )
    problem_id = str(payload.problem_id) if payload.problem_id else None
    trace = build_simple_trace(tenant_id, problem_id, "pricing-formulas-1.0.0", serialize_inputs(data))

    try:
        result = calculate_foc_equivalent_unit_cost(data)
    except InsufficientEvidenceError as exc:
        log_event(
            session, tenant_id=tenant_id, event_type="FOC_EQUIVALENT_BLOCKED",
            execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
            notes_fa=exc.explanation_fa,
        )
        return FocEquivalentResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )

    log_event(
        session, tenant_id=tenant_id, event_type="FOC_EQUIVALENT_EXECUTED",
        execution_id=trace.execution_id,
        payload={"effective_unit_cost": str(result.effective_unit_cost)},
    )
    return FocEquivalentResponseSchema(
        status="OK", currency=result.currency, effective_unit_cost=result.effective_unit_cost,
        total_delivered_units=result.total_delivered_units, trace=_trace_schema(trace),
    )


def execute_channel_margin(
    session: Session, tenant_id: str, payload: ChannelMarginRequestSchema
) -> ChannelMarginResponseSchema:
    data = ChannelMarginInput(
        currency=payload.currency, sell_price=payload.sell_price, cost_to_seller=payload.cost_to_seller,
    )
    problem_id = str(payload.problem_id) if payload.problem_id else None
    trace = build_simple_trace(tenant_id, problem_id, "pricing-formulas-1.0.0", serialize_inputs(data))

    try:
        result = calculate_channel_margin(data)
    except InsufficientEvidenceError as exc:
        log_event(
            session, tenant_id=tenant_id, event_type="CHANNEL_MARGIN_BLOCKED",
            execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
            notes_fa=exc.explanation_fa,
        )
        return ChannelMarginResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )

    log_event(
        session, tenant_id=tenant_id, event_type="CHANNEL_MARGIN_EXECUTED",
        execution_id=trace.execution_id, payload={"margin_per_unit": str(result.margin_per_unit)},
    )
    return ChannelMarginResponseSchema(
        status="OK", currency=result.currency, margin_per_unit=result.margin_per_unit,
        margin_pct=result.margin_pct, trace=_trace_schema(trace),
    )


def execute_channel_conflict(
    session: Session, tenant_id: str, payload: ChannelConflictRequestSchema
) -> ChannelConflictResponseSchema:
    data = ChannelConflictInput(
        currency=payload.currency, price_to_dealer=payload.price_to_dealer,
        price_to_sub_dealer=payload.price_to_sub_dealer,
    )
    problem_id = str(payload.problem_id) if payload.problem_id else None
    trace = build_simple_trace(tenant_id, problem_id, "pricing-formulas-1.0.0", serialize_inputs(data))

    try:
        result = detect_channel_conflict(data)
    except InsufficientEvidenceError as exc:
        log_event(
            session, tenant_id=tenant_id, event_type="CHANNEL_CONFLICT_BLOCKED",
            execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
            notes_fa=exc.explanation_fa,
        )
        return ChannelConflictResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )

    log_event(
        session, tenant_id=tenant_id, event_type="CHANNEL_CONFLICT_EXECUTED",
        execution_id=trace.execution_id, payload={"conflict_detected": result.conflict_detected},
    )
    return ChannelConflictResponseSchema(
        status="OK", currency=result.currency, conflict_detected=result.conflict_detected,
        price_gap=result.price_gap, explanation_fa=result.explanation_fa, trace=_trace_schema(trace),
    )


def execute_credit_economics(
    session: Session, tenant_id: str, payload: CreditEconomicsRequestSchema
) -> CreditEconomicsResponseSchema:
    data = CreditEconomicsInput(
        currency=payload.currency, incremental_margin=payload.incremental_margin,
        financing_cost=payload.financing_cost, expected_credit_loss=payload.expected_credit_loss,
        collection_cost=payload.collection_cost,
    )
    problem_id = str(payload.problem_id) if payload.problem_id else None
    trace = build_simple_trace(tenant_id, problem_id, "pricing-formulas-1.0.0", serialize_inputs(data))

    try:
        result = calculate_credit_adjusted_margin(data)
    except InsufficientEvidenceError as exc:
        log_event(
            session, tenant_id=tenant_id, event_type="CREDIT_ECONOMICS_BLOCKED",
            execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
            notes_fa=exc.explanation_fa,
        )
        return CreditEconomicsResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )

    log_event(
        session, tenant_id=tenant_id, event_type="CREDIT_ECONOMICS_EXECUTED",
        execution_id=trace.execution_id,
        payload={"net_credit_adjusted_margin": str(result.net_credit_adjusted_margin)},
    )
    return CreditEconomicsResponseSchema(
        status="OK", currency=result.currency,
        net_credit_adjusted_margin=result.net_credit_adjusted_margin,
        explanation_fa=result.explanation_fa, trace=_trace_schema(trace),
    )
