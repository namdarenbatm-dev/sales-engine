import uuid
from decimal import Decimal

from pydantic import BaseModel, Field

from app.domain.decision.schemas_stage2 import TraceSchema


class SalesGrowthRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    previous_period_value: Decimal
    current_period_value: Decimal


class SalesGrowthResponseSchema(BaseModel):
    status: str
    growth_rate_pct: Decimal | None = None
    absolute_change: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


class FunnelStageSchema(BaseModel):
    stage_name_fa: str
    count: Decimal


class SalesFunnelRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    stages: list[FunnelStageSchema]


class FunnelConversionSchema(BaseModel):
    from_stage_fa: str
    to_stage_fa: str
    conversion_rate_pct: Decimal | None


class SalesFunnelResponseSchema(BaseModel):
    status: str
    conversions: list[FunnelConversionSchema] = Field(default_factory=list)
    overall_conversion_pct: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


class SalesProductivityRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    output_value: Decimal
    input_value: Decimal


class SalesProductivityResponseSchema(BaseModel):
    status: str
    productivity_ratio: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


class ForecastResponseSchema(BaseModel):
    status: str
    forecast_next_period: Decimal | None = None
    method_fa: str | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


class NaiveForecastRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    historical_values: list[Decimal]


class MovingAverageRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    historical_values: list[Decimal]
    window: int


class WeightedMovingAverageRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    historical_values: list[Decimal]
    weights: list[Decimal]


class ExponentialSmoothingRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    historical_values: list[Decimal]
    alpha: Decimal
