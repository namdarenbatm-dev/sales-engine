from sqlalchemy.orm import Session

from app.domain.analytics.engine import PricingCoreRequest
from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.breakeven import (
    BreakevenInput,
    calculate_breakeven_units,
)
from app.domain.analytics.scenario import (
    ScenarioDefinition,
    run_pricing_scenarios,
    run_sensitivity_analysis,
)
from app.domain.analytics.trace_utils import build_simple_trace
from app.domain.audit.service import log_event
from app.domain.decision.schemas import PricingCoreRequestSchema
from app.domain.decision.schemas_stage2 import TraceSchema
from app.domain.decision.schemas_stage5 import (
    BreakevenRequestSchema,
    BreakevenResponseSchema,
    ScenarioOutcomeSchema,
    ScenarioRequestSchema,
    ScenarioResponseSchema,
    SensitivityPointSchema,
    SensitivityRequestSchema,
    SensitivityResponseSchema,
)
from app.domain.decision.service import build_pricing_core_response_schema


def _to_engine_request(tenant_id: str, base: PricingCoreRequestSchema) -> PricingCoreRequest:
    return PricingCoreRequest(
        tenant_id=tenant_id,
        problem_id=str(base.problem_id) if base.problem_id else None,
        currency=base.currency,
        nominal_unit_price=base.nominal_unit_price,
        paid_units=base.paid_units,
        total_discounts=base.total_discounts,
        total_rebates=base.total_rebates,
        foc_units=base.foc_units,
        variable_cost_per_unit=base.variable_cost_per_unit,
        minimum_required_margin_pct=base.minimum_required_margin_pct,
        proposed_price=base.proposed_price,
    )


def execute_pricing_scenarios(
    session: Session, tenant_id: str, payload: ScenarioRequestSchema
) -> ScenarioResponseSchema:
    base_request = _to_engine_request(tenant_id, payload.base)
    scenario_defs = [
        ScenarioDefinition(
            name_fa=s.name_fa, scenario_type=s.scenario_type, multipliers=s.multipliers
        )
        for s in payload.scenarios
    ]

    outcomes = run_pricing_scenarios(base_request, scenario_defs)

    outcome_schemas = []
    for outcome in outcomes:
        response = build_pricing_core_response_schema(outcome.result)
        outcome_schemas.append(
            ScenarioOutcomeSchema(
                name_fa=outcome.name_fa, scenario_type=outcome.scenario_type, result=response
            )
        )
        log_event(
            session,
            tenant_id=tenant_id,
            event_type="PRICING_SCENARIO_EXECUTED",
            execution_id=outcome.result.trace.execution_id,
            payload={"scenario_name_fa": outcome.name_fa, "scenario_type": outcome.scenario_type,
                      "status": outcome.result.status},
        )

    return ScenarioResponseSchema(outcomes=outcome_schemas)


def execute_sensitivity_analysis(
    session: Session, tenant_id: str, payload: SensitivityRequestSchema
) -> SensitivityResponseSchema:
    base_request = _to_engine_request(tenant_id, payload.base)
    results = run_sensitivity_analysis(base_request, payload.field, payload.test_values)

    points = []
    for value, result in results:
        response = build_pricing_core_response_schema(result)
        points.append(SensitivityPointSchema(value=value, result=response))
        log_event(
            session,
            tenant_id=tenant_id,
            event_type="PRICING_SENSITIVITY_POINT_EXECUTED",
            execution_id=result.trace.execution_id,
            payload={"field": payload.field, "value": str(value), "status": result.status},
        )

    return SensitivityResponseSchema(field=payload.field, points=points)


def execute_breakeven(
    session: Session, tenant_id: str, payload: BreakevenRequestSchema
) -> BreakevenResponseSchema:
    data = BreakevenInput(
        fixed_cost=payload.fixed_cost, contribution_margin_per_unit=payload.contribution_margin_per_unit
    )
    problem_id = str(payload.problem_id) if payload.problem_id else None
    raw_inputs = {
        "fixed_cost": str(payload.fixed_cost),
        "contribution_margin_per_unit": str(payload.contribution_margin_per_unit),
    }
    trace = build_simple_trace(tenant_id, problem_id, "pricing-formulas-1.0.0", raw_inputs)
    trace_schema = TraceSchema(
        execution_id=trace.execution_id, engine_version=trace.engine_version,
        formula_version=trace.formula_version, executed_at=trace.executed_at,
        problem_id=trace.problem_id,
    )

    try:
        result = calculate_breakeven_units(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="BREAKEVEN_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return BreakevenResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields, trace=trace_schema,
        )

    log_event(session, tenant_id=tenant_id, event_type="BREAKEVEN_EXECUTED",
               execution_id=trace.execution_id, payload={"breakeven_units": str(result.breakeven_units)})
    return BreakevenResponseSchema(
        status="OK", breakeven_units=result.breakeven_units, trace=trace_schema,
    )
