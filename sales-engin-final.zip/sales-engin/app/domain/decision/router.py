from fastapi import APIRouter, Header

from app.core.database import get_session, require_tenant_id
from app.domain.decision.schemas import PricingCoreRequestSchema, PricingCoreResponseSchema
from app.domain.decision.service import execute_pricing_core

router = APIRouter(prefix="/api/v1/pricing-core", tags=["pricing-core"])


@router.post("/calculate", response_model=PricingCoreResponseSchema)
def calculate_pricing_core(
    payload: PricingCoreRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> PricingCoreResponseSchema:
    tenant_id = require_tenant_id(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_pricing_core(session, tenant_id, payload)
