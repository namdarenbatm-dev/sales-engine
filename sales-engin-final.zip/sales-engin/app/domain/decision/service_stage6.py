from sqlalchemy.orm import Session

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.action_value import ActionValueInput, calculate_action_value
from app.domain.analytics.formulas.negotiation import (
    NegotiationOptionInput,
    calculate_negotiation_option_impact,
)
from app.domain.analytics.trace_utils import build_simple_trace, serialize_inputs
from app.domain.audit.service import log_event
from app.domain.decision.schemas_stage2 import TraceSchema
from app.domain.decision.schemas_stage6 import (
    ActionValueRequestSchema,
    ActionValueResponseSchema,
    B2CActionOptionsRequestSchema,
    B2CActionOptionsResponseSchema,
    NegotiationOptionRequestSchema,
    NegotiationOptionResponseSchema,
)


def _trace_schema(trace) -> TraceSchema:
    return TraceSchema(
        execution_id=trace.execution_id, engine_version=trace.engine_version,
        formula_version=trace.formula_version, executed_at=trace.executed_at,
        problem_id=trace.problem_id,
    )


def _pid(payload) -> str | None:
    return str(payload.problem_id) if payload.problem_id else None


def execute_negotiation_option(
    session: Session, tenant_id: str, payload: NegotiationOptionRequestSchema
) -> NegotiationOptionResponseSchema:
    data = NegotiationOptionInput(
        currency=payload.currency, baseline_unit_price=payload.baseline_unit_price,
        baseline_volume=payload.baseline_volume, variable_cost_per_unit=payload.variable_cost_per_unit,
        concession_price_reduction_per_unit=payload.concession_price_reduction_per_unit,
        counterpart_volume_increase_units=payload.counterpart_volume_increase_units,
        counterpart_payment_days_reduction=payload.counterpart_payment_days_reduction,
        daily_financing_rate=payload.daily_financing_rate,
    )
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", serialize_inputs(data))
    try:
        result = calculate_negotiation_option_impact(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="NEGOTIATION_OPTION_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return NegotiationOptionResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )
    log_event(session, tenant_id=tenant_id, event_type="NEGOTIATION_OPTION_EXECUTED",
               execution_id=trace.execution_id,
               payload={"net_economic_effect": str(result.net_economic_effect)})
    return NegotiationOptionResponseSchema(
        status="OK", currency=result.currency, baseline_margin_total=result.baseline_margin_total,
        new_margin_total=result.new_margin_total, margin_impact=result.margin_impact,
        cash_flow_benefit=result.cash_flow_benefit, net_economic_effect=result.net_economic_effect,
        trace=_trace_schema(trace),
    )


def _execute_single_action_value(
    session: Session, tenant_id: str, payload: ActionValueRequestSchema
) -> ActionValueResponseSchema:
    data = ActionValueInput(
        currency=payload.currency, expected_economic_impact=payload.expected_economic_impact,
        action_cost=payload.action_cost, risk_cost=payload.risk_cost,
    )
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", serialize_inputs(data))
    try:
        result = calculate_action_value(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="ACTION_VALUE_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return ActionValueResponseSchema(
            status="BLOCKED", action_label_fa=payload.action_label_fa,
            headline_fa=InsufficientEvidenceError.HEADLINE_FA, explanation_fa=exc.explanation_fa,
            missing_fields=exc.missing_fields, trace=_trace_schema(trace),
        )
    log_event(session, tenant_id=tenant_id, event_type="ACTION_VALUE_EXECUTED",
               execution_id=trace.execution_id, payload={"action_value": str(result.action_value)})
    return ActionValueResponseSchema(
        status="OK", action_label_fa=payload.action_label_fa, currency=result.currency,
        action_value=result.action_value, trace=_trace_schema(trace),
    )


def execute_action_value(
    session: Session, tenant_id: str, payload: ActionValueRequestSchema
) -> ActionValueResponseSchema:
    return _execute_single_action_value(session, tenant_id, payload)


def execute_b2c_action_options(
    session: Session, tenant_id: str, payload: B2CActionOptionsRequestSchema
) -> B2CActionOptionsResponseSchema:
    no_action = ActionValueRequestSchema(
        problem_id=payload.problem_id, action_label_fa="بدون اقدام", currency=payload.currency,
        expected_economic_impact=0, action_cost=0, risk_cost=0,
    )
    all_candidates = [no_action] + list(payload.candidate_actions)

    options = [
        _execute_single_action_value(session, tenant_id, candidate) for candidate in all_candidates
    ]
    return B2CActionOptionsResponseSchema(options=options)
