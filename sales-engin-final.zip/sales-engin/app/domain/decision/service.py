from sqlalchemy.orm import Session

from app.domain.analytics.engine import PricingCoreRequest, run_pricing_core
from app.domain.audit.service import log_event
from app.domain.decision.schemas import (
    CalculationTraceSchema,
    DecisionOptionSchema,
    PricingCoreRequestSchema,
    PricingCoreResponseSchema,
)


def build_pricing_core_response_schema(result) -> PricingCoreResponseSchema:
    """قابل‌استفاده مجدد در موتور سناریو/حساسیت — تبدیل نتیجه خام موتور به schema پاسخ."""
    trace_schema = CalculationTraceSchema(
        execution_id=result.trace.execution_id,
        engine_version=result.trace.engine_version,
        formula_version=result.trace.formula_version,
        executed_at=result.trace.executed_at,
        problem_id=result.trace.problem_id,
    )

    if result.status == "BLOCKED":
        return PricingCoreResponseSchema(
            status="BLOCKED",
            headline_fa=result.headline_fa,
            explanation_fa=result.explanation_fa,
            missing_fields=result.missing_fields,
            trace=trace_schema,
        )

    return PricingCoreResponseSchema(
        status="OK",
        currency=result.currency,
        effective_unit_price=result.effective_unit_price,
        contribution_margin_per_unit=result.contribution_margin_per_unit,
        contribution_margin_pct=result.contribution_margin_pct,
        price_floor_effective_unit_price=result.price_floor_effective_unit_price,
        decision_options=[
            DecisionOptionSchema(**vars(option)) for option in result.decision_options
        ],
        trace=trace_schema,
    )


def execute_pricing_core(
    session: Session, tenant_id: str, payload: PricingCoreRequestSchema
) -> PricingCoreResponseSchema:
    request = PricingCoreRequest(
        tenant_id=tenant_id,
        problem_id=str(payload.problem_id) if payload.problem_id else None,
        currency=payload.currency,
        nominal_unit_price=payload.nominal_unit_price,
        paid_units=payload.paid_units,
        total_discounts=payload.total_discounts,
        total_rebates=payload.total_rebates,
        foc_units=payload.foc_units,
        variable_cost_per_unit=payload.variable_cost_per_unit,
        minimum_required_margin_pct=payload.minimum_required_margin_pct,
        proposed_price=payload.proposed_price,
    )

    result = run_pricing_core(request)
    response = build_pricing_core_response_schema(result)

    if result.status == "BLOCKED":
        log_event(
            session,
            tenant_id=tenant_id,
            event_type="PRICING_CORE_CALCULATION_BLOCKED",
            execution_id=result.trace.execution_id,
            payload={"missing_fields": result.missing_fields, "raw_inputs": result.trace.raw_inputs},
            notes_fa=result.explanation_fa,
        )
        return response

    log_event(
        session,
        tenant_id=tenant_id,
        event_type="PRICING_CORE_CALCULATION_EXECUTED",
        execution_id=result.trace.execution_id,
        payload={
            "raw_inputs": result.trace.raw_inputs,
            "effective_unit_price": str(result.effective_unit_price),
            "contribution_margin_per_unit": str(result.contribution_margin_per_unit),
            "price_floor_effective_unit_price": str(result.price_floor_effective_unit_price),
        },
        notes_fa="محاسبه هسته قیمت‌گذاری با موفقیت اجرا شد.",
    )
    return response
