import uuid
from decimal import Decimal

from pydantic import BaseModel, Field


class PricingCoreRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = Field(
        default=None, description="شناسه مسئله مرتبط (اختیاری) — برای اتصال محاسبه به مسئله ثبت‌شده"
    )
    currency: str = Field(..., min_length=3, max_length=3, description="کد واحد پول، مثل IRR یا USD")
    nominal_unit_price: Decimal = Field(..., description="قیمت اسمی هر واحد")
    paid_units: Decimal = Field(..., description="تعداد واحد فروخته‌شده (پرداخت‌شده)")
    total_discounts: Decimal = Field(default=Decimal("0"), description="جمع تخفیف‌ها")
    total_rebates: Decimal = Field(default=Decimal("0"), description="جمع پاداش فروش (rebate)")
    foc_units: Decimal = Field(default=Decimal("0"), description="تعداد واحد کالای رایگان همراه خرید")
    variable_cost_per_unit: Decimal = Field(..., description="هزینه متغیر هر واحد")
    minimum_required_margin_pct: Decimal = Field(
        ..., description="حداقل درصد حاشیه سود قابل‌قبول، مثلاً 0.15 برای 15٪"
    )
    proposed_price: Decimal | None = Field(
        default=None, description="قیمت پیشنهادی برای مقایسه با کف قیمت (اختیاری)"
    )


class DecisionOptionSchema(BaseModel):
    option_code: str
    label_fa: str
    rationale_fa: str
    risk_fa: str | None
    supported_by_evidence: bool


class CalculationTraceSchema(BaseModel):
    execution_id: str
    engine_version: str
    formula_version: str
    executed_at: str
    problem_id: uuid.UUID | None = None


class PricingCoreResponseSchema(BaseModel):
    status: str
    currency: str | None = None
    effective_unit_price: Decimal | None = None
    contribution_margin_per_unit: Decimal | None = None
    contribution_margin_pct: Decimal | None = None
    price_floor_effective_unit_price: Decimal | None = None
    decision_options: list[DecisionOptionSchema] = Field(default_factory=list)
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: CalculationTraceSchema
