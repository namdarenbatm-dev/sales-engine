from sqlalchemy.orm import Session

from app.domain.analytics.exceptions import InsufficientEvidenceError
from app.domain.analytics.formulas.forecasting import (
    ExponentialSmoothingInput,
    MovingAverageInput,
    NaiveForecastInput,
    WeightedMovingAverageInput,
    calculate_exponential_smoothing_forecast,
    calculate_moving_average_forecast,
    calculate_naive_forecast,
    calculate_weighted_moving_average_forecast,
)
from app.domain.analytics.formulas.sales_performance import (
    FunnelStage,
    SalesFunnelInput,
    SalesGrowthInput,
    SalesProductivityInput,
    calculate_sales_funnel,
    calculate_sales_growth,
    calculate_sales_productivity,
)
from app.domain.analytics.trace_utils import build_simple_trace, serialize_inputs
from app.domain.audit.service import log_event
from app.domain.decision.schemas_stage2 import TraceSchema
from app.domain.decision.schemas_stage3 import (
    ExponentialSmoothingRequestSchema,
    ForecastResponseSchema,
    FunnelConversionSchema,
    MovingAverageRequestSchema,
    NaiveForecastRequestSchema,
    SalesFunnelRequestSchema,
    SalesFunnelResponseSchema,
    SalesGrowthRequestSchema,
    SalesGrowthResponseSchema,
    SalesProductivityRequestSchema,
    SalesProductivityResponseSchema,
    WeightedMovingAverageRequestSchema,
)


def _trace_schema(trace) -> TraceSchema:
    return TraceSchema(
        execution_id=trace.execution_id, engine_version=trace.engine_version,
        formula_version=trace.formula_version, executed_at=trace.executed_at,
        problem_id=trace.problem_id,
    )


def _pid(payload) -> str | None:
    return str(payload.problem_id) if payload.problem_id else None


def execute_sales_growth(
    session: Session, tenant_id: str, payload: SalesGrowthRequestSchema
) -> SalesGrowthResponseSchema:
    data = SalesGrowthInput(
        previous_period_value=payload.previous_period_value,
        current_period_value=payload.current_period_value,
    )
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", serialize_inputs(data))
    try:
        result = calculate_sales_growth(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="SALES_GROWTH_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return SalesGrowthResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )
    log_event(session, tenant_id=tenant_id, event_type="SALES_GROWTH_EXECUTED",
               execution_id=trace.execution_id, payload={"growth_rate_pct": str(result.growth_rate_pct)})
    return SalesGrowthResponseSchema(
        status="OK", growth_rate_pct=result.growth_rate_pct, absolute_change=result.absolute_change,
        trace=_trace_schema(trace),
    )


def execute_sales_funnel(
    session: Session, tenant_id: str, payload: SalesFunnelRequestSchema
) -> SalesFunnelResponseSchema:
    stages = [FunnelStage(s.stage_name_fa, s.count) for s in payload.stages]
    data = SalesFunnelInput(stages=stages)
    raw_inputs = {"stages": [{"stage_name_fa": s.stage_name_fa, "count": str(s.count)} for s in stages]}
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", raw_inputs)
    try:
        result = calculate_sales_funnel(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="SALES_FUNNEL_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return SalesFunnelResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )
    log_event(session, tenant_id=tenant_id, event_type="SALES_FUNNEL_EXECUTED",
               execution_id=trace.execution_id,
               payload={"overall_conversion_pct": str(result.overall_conversion_pct)})
    return SalesFunnelResponseSchema(
        status="OK",
        conversions=[
            FunnelConversionSchema(
                from_stage_fa=c.from_stage_fa, to_stage_fa=c.to_stage_fa,
                conversion_rate_pct=c.conversion_rate_pct,
            )
            for c in result.conversions
        ],
        overall_conversion_pct=result.overall_conversion_pct, trace=_trace_schema(trace),
    )


def execute_sales_productivity(
    session: Session, tenant_id: str, payload: SalesProductivityRequestSchema
) -> SalesProductivityResponseSchema:
    data = SalesProductivityInput(output_value=payload.output_value, input_value=payload.input_value)
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", serialize_inputs(data))
    try:
        result = calculate_sales_productivity(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="SALES_PRODUCTIVITY_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return SalesProductivityResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )
    log_event(session, tenant_id=tenant_id, event_type="SALES_PRODUCTIVITY_EXECUTED",
               execution_id=trace.execution_id,
               payload={"productivity_ratio": str(result.productivity_ratio)})
    return SalesProductivityResponseSchema(
        status="OK", productivity_ratio=result.productivity_ratio, trace=_trace_schema(trace),
    )


def _forecast_response(trace, result=None, exc=None) -> ForecastResponseSchema:
    if exc is not None:
        return ForecastResponseSchema(
            status="BLOCKED", headline_fa=InsufficientEvidenceError.HEADLINE_FA,
            explanation_fa=exc.explanation_fa, missing_fields=exc.missing_fields,
            trace=_trace_schema(trace),
        )
    return ForecastResponseSchema(
        status="OK", forecast_next_period=result.forecast_next_period, method_fa=result.method_fa,
        trace=_trace_schema(trace),
    )


def execute_naive_forecast(
    session: Session, tenant_id: str, payload: NaiveForecastRequestSchema
) -> ForecastResponseSchema:
    data = NaiveForecastInput(payload.historical_values)
    raw = {"historical_values": [str(v) for v in payload.historical_values]}
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", raw)
    try:
        result = calculate_naive_forecast(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="NAIVE_FORECAST_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return _forecast_response(trace, exc=exc)
    log_event(session, tenant_id=tenant_id, event_type="NAIVE_FORECAST_EXECUTED",
               execution_id=trace.execution_id,
               payload={"forecast_next_period": str(result.forecast_next_period)})
    return _forecast_response(trace, result=result)


def execute_moving_average_forecast(
    session: Session, tenant_id: str, payload: MovingAverageRequestSchema
) -> ForecastResponseSchema:
    data = MovingAverageInput(payload.historical_values, window=payload.window)
    raw = {"historical_values": [str(v) for v in payload.historical_values], "window": payload.window}
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", raw)
    try:
        result = calculate_moving_average_forecast(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="MOVING_AVERAGE_FORECAST_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return _forecast_response(trace, exc=exc)
    log_event(session, tenant_id=tenant_id, event_type="MOVING_AVERAGE_FORECAST_EXECUTED",
               execution_id=trace.execution_id,
               payload={"forecast_next_period": str(result.forecast_next_period)})
    return _forecast_response(trace, result=result)


def execute_weighted_moving_average_forecast(
    session: Session, tenant_id: str, payload: WeightedMovingAverageRequestSchema
) -> ForecastResponseSchema:
    data = WeightedMovingAverageInput(payload.historical_values, weights=payload.weights)
    raw = {
        "historical_values": [str(v) for v in payload.historical_values],
        "weights": [str(w) for w in payload.weights],
    }
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", raw)
    try:
        result = calculate_weighted_moving_average_forecast(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="WEIGHTED_MOVING_AVERAGE_FORECAST_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return _forecast_response(trace, exc=exc)
    log_event(session, tenant_id=tenant_id, event_type="WEIGHTED_MOVING_AVERAGE_FORECAST_EXECUTED",
               execution_id=trace.execution_id,
               payload={"forecast_next_period": str(result.forecast_next_period)})
    return _forecast_response(trace, result=result)


def execute_exponential_smoothing_forecast(
    session: Session, tenant_id: str, payload: ExponentialSmoothingRequestSchema
) -> ForecastResponseSchema:
    data = ExponentialSmoothingInput(payload.historical_values, alpha=payload.alpha)
    raw = {"historical_values": [str(v) for v in payload.historical_values], "alpha": str(payload.alpha)}
    trace = build_simple_trace(tenant_id, _pid(payload), "pricing-formulas-1.0.0", raw)
    try:
        result = calculate_exponential_smoothing_forecast(data)
    except InsufficientEvidenceError as exc:
        log_event(session, tenant_id=tenant_id, event_type="EXPONENTIAL_SMOOTHING_FORECAST_BLOCKED",
                   execution_id=trace.execution_id, payload={"missing_fields": exc.missing_fields},
                   notes_fa=exc.explanation_fa)
        return _forecast_response(trace, exc=exc)
    log_event(session, tenant_id=tenant_id, event_type="EXPONENTIAL_SMOOTHING_FORECAST_EXECUTED",
               execution_id=trace.execution_id,
               payload={"forecast_next_period": str(result.forecast_next_period)})
    return _forecast_response(trace, result=result)
