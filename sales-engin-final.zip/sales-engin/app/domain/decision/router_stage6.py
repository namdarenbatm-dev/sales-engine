from fastapi import APIRouter, Header

from app.core.database import get_session, require_tenant_id
from app.domain.decision.schemas_stage6 import (
    ActionValueRequestSchema,
    ActionValueResponseSchema,
    B2CActionOptionsRequestSchema,
    B2CActionOptionsResponseSchema,
    NegotiationOptionRequestSchema,
    NegotiationOptionResponseSchema,
)
from app.domain.decision.service_stage6 import (
    execute_action_value,
    execute_b2c_action_options,
    execute_negotiation_option,
)

router = APIRouter(tags=["negotiation-action"])


def _tenant(x_tenant_id: str | None) -> str:
    return require_tenant_id(x_tenant_id)


@router.post("/api/v1/negotiation/evaluate-option", response_model=NegotiationOptionResponseSchema)
def negotiation_evaluate_option(
    payload: NegotiationOptionRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> NegotiationOptionResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_negotiation_option(session, tenant_id, payload)


@router.post("/api/v1/action/value", response_model=ActionValueResponseSchema)
def action_value(
    payload: ActionValueRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ActionValueResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_action_value(session, tenant_id, payload)


@router.post("/api/v1/action/b2c-options", response_model=B2CActionOptionsResponseSchema)
def b2c_action_options(
    payload: B2CActionOptionsRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> B2CActionOptionsResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_b2c_action_options(session, tenant_id, payload)
