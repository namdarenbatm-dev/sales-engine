import uuid
from decimal import Decimal

from pydantic import BaseModel, Field


class TraceSchema(BaseModel):
    execution_id: str
    engine_version: str
    formula_version: str
    executed_at: str
    problem_id: uuid.UUID | None = None


class BlockedFieldsSchema(BaseModel):
    status: str = "BLOCKED"
    headline_fa: str
    explanation_fa: str
    missing_fields: list[str]
    trace: TraceSchema


# --- پاداش فروش ---


class RebateEquivalentRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    currency: str = Field(..., min_length=3, max_length=3)
    nominal_unit_price: Decimal
    rebate_rate_pct: Decimal


class RebateEquivalentResponseSchema(BaseModel):
    status: str
    currency: str | None = None
    rebate_equivalent_unit_price: Decimal | None = None
    rebate_amount_per_unit: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


# --- کالای رایگان همراه خرید ---


class FocEquivalentRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    currency: str = Field(..., min_length=3, max_length=3)
    purchased_units: Decimal
    unit_price: Decimal
    foc_units: Decimal = Decimal("0")


class FocEquivalentResponseSchema(BaseModel):
    status: str
    currency: str | None = None
    effective_unit_cost: Decimal | None = None
    total_delivered_units: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


# --- حاشیه کانال ---


class ChannelMarginRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    currency: str = Field(..., min_length=3, max_length=3)
    sell_price: Decimal
    cost_to_seller: Decimal


class ChannelMarginResponseSchema(BaseModel):
    status: str
    currency: str | None = None
    margin_per_unit: Decimal | None = None
    margin_pct: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


# --- تعارض کانال ---


class ChannelConflictRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    currency: str = Field(..., min_length=3, max_length=3)
    price_to_dealer: Decimal
    price_to_sub_dealer: Decimal


class ChannelConflictResponseSchema(BaseModel):
    status: str
    currency: str | None = None
    conflict_detected: bool | None = None
    price_gap: Decimal | None = None
    explanation_fa: str | None = None
    headline_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


# --- اقتصاد اعتبار ---


class CreditEconomicsRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    currency: str = Field(..., min_length=3, max_length=3)
    incremental_margin: Decimal
    financing_cost: Decimal
    expected_credit_loss: Decimal
    collection_cost: Decimal


class CreditEconomicsResponseSchema(BaseModel):
    status: str
    currency: str | None = None
    net_credit_adjusted_margin: Decimal | None = None
    explanation_fa: str | None = None
    headline_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema
