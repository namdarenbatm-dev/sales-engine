import uuid
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field

from app.domain.decision.schemas import PricingCoreRequestSchema, PricingCoreResponseSchema
from app.domain.decision.schemas_stage2 import TraceSchema

ScenarioTypeSchema = Literal["UPSIDE", "DOWNSIDE", "STRESS", "CUSTOM"]


class ScenarioDefinitionSchema(BaseModel):
    name_fa: str
    scenario_type: ScenarioTypeSchema
    multipliers: dict[str, Decimal] = Field(
        ..., description="مثلاً {'paid_units': 0.8} یعنی ۸۰٪ مقدار پایه"
    )


class ScenarioRequestSchema(BaseModel):
    base: PricingCoreRequestSchema
    scenarios: list[ScenarioDefinitionSchema]


class ScenarioOutcomeSchema(BaseModel):
    name_fa: str
    scenario_type: str
    result: PricingCoreResponseSchema


class ScenarioResponseSchema(BaseModel):
    outcomes: list[ScenarioOutcomeSchema]
    disclaimer_fa: str = (
        "این سناریوها پیش‌بینی قطعی نیستند و صرفاً حساسیت نتیجه به تغییر فرض‌ها را نشان می‌دهند. "
        "هیچ سناریویی به‌عنوان «سناریوی درست» یا محتمل‌ترین آینده اعلام نشده است."
    )


class SensitivityRequestSchema(BaseModel):
    base: PricingCoreRequestSchema
    field: str = Field(
        ..., description="یکی از: nominal_unit_price، paid_units، total_discounts، total_rebates، variable_cost_per_unit"
    )
    test_values: list[Decimal]


class SensitivityPointSchema(BaseModel):
    value: Decimal
    result: PricingCoreResponseSchema


class SensitivityResponseSchema(BaseModel):
    field: str
    points: list[SensitivityPointSchema]


class BreakevenRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    fixed_cost: Decimal
    contribution_margin_per_unit: Decimal


class BreakevenResponseSchema(BaseModel):
    status: str
    breakeven_units: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema
