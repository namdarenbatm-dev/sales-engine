import uuid
from decimal import Decimal

from pydantic import BaseModel, Field

from app.domain.decision.schemas_stage2 import TraceSchema


class NegotiationOptionRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    currency: str = Field(..., min_length=3, max_length=3)
    baseline_unit_price: Decimal
    baseline_volume: Decimal
    variable_cost_per_unit: Decimal
    concession_price_reduction_per_unit: Decimal
    counterpart_volume_increase_units: Decimal = Decimal("0")
    counterpart_payment_days_reduction: Decimal = Decimal("0")
    daily_financing_rate: Decimal = Decimal("0")


class NegotiationOptionResponseSchema(BaseModel):
    status: str
    currency: str | None = None
    baseline_margin_total: Decimal | None = None
    new_margin_total: Decimal | None = None
    margin_impact: Decimal | None = None
    cash_flow_benefit: Decimal | None = None
    net_economic_effect: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


class ActionValueRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    action_label_fa: str = Field(..., description="مثلاً «تماس تلفنی»، «پیشنهاد بازگشت کالا»")
    currency: str = Field(..., min_length=3, max_length=3)
    expected_economic_impact: Decimal
    action_cost: Decimal
    risk_cost: Decimal


class ActionValueResponseSchema(BaseModel):
    status: str
    action_label_fa: str | None = None
    currency: str | None = None
    action_value: Decimal | None = None
    headline_fa: str | None = None
    explanation_fa: str | None = None
    missing_fields: list[str] = Field(default_factory=list)
    trace: TraceSchema


class B2CActionOptionsRequestSchema(BaseModel):
    problem_id: uuid.UUID | None = None
    currency: str = Field(..., min_length=3, max_length=3)
    candidate_actions: list[ActionValueRequestSchema] = Field(
        ..., description="گزینه‌های اقدام کاندید (غیر از «بدون اقدام» که خودکار افزوده می‌شود)"
    )


class B2CActionOptionsResponseSchema(BaseModel):
    options: list[ActionValueResponseSchema]
    disclaimer_fa: str = (
        "این فهرست هیچ گزینه‌ای را «بهترین اقدام» اعلام نمی‌کند. «بدون اقدام» همیشه یک گزینه "
        "معتبر است و به‌صورت خودکار با ارزش صفر در فهرست قرار گرفته."
    )
