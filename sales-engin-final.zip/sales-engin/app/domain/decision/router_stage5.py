from fastapi import APIRouter, Header, HTTPException

from app.core.database import get_session, require_tenant_id
from app.domain.decision.schemas_stage5 import (
    BreakevenRequestSchema,
    BreakevenResponseSchema,
    ScenarioRequestSchema,
    ScenarioResponseSchema,
    SensitivityRequestSchema,
    SensitivityResponseSchema,
)
from app.domain.decision.service_stage5 import (
    execute_breakeven,
    execute_pricing_scenarios,
    execute_sensitivity_analysis,
)

router = APIRouter(prefix="/api/v1/pricing-core", tags=["scenario-sensitivity-breakeven"])


def _tenant(x_tenant_id: str | None) -> str:
    return require_tenant_id(x_tenant_id)


@router.post("/scenarios", response_model=ScenarioResponseSchema)
def pricing_scenarios(
    payload: ScenarioRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ScenarioResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        try:
            return execute_pricing_scenarios(session, tenant_id, payload)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))


@router.post("/sensitivity", response_model=SensitivityResponseSchema)
def pricing_sensitivity(
    payload: SensitivityRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> SensitivityResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        try:
            return execute_sensitivity_analysis(session, tenant_id, payload)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))


@router.post("/breakeven", response_model=BreakevenResponseSchema)
def pricing_breakeven(
    payload: BreakevenRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> BreakevenResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_breakeven(session, tenant_id, payload)
