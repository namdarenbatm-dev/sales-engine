from fastapi import APIRouter, Header

from app.core.database import get_session, require_tenant_id
from app.domain.decision.schemas_stage2 import (
    ChannelConflictRequestSchema,
    ChannelConflictResponseSchema,
    ChannelMarginRequestSchema,
    ChannelMarginResponseSchema,
    CreditEconomicsRequestSchema,
    CreditEconomicsResponseSchema,
    FocEquivalentRequestSchema,
    FocEquivalentResponseSchema,
    RebateEquivalentRequestSchema,
    RebateEquivalentResponseSchema,
)
from app.domain.decision.service_stage2 import (
    execute_channel_conflict,
    execute_channel_margin,
    execute_credit_economics,
    execute_foc_equivalent,
    execute_rebate_equivalent,
)

router = APIRouter(tags=["incentives-channel-credit"])


def _tenant(x_tenant_id: str | None) -> str:
    return require_tenant_id(x_tenant_id)


@router.post("/api/v1/incentives/rebate-equivalent", response_model=RebateEquivalentResponseSchema)
def rebate_equivalent(
    payload: RebateEquivalentRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> RebateEquivalentResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_rebate_equivalent(session, tenant_id, payload)


@router.post("/api/v1/incentives/foc-equivalent", response_model=FocEquivalentResponseSchema)
def foc_equivalent(
    payload: FocEquivalentRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> FocEquivalentResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_foc_equivalent(session, tenant_id, payload)


@router.post("/api/v1/channel/margin", response_model=ChannelMarginResponseSchema)
def channel_margin(
    payload: ChannelMarginRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ChannelMarginResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_channel_margin(session, tenant_id, payload)


@router.post("/api/v1/channel/conflict", response_model=ChannelConflictResponseSchema)
def channel_conflict(
    payload: ChannelConflictRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ChannelConflictResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_channel_conflict(session, tenant_id, payload)


@router.post("/api/v1/credit/economics", response_model=CreditEconomicsResponseSchema)
def credit_economics(
    payload: CreditEconomicsRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> CreditEconomicsResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_credit_economics(session, tenant_id, payload)
