from fastapi import APIRouter, Header

from app.core.database import get_session, require_tenant_id
from app.domain.decision.schemas_stage3 import (
    ExponentialSmoothingRequestSchema,
    ForecastResponseSchema,
    MovingAverageRequestSchema,
    NaiveForecastRequestSchema,
    SalesFunnelRequestSchema,
    SalesFunnelResponseSchema,
    SalesGrowthRequestSchema,
    SalesGrowthResponseSchema,
    SalesProductivityRequestSchema,
    SalesProductivityResponseSchema,
    WeightedMovingAverageRequestSchema,
)
from app.domain.decision.service_stage3 import (
    execute_exponential_smoothing_forecast,
    execute_moving_average_forecast,
    execute_naive_forecast,
    execute_sales_funnel,
    execute_sales_growth,
    execute_sales_productivity,
    execute_weighted_moving_average_forecast,
)

router = APIRouter(tags=["sales-performance-forecasting"])


def _tenant(x_tenant_id: str | None) -> str:
    return require_tenant_id(x_tenant_id)


@router.post("/api/v1/sales-performance/growth", response_model=SalesGrowthResponseSchema)
def sales_growth(
    payload: SalesGrowthRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> SalesGrowthResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_sales_growth(session, tenant_id, payload)


@router.post("/api/v1/sales-performance/funnel", response_model=SalesFunnelResponseSchema)
def sales_funnel(
    payload: SalesFunnelRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> SalesFunnelResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_sales_funnel(session, tenant_id, payload)


@router.post("/api/v1/sales-performance/productivity", response_model=SalesProductivityResponseSchema)
def sales_productivity(
    payload: SalesProductivityRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> SalesProductivityResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_sales_productivity(session, tenant_id, payload)


@router.post("/api/v1/forecasting/naive", response_model=ForecastResponseSchema)
def naive_forecast(
    payload: NaiveForecastRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ForecastResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_naive_forecast(session, tenant_id, payload)


@router.post("/api/v1/forecasting/moving-average", response_model=ForecastResponseSchema)
def moving_average_forecast(
    payload: MovingAverageRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ForecastResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_moving_average_forecast(session, tenant_id, payload)


@router.post("/api/v1/forecasting/weighted-moving-average", response_model=ForecastResponseSchema)
def weighted_moving_average_forecast(
    payload: WeightedMovingAverageRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ForecastResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_weighted_moving_average_forecast(session, tenant_id, payload)


@router.post("/api/v1/forecasting/exponential-smoothing", response_model=ForecastResponseSchema)
def exponential_smoothing_forecast(
    payload: ExponentialSmoothingRequestSchema,
    x_tenant_id: str | None = Header(default=None, alias="X-Tenant-Id"),
) -> ForecastResponseSchema:
    tenant_id = _tenant(x_tenant_id)
    with get_session(tenant_id) as session:
        return execute_exponential_smoothing_forecast(session, tenant_id, payload)
