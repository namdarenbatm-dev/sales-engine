# زیرساخت به‌عنوان کد — نسخه حداقلی/شروع‌کننده.
#
# توجه صادقانه: این یک استقرار production-ready کامل نیست. فقط دو منبع پایه (پایگاه‌داده
# و object storage) را نشان می‌دهد تا الگوی کار روشن باشد. موارد زیر عمداً اینجا نیستند
# و باید قبل از استقرار واقعی اضافه شوند: VPC/subnet/security-group مناسب، مدیریت اسرار
# واقعی (به‌جای متغیر ساده)، backup/PITR، مقیاس‌پذیری Redis/OpenSearch، و شبکه Zero Trust.

terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

variable "environment" {
  description = "نام محیط، مثلاً staging یا production"
  type        = string
}

variable "db_password" {
  description = "رمز عبور پایگاه‌داده — در استقرار واقعی باید از یک مدیریت اسرار واقعی (Vault/AWS Secrets Manager) تأمین شود، نه متغیر Terraform ساده"
  type        = string
  sensitive   = true
}

resource "aws_db_instance" "sales_engin_postgres" {
  identifier           = "sales-engin-${var.environment}"
  engine               = "postgres"
  engine_version       = "16"
  instance_class       = "db.t3.medium"
  allocated_storage    = 50
  db_name              = "sales_engin"
  username             = "sales_engin"
  password             = var.db_password
  skip_final_snapshot  = var.environment != "production"
  backup_retention_period = 7
}

resource "aws_s3_bucket" "sales_engin_object_storage" {
  bucket = "sales-engin-${var.environment}-objects"
}

resource "aws_s3_bucket_versioning" "sales_engin_object_storage_versioning" {
  bucket = aws_s3_bucket.sales_engin_object_storage.id
  versioning_configuration {
    status = "Enabled"
  }
}

output "database_endpoint" {
  value = aws_db_instance.sales_engin_postgres.endpoint
}

output "object_storage_bucket" {
  value = aws_s3_bucket.sales_engin_object_storage.bucket
}
