// Service Worker حداقلی — فقط پوسته اپ (شِل) را کش می‌کند تا بارگذاری بعدی سریع‌تر باشد.
// این یک PWA کامل با استراتژی‌های کش پیچیده (stale-while-revalidate برای API و...) نیست.

const CACHE_NAME = "sales-engin-shell-v1";
const SHELL_URLS = ["/", "/manifest.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_URLS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // فقط GETهای هم‌مبدأ صفحه — درخواست‌های API عمداً کش نمی‌شوند تا داده بی‌اعتبار نمایش داده نشود
  if (event.request.method !== "GET") return;

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
