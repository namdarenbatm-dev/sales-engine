"use client";

import { useEffect, useState, type FormEvent } from "react";
import {
  calculatePricingCore,
  listPricingCoreModels,
  type ModelRegistryEntry,
  type PricingCoreResponse,
} from "../../lib/api";

interface FormState {
  currency: string;
  nominal_unit_price: string;
  paid_units: string;
  total_discounts: string;
  total_rebates: string;
  foc_units: string;
  variable_cost_per_unit: string;
  minimum_required_margin_pct: string; // به‌صورت درصد وارد می‌شود، مثلاً 25
  proposed_price: string;
}

const initialForm: FormState = {
  currency: "IRR",
  nominal_unit_price: "",
  paid_units: "",
  total_discounts: "0",
  total_rebates: "0",
  foc_units: "0",
  variable_cost_per_unit: "",
  minimum_required_margin_pct: "",
  proposed_price: "",
};

export default function PricingCorePage() {
  const [form, setForm] = useState<FormState>(initialForm);
  const [models, setModels] = useState<ModelRegistryEntry[]>([]);
  const [result, setResult] = useState<PricingCoreResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listPricingCoreModels()
      .then(setModels)
      .catch(() => {
        // نمایش فهرست مدل‌ها اختیاری است — اگر API در دسترس نبود، فرم همچنان قابل استفاده می‌ماند.
      });
  }, []);

  function updateField(field: keyof FormState, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const minMarginAsFraction = form.minimum_required_margin_pct
        ? (Number(form.minimum_required_margin_pct) / 100).toString()
        : "0";

      const response = await calculatePricingCore({
        currency: form.currency,
        nominal_unit_price: form.nominal_unit_price,
        paid_units: form.paid_units,
        total_discounts: form.total_discounts || "0",
        total_rebates: form.total_rebates || "0",
        foc_units: form.foc_units || "0",
        variable_cost_per_unit: form.variable_cost_per_unit,
        minimum_required_margin_pct: minMarginAsFraction,
        proposed_price: form.proposed_price || null,
      });
      setResult(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای نامشخص در ارتباط با سرور.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container">
      <div className="card">
        <h2>مسئله: تصمیم قیمت‌گذاری</h2>
        <p style={{ color: "var(--color-muted)", marginTop: -8 }}>
          داده معامله را وارد کنید تا قیمت مؤثر، حاشیه سود مشارکت و کف قیمت محاسبه شود.
        </p>
      </div>

      {models.length > 0 && (
        <div className="card">
          <h2>مدل‌های قابل انتخاب برای این مسئله</h2>
          {models.map((m) => (
            <div key={m.code} className="option">
              <strong>{m.name_fa}</strong>{" "}
              <span style={{ color: "var(--color-muted)", fontSize: "0.8rem" }}>
                ({m.name_en})
              </span>
              <p style={{ margin: "6px 0 0", fontSize: "0.85rem" }}>
                داده لازم: {m.required_data_fa}
              </p>
              <p style={{ margin: "4px 0 0", fontSize: "0.8rem", color: "var(--color-muted)" }}>
                محدودیت: {m.limitations_fa}
              </p>
            </div>
          ))}
        </div>
      )}

      <form className="card" onSubmit={handleSubmit}>
        <h2>داده</h2>
        <div className="field-grid">
          <div>
            <label>واحد پول (مثلاً IRR)</label>
            <input
              value={form.currency}
              onChange={(e) => updateField("currency", e.target.value.toUpperCase())}
              maxLength={3}
              required
            />
          </div>
          <div>
            <label>قیمت اسمی هر واحد</label>
            <input
              type="number"
              value={form.nominal_unit_price}
              onChange={(e) => updateField("nominal_unit_price", e.target.value)}
              required
            />
          </div>
          <div>
            <label>تعداد واحد فروخته‌شده</label>
            <input
              type="number"
              value={form.paid_units}
              onChange={(e) => updateField("paid_units", e.target.value)}
              required
            />
          </div>
          <div>
            <label>تعداد واحد کالای رایگان همراه خرید (FOC)</label>
            <input
              type="number"
              value={form.foc_units}
              onChange={(e) => updateField("foc_units", e.target.value)}
            />
          </div>
          <div>
            <label>جمع تخفیف</label>
            <input
              type="number"
              value={form.total_discounts}
              onChange={(e) => updateField("total_discounts", e.target.value)}
            />
          </div>
          <div>
            <label>جمع پاداش فروش (Rebate)</label>
            <input
              type="number"
              value={form.total_rebates}
              onChange={(e) => updateField("total_rebates", e.target.value)}
            />
          </div>
          <div>
            <label>هزینه متغیر هر واحد</label>
            <input
              type="number"
              value={form.variable_cost_per_unit}
              onChange={(e) => updateField("variable_cost_per_unit", e.target.value)}
              required
            />
          </div>
          <div>
            <label>حداقل درصد حاشیه سود قابل‌قبول (٪)</label>
            <input
              type="number"
              value={form.minimum_required_margin_pct}
              onChange={(e) => updateField("minimum_required_margin_pct", e.target.value)}
              required
            />
          </div>
          <div>
            <label>قیمت پیشنهادی (اختیاری، برای مقایسه با کف قیمت)</label>
            <input
              type="number"
              value={form.proposed_price}
              onChange={(e) => updateField("proposed_price", e.target.value)}
            />
          </div>
        </div>
        <div style={{ marginTop: 16 }}>
          <button className="primary" type="submit" disabled={loading}>
            {loading ? "در حال محاسبه…" : "محاسبه تحلیل"}
          </button>
        </div>
      </form>

      {error && (
        <div className="card evidence-note">
          <strong>خطا:</strong> {error}
        </div>
      )}

      {result && result.status === "BLOCKED" && (
        <div className="card evidence-note">
          <h2 style={{ color: "inherit" }}>{result.headline_fa}</h2>
          <p>{result.explanation_fa}</p>
          {result.missing_fields.length > 0 && (
            <p style={{ fontSize: "0.85rem" }}>
              فیلدهای ناقص/نامعتبر: {result.missing_fields.join("، ")}
            </p>
          )}
        </div>
      )}

      {result && result.status === "OK" && (
        <>
          <div className="card">
            <h2>تحلیل</h2>
            <div className="result-grid">
              <div className="result-cell">
                <div className="value">
                  {result.effective_unit_price} {result.currency}
                </div>
                <div className="label">قیمت مؤثر</div>
              </div>
              <div className="result-cell">
                <div className="value">
                  {result.contribution_margin_per_unit} {result.currency}
                </div>
                <div className="label">
                  حاشیه سود مشارکت
                  {result.contribution_margin_pct
                    ? ` (${(Number(result.contribution_margin_pct) * 100).toFixed(1)}٪)`
                    : ""}
                </div>
              </div>
              <div className="result-cell">
                <div className="value">
                  {result.price_floor_effective_unit_price} {result.currency}
                </div>
                <div className="label">کف قیمت</div>
              </div>
            </div>
          </div>

          <div className="card">
            <h2>گزینه‌های تصمیم</h2>
            <p style={{ color: "var(--color-muted)", fontSize: "0.85rem", marginTop: -8 }}>
              سیستم هیچ گزینه‌ای را «بهترین» اعلام نمی‌کند — تصمیم نهایی با شماست.
            </p>
            {result.decision_options.map((option) => (
              <div key={option.option_code} className="option">
                <strong>{option.label_fa}</strong>
                <p style={{ margin: "6px 0 0", fontSize: "0.9rem" }}>{option.rationale_fa}</p>
                {option.risk_fa && <p className="risk">ریسک: {option.risk_fa}</p>}
                {!option.supported_by_evidence && (
                  <p className="risk">این گزینه هنوز با داده کامل پشتیبانی نمی‌شود.</p>
                )}
              </div>
            ))}
          </div>

          <div className="card">
            <h2>ممیزی</h2>
            <p style={{ fontSize: "0.8rem", color: "var(--color-muted)" }}>
              شناسه اجرا: {result.trace.execution_id}
              <br />
              نسخه فرمول: {result.trace.formula_version} — نسخه موتور:{" "}
              {result.trace.engine_version}
              <br />
              زمان اجرا: {result.trace.executed_at}
            </p>
          </div>
        </>
      )}
    </main>
  );
}
