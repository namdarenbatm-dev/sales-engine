import Link from "next/link";

const NAV_ITEMS = [
  { href: "/", label: "خانه" },
  { href: "/pricing-core", label: "هسته قیمت‌گذاری" },
  { href: "/problems", label: "مسئله و تشخیص" },
  { href: "/evidence", label: "شواهد" },
  { href: "/actions", label: "اقدام‌ها" },
  { href: "/learning", label: "یادگیری" },
];

export default function Nav() {
  return (
    <nav className="top-nav">
      <div className="top-nav-inner">
        <span className="brand">Sales Engin</span>
        <div className="nav-links">
          {NAV_ITEMS.map((item) => (
            <Link key={item.href} href={item.href}>
              {item.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
