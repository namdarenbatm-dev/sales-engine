"use client";

import { useEffect } from "react";

export default function ServiceWorkerRegister() {
  useEffect(() => {
    if (typeof window !== "undefined" && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("/service-worker.js").catch(() => {
        // ثبت service worker اختیاری است — اگر ناموفق بود، اپ همچنان به‌صورت عادی کار می‌کند
      });
    }
  }, []);

  return null;
}
