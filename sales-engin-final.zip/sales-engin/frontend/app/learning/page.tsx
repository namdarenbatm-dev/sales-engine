"use client";

import { useEffect, useState } from "react";
import { listLearningCandidates, type LearningCandidate } from "../../lib/api";

export default function LearningPage() {
  const [candidates, setCandidates] = useState<LearningCandidate[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    listLearningCandidates()
      .then(setCandidates)
      .catch((err) => setError(err instanceof Error ? err.message : "خطای نامشخص."));
  }, []);

  return (
    <main className="container">
      <div className="card">
        <h2>کاندیدهای یادگیری</h2>
        <p style={{ color: "var(--color-muted)", marginTop: -8 }}>
          این کاندیدها به‌صورت خودکار پیشنهاد می‌شوند اما هرگز خودکار اعمال نمی‌شوند — بازبینی
          نیازمند ورود با نقش مجاز است (این صفحه فقط نمایش است).
        </p>
      </div>

      {error && (
        <div className="card evidence-note">
          <strong>خطا:</strong> {error}
        </div>
      )}

      <div className="card">
        {candidates.length === 0 && <p>هیچ کاندیدایی ثبت نشده است.</p>}
        {candidates.map((c) => (
          <div key={c.id} className="list-item">
            <p>{c.hypothesis_fa}</p>
            <span className="tag">انحراف: {(Number(c.variance_pct) * 100).toFixed(1)}٪</span>
            <span className="tag">وضعیت: {c.status}</span>
          </div>
        ))}
      </div>
    </main>
  );
}
