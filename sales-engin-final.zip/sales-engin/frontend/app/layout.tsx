import type { Metadata } from "next";
import type { ReactNode } from "react";
import Nav from "./components/Nav";
import ServiceWorkerRegister from "./components/ServiceWorkerRegister";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sales Engin — موتور تصمیم فروش",
  description: "موتور تصمیم‌گیری فروش کانال پرداخت",
  manifest: "/manifest.json",
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        <Nav />
        {children}
        <ServiceWorkerRegister />
      </body>
    </html>
  );
}
