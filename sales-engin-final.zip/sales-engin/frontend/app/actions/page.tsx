"use client";

import { useState, type FormEvent } from "react";
import { createAction, recordActionResult, type Action } from "../../lib/api";

export default function ActionsPage() {
  const [form, setForm] = useState({
    action_type_fa: "", description_fa: "", owner_fa: "", kpi_fa: "",
    expected_result_value: "",
  });
  const [action, setAction] = useState<Action | null>(null);
  const [actualResult, setActualResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      setAction(await createAction(form));
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای نامشخص.");
    } finally {
      setLoading(false);
    }
  }

  async function handleRecordResult(e: FormEvent) {
    e.preventDefault();
    if (!action) return;
    setLoading(true);
    try {
      await recordActionResult(action.id, actualResult);
      setAction({ ...action, actual_result_value: actualResult });
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای نامشخص.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container">
      <div className="card">
        <h2>اقدام</h2>
        <p style={{ color: "var(--color-muted)", marginTop: -8 }}>
          اقدام را ثبت کنید، سپس نتیجه واقعی را وارد کنید تا مقایسه مورد انتظار با واقعی محاسبه شود.
        </p>
      </div>

      {!action && (
        <form className="card" onSubmit={handleCreate}>
          <label>نوع اقدام</label>
          <input
            value={form.action_type_fa}
            onChange={(e) => setForm({ ...form, action_type_fa: e.target.value })}
            required
          />
          <label style={{ marginTop: 12 }}>توضیح</label>
          <input
            value={form.description_fa}
            onChange={(e) => setForm({ ...form, description_fa: e.target.value })}
            required
          />
          <label style={{ marginTop: 12 }}>مسئول اجرا</label>
          <input
            value={form.owner_fa}
            onChange={(e) => setForm({ ...form, owner_fa: e.target.value })}
            required
          />
          <label style={{ marginTop: 12 }}>KPI</label>
          <input value={form.kpi_fa} onChange={(e) => setForm({ ...form, kpi_fa: e.target.value })} />
          <label style={{ marginTop: 12 }}>نتیجه مورد انتظار</label>
          <input
            type="number"
            value={form.expected_result_value}
            onChange={(e) => setForm({ ...form, expected_result_value: e.target.value })}
          />
          <div style={{ marginTop: 16 }}>
            <button className="primary" type="submit" disabled={loading}>
              ثبت اقدام
            </button>
          </div>
        </form>
      )}

      {error && (
        <div className="card evidence-note">
          <strong>خطا:</strong> {error}
        </div>
      )}

      {action && (
        <div className="card">
          <p>
            <span className="tag">{action.action_type_fa}</span>
            <span className="tag">وضعیت: {action.status}</span>
          </p>
          <p>{action.description_fa}</p>

          {action.actual_result_value == null ? (
            <form onSubmit={handleRecordResult}>
              <label>نتیجه واقعی</label>
              <input
                type="number"
                value={actualResult}
                onChange={(e) => setActualResult(e.target.value)}
                required
              />
              <div style={{ marginTop: 12 }}>
                <button className="primary" type="submit" disabled={loading}>
                  ثبت نتیجه واقعی
                </button>
              </div>
            </form>
          ) : (
            <p>
              نتیجه واقعی ثبت‌شده: <strong>{action.actual_result_value}</strong>
            </p>
          )}
        </div>
      )}
    </main>
  );
}
