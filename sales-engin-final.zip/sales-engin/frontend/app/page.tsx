import Link from "next/link";

export default function HomePage() {
  return (
    <main className="container">
      <div className="card">
        <h2>Sales Engin</h2>
        <p>موتور تصمیم فروش کانال پرداخت — نسخه اولین قطعه عمودی (هسته قیمت‌گذاری).</p>
        <Link href="/pricing-core">
          <button className="primary">ورود به فضای کار تصمیم قیمت‌گذاری ←</button>
        </Link>
      </div>
    </main>
  );
}
