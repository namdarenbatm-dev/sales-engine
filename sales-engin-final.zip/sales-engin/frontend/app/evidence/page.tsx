"use client";

import { useState, type FormEvent } from "react";
import { searchEvidence, type EvidenceSearchResult } from "../../lib/api";

export default function EvidencePage() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState<EvidenceSearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSearch(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      setResult(await searchEvidence(query));
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای نامشخص.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container">
      <div className="card">
        <h2>شواهد</h2>
        <p style={{ color: "var(--color-muted)", marginTop: -8 }}>
          جستجوی کلیدواژه‌ای ساده روی ادعاهای ثبت‌شده — نه یک بازیابی معنایی پیشرفته.
        </p>
      </div>

      <form className="card" onSubmit={handleSearch}>
        <label>عبارت جستجو</label>
        <input value={query} onChange={(e) => setQuery(e.target.value)} required />
        <div style={{ marginTop: 12 }}>
          <button className="primary" type="submit" disabled={loading}>
            جستجو
          </button>
        </div>
      </form>

      {error && (
        <div className="card evidence-note">
          <strong>خطا:</strong> {error}
        </div>
      )}

      {result && (
        <div className="card">
          <p style={{ fontSize: "0.8rem", color: "var(--color-muted)" }}>{result.disclaimer_fa}</p>
          {result.results.length === 0 && <p>نتیجه‌ای یافت نشد.</p>}
          {result.results.map((r) => (
            <div key={r.claim_id} className="list-item">
              <p>{r.claim_text_fa}</p>
              <span className="tag">منبع: {r.source_title_fa}</span>
              <span className="tag">سطح شواهد: {r.evidence_level_fa}</span>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}
