"use client";

import { useState, type FormEvent } from "react";
import {
  addDiagnosticEntry,
  createProblem,
  getNextDiagnosticQuestion,
  type DiagnosticStatus,
  type Problem,
} from "../../lib/api";

export default function ProblemsPage() {
  const [form, setForm] = useState({
    business_area_fa: "",
    observed_symptom_fa: "",
    target_outcome_fa: "",
  });
  const [problem, setProblem] = useState<Problem | null>(null);
  const [diagnostic, setDiagnostic] = useState<DiagnosticStatus | null>(null);
  const [answerText, setAnswerText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCreateProblem(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const created = await createProblem(form);
      setProblem(created);
      const status = await getNextDiagnosticQuestion(created.id);
      setDiagnostic(status);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای نامشخص.");
    } finally {
      setLoading(false);
    }
  }

  async function handleAnswer(e: FormEvent) {
    e.preventDefault();
    if (!problem || !diagnostic?.next_question) return;
    setLoading(true);
    try {
      const updated = await addDiagnosticEntry(
        problem.id, diagnostic.next_question.field_fa, answerText
      );
      setProblem(updated);
      setAnswerText("");
      const status = await getNextDiagnosticQuestion(problem.id);
      setDiagnostic(status);
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطای نامشخص.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="container">
      <div className="card">
        <h2>مسئله</h2>
        <p style={{ color: "var(--color-muted)", marginTop: -8 }}>
          مسئله را تعریف کنید تا سیستم واقعیت‌ها، فرضیه‌ها، فرض‌ها و محدودیت‌های آن را از شما بپرسد.
        </p>
      </div>

      {!problem && (
        <form className="card" onSubmit={handleCreateProblem}>
          <label>حوزه کسب‌وکار</label>
          <input
            value={form.business_area_fa}
            onChange={(e) => setForm({ ...form, business_area_fa: e.target.value })}
            required
          />
          <label style={{ marginTop: 12 }}>علامت مشاهده‌شده</label>
          <input
            value={form.observed_symptom_fa}
            onChange={(e) => setForm({ ...form, observed_symptom_fa: e.target.value })}
            required
          />
          <label style={{ marginTop: 12 }}>نتیجه مطلوب</label>
          <input
            value={form.target_outcome_fa}
            onChange={(e) => setForm({ ...form, target_outcome_fa: e.target.value })}
            required
          />
          <div style={{ marginTop: 16 }}>
            <button className="primary" type="submit" disabled={loading}>
              ثبت مسئله
            </button>
          </div>
        </form>
      )}

      {error && (
        <div className="card evidence-note">
          <strong>خطا:</strong> {error}
        </div>
      )}

      {problem && (
        <div className="card">
          <h2>تشخیص</h2>
          <p>
            <span className="tag">{problem.business_area_fa}</span>
            <span className="tag">وضعیت: {problem.status_fa}</span>
          </p>

          {diagnostic && !diagnostic.sufficient_fa && diagnostic.next_question && (
            <form onSubmit={handleAnswer}>
              <p style={{ fontWeight: 700 }}>{diagnostic.next_question.question_fa}</p>
              <input
                value={answerText}
                onChange={(e) => setAnswerText(e.target.value)}
                required
              />
              <div style={{ marginTop: 12 }}>
                <button className="primary" type="submit" disabled={loading}>
                  ثبت پاسخ
                </button>
              </div>
            </form>
          )}

          {diagnostic?.sufficient_fa && (
            <p style={{ color: "var(--color-primary)" }}>{diagnostic.explanation_fa}</p>
          )}

          <div style={{ marginTop: 16 }}>
            <h3 style={{ fontSize: "0.95rem" }}>واقعیت‌ها</h3>
            {problem.known_facts_fa.map((f, i) => <p key={i}>• {f}</p>)}
            <h3 style={{ fontSize: "0.95rem" }}>فرضیه‌ها</h3>
            {problem.hypotheses_fa.map((f, i) => <p key={i}>• {f}</p>)}
            <h3 style={{ fontSize: "0.95rem" }}>فرض‌ها</h3>
            {problem.assumptions_fa.map((f, i) => <p key={i}>• {f}</p>)}
            <h3 style={{ fontSize: "0.95rem" }}>محدودیت‌ها</h3>
            {problem.constraints_fa.map((f, i) => <p key={i}>• {f}</p>)}
          </div>
        </div>
      )}
    </main>
  );
}
