// کلاینت API — این قطعه فقط هسته قیمت‌گذاری را پوشش می‌دهد.
// شناسه مستأجر (tenant) فعلاً از یک متغیر محیطی ساده خوانده می‌شود؛ در قطعه بعدی
// باید از یک لایه احراز هویت واقعی (Identity/RBAC) جایگزین شود.

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000";
const TENANT_ID = process.env.NEXT_PUBLIC_TENANT_ID ?? "tenant-demo";

export interface PricingCoreRequest {
  problem_id?: string | null;
  currency: string;
  nominal_unit_price: string;
  paid_units: string;
  total_discounts: string;
  total_rebates: string;
  foc_units: string;
  variable_cost_per_unit: string;
  minimum_required_margin_pct: string;
  proposed_price?: string | null;
}

export interface DecisionOption {
  option_code: string;
  label_fa: string;
  rationale_fa: string;
  risk_fa: string | null;
  supported_by_evidence: boolean;
}

export interface CalculationTrace {
  execution_id: string;
  engine_version: string;
  formula_version: string;
  executed_at: string;
  problem_id: string | null;
}

export interface PricingCoreResponse {
  status: "OK" | "BLOCKED";
  currency?: string;
  effective_unit_price?: string;
  contribution_margin_per_unit?: string;
  contribution_margin_pct?: string;
  price_floor_effective_unit_price?: string;
  decision_options: DecisionOption[];
  headline_fa?: string;
  explanation_fa?: string;
  missing_fields: string[];
  trace: CalculationTrace;
}

export interface ModelRegistryEntry {
  code: string;
  name_fa: string;
  name_en: string;
  status: string;
  required_data_fa: string;
  assumptions_fa: string;
  limitations_fa: string;
}

async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      "X-Tenant-Id": TENANT_ID,
      ...(init?.headers ?? {}),
    },
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`درخواست ناموفق بود (${response.status}): ${body}`);
  }

  return (await response.json()) as T;
}

export function calculatePricingCore(
  payload: PricingCoreRequest
): Promise<PricingCoreResponse> {
  return apiFetch<PricingCoreResponse>("/api/v1/pricing-core/calculate", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function listPricingCoreModels(): Promise<ModelRegistryEntry[]> {
  return apiFetch<ModelRegistryEntry[]>("/api/v1/models/pricing-core");
}

// --- مسئله و تشخیص ---

export interface Problem {
  id: string;
  tenant_id: string;
  business_area_fa: string;
  observed_symptom_fa: string;
  target_outcome_fa: string;
  channel_fa: string | null;
  product_fa: string | null;
  customer_group_fa: string | null;
  status_fa: string;
  known_facts_fa: string[];
  hypotheses_fa: string[];
  assumptions_fa: string[];
  constraints_fa: string[];
  created_at: string;
}

export interface ProblemCreateInput {
  business_area_fa: string;
  observed_symptom_fa: string;
  target_outcome_fa: string;
  channel_fa?: string;
  product_fa?: string;
  customer_group_fa?: string;
}

export interface DiagnosticStatus {
  sufficient_fa: boolean;
  next_question: { field_fa: string; question_fa: string } | null;
  explanation_fa: string;
}

export function createProblem(payload: ProblemCreateInput): Promise<Problem> {
  return apiFetch<Problem>("/api/v1/problems", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function getProblem(problemId: string): Promise<Problem> {
  return apiFetch<Problem>(`/api/v1/problems/${problemId}`);
}

export function addDiagnosticEntry(
  problemId: string,
  fieldFa: string,
  textFa: string
): Promise<Problem> {
  return apiFetch<Problem>(`/api/v1/problems/${problemId}/diagnostic-entries`, {
    method: "POST",
    body: JSON.stringify({ field_fa: fieldFa, text_fa: textFa }),
  });
}

export function getNextDiagnosticQuestion(problemId: string): Promise<DiagnosticStatus> {
  return apiFetch<DiagnosticStatus>(`/api/v1/problems/${problemId}/next-diagnostic-question`);
}

// --- شواهد ---

export interface EvidenceSearchResult {
  query_fa: string;
  results: {
    claim_id: string;
    claim_text_fa: string;
    source_title_fa: string;
    evidence_level_fa: string;
    score: number;
  }[];
  disclaimer_fa: string;
}

export function searchEvidence(query: string): Promise<EvidenceSearchResult> {
  return apiFetch<EvidenceSearchResult>(`/api/v1/evidence/search?q=${encodeURIComponent(query)}`);
}

export interface SourceCreateInput {
  title_fa: string;
  author_fa?: string;
  publication_year?: number;
  source_type_fa?: string;
}

export function createSource(payload: SourceCreateInput) {
  return apiFetch<{ id: string }>("/api/v1/evidence/sources", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function createClaim(sourceId: string, claimTextFa: string, evidenceLevelFa: string) {
  return apiFetch<{ id: string }>("/api/v1/evidence/claims", {
    method: "POST",
    body: JSON.stringify({
      source_id: sourceId, claim_text_fa: claimTextFa, evidence_level_fa: evidenceLevelFa,
    }),
  });
}

// --- اقدام ---

export interface Action {
  id: string;
  action_type_fa: string;
  description_fa: string;
  owner_fa: string;
  status: string;
  expected_result_value: string | null;
  actual_result_value: string | null;
  kpi_fa: string | null;
  created_at: string;
}

export interface ActionCreateInput {
  problem_id?: string | null;
  action_type_fa: string;
  description_fa: string;
  owner_fa: string;
  kpi_fa?: string;
  baseline_value?: string;
  expected_result_value?: string;
}

export function createAction(payload: ActionCreateInput): Promise<Action> {
  return apiFetch<Action>("/api/v1/actions", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function getAction(actionId: string): Promise<Action> {
  return apiFetch<Action>(`/api/v1/actions/${actionId}`);
}

export function recordActionResult(actionId: string, actualResultValue: string) {
  return apiFetch(`/api/v1/actions/${actionId}/result`, {
    method: "POST",
    body: JSON.stringify({ actual_result_value: actualResultValue }),
  });
}

// --- کاندیدهای یادگیری ---

export interface LearningCandidate {
  id: string;
  variance_pct: string;
  hypothesis_fa: string;
  status: string;
  reviewer_fa: string | null;
  created_at: string;
}

export function listLearningCandidates(): Promise<LearningCandidate[]> {
  return apiFetch<LearningCandidate[]>("/api/v1/learning-candidates");
}
