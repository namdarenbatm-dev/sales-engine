# فهرست Endpointهای API

همه درخواست‌ها به‌جز `/health` نیاز به هدر `X-Tenant-Id` دارند (قانون معماری ۱۳).
دو مورد علامت‌خورده با 🔒 علاوه‌بر آن به هدر `Authorization: Bearer <token>` با مجوز مربوط نیاز دارند.

## هسته قیمت‌گذاری
- `POST /api/v1/pricing-core/calculate` — قیمت مؤثر + حاشیه سود مشارکت + کف قیمت + گزینه‌های تصمیم
- `POST /api/v1/pricing-core/scenarios` — سناریوهای پایه/خوش‌بینانه/بدبینانه/فشار شدید/سفارشی
- `POST /api/v1/pricing-core/sensitivity` — تحلیل حساسیت روی یک فیلد
- `POST /api/v1/pricing-core/breakeven` — نقطه سربه‌سر

## مشوق‌ها و کانال
- `POST /api/v1/incentives/rebate-equivalent`
- `POST /api/v1/incentives/foc-equivalent`
- `POST /api/v1/channel/margin`
- `POST /api/v1/channel/conflict`
- `POST /api/v1/credit/economics`

## عملکرد فروش و پیش‌بینی
- `POST /api/v1/sales-performance/growth`
- `POST /api/v1/sales-performance/funnel`
- `POST /api/v1/sales-performance/productivity`
- `POST /api/v1/forecasting/naive`
- `POST /api/v1/forecasting/moving-average`
- `POST /api/v1/forecasting/weighted-moving-average`
- `POST /api/v1/forecasting/exponential-smoothing`

## مذاکره B2B و اقدام B2C
- `POST /api/v1/negotiation/evaluate-option`
- `POST /api/v1/action/value`
- `POST /api/v1/action/b2c-options`

## مسئله و تشخیص
- `POST /api/v1/problems`
- `GET /api/v1/problems/{problem_id}`
- `POST /api/v1/problems/{problem_id}/diagnostic-entries`
- `GET /api/v1/problems/{problem_id}/next-diagnostic-question`

## اقدام
- `POST /api/v1/actions`
- `GET /api/v1/actions/{action_id}`
- `PATCH /api/v1/actions/{action_id}/status` 🔒 (مجوز `action:approve`)
- `POST /api/v1/actions/{action_id}/result` — واریانس + سنجش سهم عوامل + کاندیدای یادگیری خودکار

## یادگیری
- `GET /api/v1/learning-candidates`
- `POST /api/v1/learning-candidates/{candidate_id}/review` 🔒 (مجوز `learning:review`)

## شواهد
- `POST /api/v1/evidence/sources`
- `POST /api/v1/evidence/claims`
- `POST /api/v1/evidence/formula-registry`
- `GET /api/v1/evidence/search?q=...`

## هویت
- `POST /api/v1/identity/roles`
- `POST /api/v1/identity/users`
- `POST /api/v1/identity/auth/login` — بازمی‌گرداند `access_token` برای endpointهای 🔒

## ثبت مدل‌ها
- `GET /api/v1/models/pricing-core`

## سلامت سرویس
- `GET /health` — بدون نیاز به `X-Tenant-Id`
