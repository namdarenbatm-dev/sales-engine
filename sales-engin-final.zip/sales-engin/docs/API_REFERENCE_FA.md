# مرجع API — Sales Engin (نسخه فعلی)

همه endpointها به‌جز موارد مشخص‌شده، نیازمند هدر `X-Tenant-Id` هستند.
موارد علامت‌خورده با 🔒 علاوه‌بر آن به هدر `Authorization: Bearer <token>` با مجوز مشخص‌شده نیاز دارند.

## سلامت سرویس
- `GET /health`

## ثبت مدل‌ها (Model Registry)
- `GET /api/v1/models/pricing-core` — فهرست مدل‌های هسته قیمت‌گذاری (بدون رتبه‌بندی)

## مسئله و تشخیص
- `POST /api/v1/problems`
- `GET /api/v1/problems/{problem_id}`
- `POST /api/v1/problems/{problem_id}/diagnostic-entries`
- `GET /api/v1/problems/{problem_id}/next-diagnostic-question`

## هسته قیمت‌گذاری
- `POST /api/v1/pricing-core/calculate` — قیمت مؤثر + حاشیه سود مشارکت + کف قیمت + گزینه‌های تصمیم
- `POST /api/v1/pricing-core/scenarios` — پایه/خوش‌بینانه/بدبینانه/فشار شدید/سفارشی
- `POST /api/v1/pricing-core/sensitivity` — تحلیل حساسیت روی یک فیلد
- `POST /api/v1/pricing-core/breakeven` — نقطه سربه‌سر

## مشوق‌ها، کانال، اعتبار
- `POST /api/v1/incentives/rebate-equivalent`
- `POST /api/v1/incentives/foc-equivalent`
- `POST /api/v1/channel/margin`
- `POST /api/v1/channel/conflict`
- `POST /api/v1/credit/economics`

## عملکرد فروش و پیش‌بینی
- `POST /api/v1/sales-performance/growth`
- `POST /api/v1/sales-performance/funnel`
- `POST /api/v1/sales-performance/productivity`
- `POST /api/v1/forecasting/naive`
- `POST /api/v1/forecasting/moving-average`
- `POST /api/v1/forecasting/weighted-moving-average`
- `POST /api/v1/forecasting/exponential-smoothing`

## مذاکره B2B و اقدام B2C
- `POST /api/v1/negotiation/evaluate-option`
- `POST /api/v1/action/value`
- `POST /api/v1/action/b2c-options` — همیشه شامل «بدون اقدام» با ارزش صفر

## چرخه اقدام
- `POST /api/v1/actions`
- `GET /api/v1/actions/{action_id}`
- `PATCH /api/v1/actions/{action_id}/status` 🔒 `action:approve`
- `POST /api/v1/actions/{action_id}/result` — محاسبه خودکار واریانس + سنجش سهم عوامل + پیشنهاد یادگیری در صورت انحراف بالا

## یادگیری
- `GET /api/v1/learning-candidates`
- `POST /api/v1/learning-candidates/{candidate_id}/review` 🔒 `learning:review` — تنها راه تغییر وضعیت؛ هرگز خودکار

## شواهد
- `POST /api/v1/evidence/sources`
- `POST /api/v1/evidence/claims`
- `POST /api/v1/evidence/formula-registry`
- `GET /api/v1/evidence/search?q=...` — جستجوی کلیدواژه‌ای ساده

## هویت
- `POST /api/v1/identity/roles`
- `POST /api/v1/identity/users`
- `POST /api/v1/identity/auth/login` — بازمی‌گرداند `access_token` (JWT حداقلی، اعتبار پیش‌فرض ۱ ساعت)
