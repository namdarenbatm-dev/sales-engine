import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.config import settings  # noqa: E402
from app.core.database import Base  # noqa: E402

# ایمپورت همه مدل‌ها تا Base.metadata کامل باشد (برای autogenerate در آینده)
from app.domain.action.models import Action  # noqa: E402,F401
from app.domain.audit.models import AuditEvent  # noqa: E402,F401
from app.domain.evidence.models import Claim, FormulaRegistryEntry, Source  # noqa: E402,F401
from app.domain.identity.models import Role, User  # noqa: E402,F401
from app.domain.learning.models import LearningCandidate  # noqa: E402,F401
from app.domain.model_registry.models import AnalyticalModel  # noqa: E402,F401
from app.domain.problem.models import Problem  # noqa: E402,F401

config = context.config
config.set_main_option("sqlalchemy.url", settings.database_url)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url, target_metadata=target_metadata, literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.", poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
