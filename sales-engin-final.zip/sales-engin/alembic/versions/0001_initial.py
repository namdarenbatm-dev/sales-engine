"""initial schema

Revision ID: 0001_initial
Revises:
Create Date: 2026-09-27

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute('CREATE EXTENSION IF NOT EXISTS "pgcrypto"')

    model_status = postgresql.ENUM(
        "CANDIDATE", "VALIDATED", "PRODUCTION_READY", "REJECTED", "DEPRECATED",
        name="model_status",
    )
    action_status = postgresql.ENUM(
        "ایجادشده", "در انتظار تأیید", "تأییدشده", "در حال اجرا", "تکمیل‌شده",
        "متوقف‌شده", "لغوشده", name="action_status",
    )
    learning_candidate_status = postgresql.ENUM(
        "پیشنهادشده", "تأییدشده(اعتبارسنجی)", "ردشده", "اعمال‌شده",
        name="learning_candidate_status",
    )
    model_status.create(op.get_bind(), checkfirst=True)
    action_status.create(op.get_bind(), checkfirst=True)
    learning_candidate_status.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "analytical_models",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("code", sa.String(64), nullable=False, unique=True),
        sa.Column("name_fa", sa.String(128), nullable=False),
        sa.Column("name_en", sa.String(128), nullable=False),
        sa.Column("family", sa.String(64), nullable=False),
        sa.Column("version", sa.String(32), nullable=False),
        sa.Column("status", model_status, nullable=False, server_default="CANDIDATE"),
        sa.Column("required_data_fa", sa.Text(), nullable=False),
        sa.Column("assumptions_fa", sa.Text(), nullable=False),
        sa.Column("limitations_fa", sa.Text(), nullable=False),
    )

    op.create_table(
        "audit_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("execution_id", sa.String(64)),
        sa.Column("actor", sa.String(128), nullable=False, server_default="system"),
        sa.Column("payload", postgresql.JSONB(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("notes_fa", sa.Text()),
    )
    op.create_index("idx_audit_events_tenant", "audit_events", ["tenant_id"])
    op.create_index("idx_audit_events_execution", "audit_events", ["execution_id"])

    op.create_table(
        "problems",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("business_area_fa", sa.String(128), nullable=False),
        sa.Column("observed_symptom_fa", sa.Text(), nullable=False),
        sa.Column("target_outcome_fa", sa.Text(), nullable=False),
        sa.Column("channel_fa", sa.String(128)),
        sa.Column("product_fa", sa.String(128)),
        sa.Column("customer_group_fa", sa.String(128)),
        sa.Column("period_start", sa.Date()),
        sa.Column("period_end", sa.Date()),
        sa.Column("status_fa", sa.String(64), nullable=False, server_default="باز"),
        sa.Column("known_facts_fa", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("hypotheses_fa", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("assumptions_fa", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("constraints_fa", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                   server_default=sa.text("now()")),
    )
    op.create_index("idx_problems_tenant", "problems", ["tenant_id"])

    op.create_table(
        "actions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("problem_id", postgresql.UUID(as_uuid=True)),
        sa.Column("source_execution_id", sa.String(64)),
        sa.Column("option_code", sa.String(128)),
        sa.Column("action_type_fa", sa.String(128), nullable=False),
        sa.Column("description_fa", sa.Text(), nullable=False),
        sa.Column("owner_fa", sa.String(128), nullable=False),
        sa.Column("organizational_unit_fa", sa.String(128)),
        sa.Column("start_date", sa.Date()),
        sa.Column("deadline", sa.Date()),
        sa.Column("kpi_fa", sa.String(128)),
        sa.Column("baseline_value", sa.Numeric(18, 2)),
        sa.Column("target_value", sa.Numeric(18, 2)),
        sa.Column("status", action_status, nullable=False, server_default="ایجادشده"),
        sa.Column("execution_cost", sa.Numeric(18, 2)),
        sa.Column("risk_fa", sa.Text()),
        sa.Column("expected_result_value", sa.Numeric(18, 2)),
        sa.Column("actual_result_value", sa.Numeric(18, 2)),
        sa.Column("measurement_period_start", sa.Date()),
        sa.Column("measurement_period_end", sa.Date()),
        sa.Column("source_fa", sa.String(128)),
        sa.Column("approver_fa", sa.String(128)),
        sa.Column("approval_date", sa.Date()),
        sa.Column("change_history", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                   server_default=sa.text("now()")),
    )
    op.create_index("idx_actions_tenant", "actions", ["tenant_id"])
    op.create_index("idx_actions_problem", "actions", ["problem_id"])

    op.create_table(
        "learning_candidates",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("source_action_id", postgresql.UUID(as_uuid=True)),
        sa.Column("model_code", sa.String(64)),
        sa.Column("variance_pct", sa.Numeric(10, 4), nullable=False),
        sa.Column("hypothesis_fa", sa.Text(), nullable=False),
        sa.Column("status", learning_candidate_status, nullable=False, server_default="پیشنهادشده"),
        sa.Column("reviewer_fa", sa.String(128)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                   server_default=sa.text("now()")),
    )
    op.create_index("idx_learning_candidates_tenant", "learning_candidates", ["tenant_id"])

    op.create_table(
        "sources",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("title_fa", sa.String(256), nullable=False),
        sa.Column("author_fa", sa.String(256)),
        sa.Column("publication_year", sa.Integer()),
        sa.Column("source_type_fa", sa.String(64), nullable=False, server_default="دانش سازمانی"),
        sa.Column("reference_fa", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                   server_default=sa.text("now()")),
    )

    op.create_table(
        "claims",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("source_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("sources.id"), nullable=False),
        sa.Column("claim_text_fa", sa.Text(), nullable=False),
        sa.Column("evidence_level_fa", sa.String(32), nullable=False, server_default="متوسط"),
        sa.Column("related_model_code", sa.String(64)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                   server_default=sa.text("now()")),
    )
    op.create_index("idx_claims_tenant", "claims", ["tenant_id"])

    op.create_table(
        "formula_registry_entries",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("formula_code", sa.String(64), nullable=False),
        sa.Column("version", sa.String(32), nullable=False),
        sa.Column("description_fa", sa.Text(), nullable=False),
        sa.Column("primary_source_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("sources.id")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                   server_default=sa.text("now()")),
    )

    op.create_table(
        "roles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("code", sa.String(64), nullable=False),
        sa.Column("name_fa", sa.String(128), nullable=False),
        sa.Column("permission_codes", postgresql.JSONB(), nullable=False, server_default="[]"),
    )

    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                   server_default=sa.text("gen_random_uuid()")),
        sa.Column("tenant_id", sa.String(128), nullable=False),
        sa.Column("email", sa.String(256), nullable=False),
        sa.Column("hashed_password", sa.String(256), nullable=False),
        sa.Column("display_name_fa", sa.String(128), nullable=False),
        sa.Column("role_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("roles.id")),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("failed_login_attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("locked_until", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False,
                   server_default=sa.text("now()")),
        sa.UniqueConstraint("tenant_id", "email"),
    )
    op.create_index("idx_users_tenant", "users", ["tenant_id"])

    # Row-Level Security — دفاع دوم پس از فیلتر tenant_id در لایه برنامه
    rls_tables = [
        "problems", "actions", "learning_candidates", "sources", "claims",
        "formula_registry_entries", "audit_events", "roles", "users",
    ]
    for table_name in rls_tables:
        op.execute(f"ALTER TABLE {table_name} ENABLE ROW LEVEL SECURITY")
        op.execute(f"ALTER TABLE {table_name} FORCE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation_{table_name} ON {table_name}
                USING (tenant_id = current_setting('app.current_tenant_id', true))
                WITH CHECK (tenant_id = current_setting('app.current_tenant_id', true))
            """
        )


def downgrade() -> None:
    rls_tables = [
        "problems", "actions", "learning_candidates", "sources", "claims",
        "formula_registry_entries", "audit_events", "roles", "users",
    ]
    for table_name in rls_tables:
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation_{table_name} ON {table_name}")
        op.execute(f"ALTER TABLE {table_name} DISABLE ROW LEVEL SECURITY")

    op.drop_table("users")
    op.drop_table("roles")
    op.drop_table("formula_registry_entries")
    op.drop_table("claims")
    op.drop_table("sources")
    op.drop_table("learning_candidates")
    op.drop_table("actions")
    op.drop_table("problems")
    op.drop_table("audit_events")
    op.drop_table("analytical_models")

    postgresql.ENUM(name="learning_candidate_status").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="action_status").drop(op.get_bind(), checkfirst=True)
    postgresql.ENUM(name="model_status").drop(op.get_bind(), checkfirst=True)
