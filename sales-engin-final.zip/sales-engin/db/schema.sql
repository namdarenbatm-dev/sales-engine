-- Sales Engin — schema مرجع برای قطعه عمودی اول (هسته قیمت‌گذاری)
-- توجه: این فایل جایگزین مهاجرت‌های نسخه‌دار (Alembic) نیست؛ صرفاً برای راه‌اندازی سریع
-- محیط توسعه محلی از طریق docker-compose است. مدیریت schema در نسخه بعدی باید
-- migration-based شود (طبق بخش ۱۰ و ۶۱ سند معماری).

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE model_status AS ENUM (
    'CANDIDATE', 'VALIDATED', 'PRODUCTION_READY', 'REJECTED', 'DEPRECATED'
);

CREATE TABLE IF NOT EXISTS analytical_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(64) UNIQUE NOT NULL,
    name_fa VARCHAR(128) NOT NULL,
    name_en VARCHAR(128) NOT NULL,
    family VARCHAR(64) NOT NULL,
    version VARCHAR(32) NOT NULL,
    status model_status NOT NULL DEFAULT 'CANDIDATE',
    required_data_fa TEXT NOT NULL,
    assumptions_fa TEXT NOT NULL,
    limitations_fa TEXT NOT NULL
);

-- نسخه حداقلی نمایش ساختاریافته مسئله + تشخیص پویا ساده (JSONB برای واقعیت/فرضیه/فرض/محدودیت)
CREATE TABLE IF NOT EXISTS problems (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    business_area_fa VARCHAR(128) NOT NULL,
    observed_symptom_fa TEXT NOT NULL,
    target_outcome_fa TEXT NOT NULL,
    channel_fa VARCHAR(128),
    product_fa VARCHAR(128),
    customer_group_fa VARCHAR(128),
    period_start DATE,
    period_end DATE,
    status_fa VARCHAR(64) NOT NULL DEFAULT 'باز',
    known_facts_fa JSONB NOT NULL DEFAULT '[]'::jsonb,
    hypotheses_fa JSONB NOT NULL DEFAULT '[]'::jsonb,
    assumptions_fa JSONB NOT NULL DEFAULT '[]'::jsonb,
    constraints_fa JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_problems_tenant ON problems (tenant_id);

CREATE TYPE action_status AS ENUM (
    'ایجادشده', 'در انتظار تأیید', 'تأییدشده', 'در حال اجرا', 'تکمیل‌شده', 'متوقف‌شده', 'لغوشده'
);

CREATE TABLE IF NOT EXISTS actions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    problem_id UUID,
    source_execution_id VARCHAR(64),
    option_code VARCHAR(128),
    action_type_fa VARCHAR(128) NOT NULL,
    description_fa TEXT NOT NULL,
    owner_fa VARCHAR(128) NOT NULL,
    organizational_unit_fa VARCHAR(128),
    start_date DATE,
    deadline DATE,
    kpi_fa VARCHAR(128),
    baseline_value NUMERIC(18,2),
    target_value NUMERIC(18,2),
    status action_status NOT NULL DEFAULT 'ایجادشده',
    execution_cost NUMERIC(18,2),
    risk_fa TEXT,
    expected_result_value NUMERIC(18,2),
    actual_result_value NUMERIC(18,2),
    measurement_period_start DATE,
    measurement_period_end DATE,
    source_fa VARCHAR(128),
    approver_fa VARCHAR(128),
    approval_date DATE,
    change_history JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_actions_tenant ON actions (tenant_id);
CREATE INDEX IF NOT EXISTS idx_actions_problem ON actions (problem_id);

CREATE TYPE learning_candidate_status AS ENUM (
    'پیشنهادشده', 'تأییدشده(اعتبارسنجی)', 'ردشده', 'اعمال‌شده'
);

-- هرگز به‌صورت خودکار به 'اعمال‌شده' تغییر نمی‌کند؛ فقط با فراخوانی صریح انسان (قانون ۱۹)
CREATE TABLE IF NOT EXISTS learning_candidates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    source_action_id UUID,
    model_code VARCHAR(64),
    variance_pct NUMERIC(10,4) NOT NULL,
    hypothesis_fa TEXT NOT NULL,
    status learning_candidate_status NOT NULL DEFAULT 'پیشنهادشده',
    reviewer_fa VARCHAR(128),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_learning_candidates_tenant ON learning_candidates (tenant_id);

CREATE TABLE IF NOT EXISTS sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    title_fa VARCHAR(256) NOT NULL,
    author_fa VARCHAR(256),
    publication_year INTEGER,
    source_type_fa VARCHAR(64) NOT NULL DEFAULT 'دانش سازمانی',
    reference_fa TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS claims (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    source_id UUID NOT NULL REFERENCES sources(id),
    claim_text_fa TEXT NOT NULL,
    evidence_level_fa VARCHAR(32) NOT NULL DEFAULT 'متوسط',
    related_model_code VARCHAR(64),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_claims_tenant ON claims (tenant_id);

CREATE TABLE IF NOT EXISTS formula_registry_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    formula_code VARCHAR(64) NOT NULL,
    version VARCHAR(32) NOT NULL,
    description_fa TEXT NOT NULL,
    primary_source_id UUID REFERENCES sources(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- append-only: هیچ برنامه‌ای اجازه UPDATE/DELETE روی این جدول ندارد (قانون ۱۸).
CREATE TABLE IF NOT EXISTS audit_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    execution_id VARCHAR(64),
    actor VARCHAR(128) NOT NULL DEFAULT 'system',
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    notes_fa TEXT
);

CREATE INDEX IF NOT EXISTS idx_audit_events_tenant ON audit_events (tenant_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_execution ON audit_events (execution_id);

-- داده اولیه Model Registry برای هسته قیمت‌گذاری، مشوق‌ها، کانال، اعتبار، عملکرد فروش و پیش‌بینی
INSERT INTO analytical_models (code, name_fa, name_en, family, version, status, required_data_fa, assumptions_fa, limitations_fa)
VALUES
  ('effective_price_v1', 'قیمت مؤثر', 'Effective Price', 'pricing', '1.0.0', 'VALIDATED',
   'قیمت اسمی، تعداد واحد، جمع تخفیف، جمع پاداش فروش، تعداد FOC، واحد پول یکسان.',
   'همه مقادیر مالی هم‌ارز؛ FOC بدون هزینه مجزا برای خریدار.',
   'هزینه تمام‌شده را محاسبه نمی‌کند.'),
  ('contribution_margin_v1', 'حاشیه سود مشارکت', 'Contribution Margin', 'pricing', '1.0.0', 'VALIDATED',
   'قیمت مؤثر و هزینه متغیر هر واحد.',
   'هزینه متغیر شامل تمام هزینه‌های مستقیم فروش است.',
   'هزینه‌های ثابت را نادیده می‌گیرد.'),
  ('price_floor_v1', 'کف قیمت', 'Price Floor', 'pricing', '1.0.0', 'VALIDATED',
   'هزینه متغیر هر واحد و حداقل درصد حاشیه سود قابل‌قبول.',
   'حداقل درصد حاشیه یک فرض سیاستی مدیریتی است.',
   'فرض می‌کند نرخ پاداش فروش/FOC صفر است مگر صراحتاً داده شود.'),
  ('rebate_equivalent_v1', 'معادل پاداش فروش', 'Rebate Equivalent', 'incentives', '1.0.0', 'VALIDATED',
   'قیمت اسمی هر واحد و نرخ پاداش فروش مشروط.',
   'پاداش فروش قطعی و بدون شرط باقی‌مانده فرض شده.',
   'شرط‌های پاداش فروش (مثل سقف حجم) را مدل نمی‌کند.'),
  ('foc_equivalent_v1', 'معادل کالای رایگان همراه خرید', 'FOC Equivalent', 'incentives', '1.0.0', 'VALIDATED',
   'تعداد واحد خریداری‌شده، قیمت واحد و تعداد واحد رایگان همراه خرید.',
   'کالای رایگان بدون هزینه جداگانه برای خریدار است.',
   'هزینه نگهداری/انبارداری واحدهای اضافی را در نظر نمی‌گیرد.'),
  ('channel_margin_v1', 'حاشیه کانال', 'Channel Margin', 'channel', '1.0.0', 'VALIDATED',
   'قیمت فروش و هزینه تمام‌شده برای فروشنده در آن سطح کانال.',
   'قیمت و هزینه در یک واحد پول و یک بازه زمانی مشخص هستند.',
   'هزینه‌های غیرمستقیم توزیع را جداگانه لحاظ نمی‌کند.'),
  ('channel_conflict_v1', 'تعارض کانال', 'Channel Conflict', 'channel', '1.0.0', 'CANDIDATE',
   'قیمت به نماینده اصلی و قیمت به زیرنماینده در همان بازه.',
   'شکاف قیمتی نشانه نشتی احتمالی است، نه اثبات قطعی.',
   'رفتار واقعی بازار را مشاهده نمی‌کند؛ فقط شکاف قیمت رسمی را می‌سنجد.'),
  ('credit_economics_v1', 'اقتصاد اعتبار', 'Credit Economics', 'credit', '1.0.0', 'CANDIDATE',
   'حاشیه سود افزایشی، هزینه تأمین مالی، زیان اعتباری مورد انتظار و هزینه وصول.',
   'زیان اعتباری مورد انتظار یک برآورد است، نه واقعیت مشاهده‌شده.',
   'ریسک تمرکز اعتباری در سطح کل پرتفوی را نمی‌سنجد.'),
  ('sales_growth_v1', 'روند/رشد فروش', 'Sales Trend/Growth', 'sales_performance', '1.0.0', 'VALIDATED',
   'مقدار فروش دوره قبل و دوره جاری.',
   'دو دوره از نظر طول زمانی و فصلی بودن قابل‌مقایسه‌اند.',
   'اثر فصلی بودن یا رویدادهای یک‌باره را جدا نمی‌کند.'),
  ('sales_funnel_v1', 'قیف فروش', 'Sales Funnel', 'sales_performance', '1.0.0', 'VALIDATED',
   'تعداد در هر مرحله قیف، به ترتیب از بالا به پایین.',
   'مراحل قیف به‌ترتیب درست و بدون هم‌پوشانی وارد شده‌اند.',
   'علت افت در هر مرحله را توضیح نمی‌دهد.'),
  ('sales_productivity_v1', 'بهره‌وری فروش', 'Sales Productivity', 'sales_performance', '1.0.0', 'VALIDATED',
   'یک شاخص خروجی و یک شاخص ورودی.',
   'شاخص ورودی به‌درستی نماینده تلاش/منابع صرف‌شده است.',
   'کیفیت فروش یا رضایت مشتری را نمی‌سنجد.'),
  ('naive_forecast_v1', 'پیش‌بینی ساده', 'Naive Forecast', 'forecasting', '1.0.0', 'VALIDATED',
   'حداقل یک دوره داده تاریخی.',
   'روند آینده مشابه آخرین دوره مشاهده‌شده است.',
   'هیچ روند یا فصلی بودنی را لحاظ نمی‌کند.'),
  ('moving_average_forecast_v1', 'میانگین متحرک ساده', 'Moving Average', 'forecasting', '1.0.0', 'VALIDATED',
   'داده تاریخی به تعداد حداقل برابر طول پنجره.',
   'همه دوره‌های داخل پنجره اهمیت یکسانی دارند.',
   'به تغییرات ناگهانی اخیر دیر واکنش نشان می‌دهد.'),
  ('weighted_moving_average_forecast_v1', 'میانگین متحرک وزنی', 'Weighted Moving Average', 'forecasting', '1.0.0', 'VALIDATED',
   'داده تاریخی و مجموعه وزن‌ها (مجموع = ۱).',
   'وزن‌ها بر پایه قضاوت تجاری معتبر تعیین شده‌اند.',
   'انتخاب وزن‌ها ذهنی است و می‌تواند نتیجه را جهت‌دار کند.'),
  ('exponential_smoothing_forecast_v1', 'هموارسازی نمایی', 'Exponential Smoothing', 'forecasting', '1.0.0', 'CANDIDATE',
   'حداقل دو دوره داده تاریخی و ضریب هموارسازی (alpha).',
   'ضریب alpha به‌درستی سرعت واکنش به تغییرات اخیر را نشان می‌دهد.',
   'روند یا فصلی بودن را به‌طور صریح مدل نمی‌کند.')
ON CONFLICT (code) DO NOTHING;

-- هویت و RBAC حداقلی (بخش ۹)
CREATE TABLE IF NOT EXISTS roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    code VARCHAR(64) NOT NULL,
    name_fa VARCHAR(128) NOT NULL,
    permission_codes JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(128) NOT NULL,
    email VARCHAR(256) NOT NULL,
    hashed_password VARCHAR(256) NOT NULL,
    display_name_fa VARCHAR(128) NOT NULL,
    role_id UUID REFERENCES roles(id),
    is_active BOOLEAN NOT NULL DEFAULT true,
    failed_login_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_tenant ON users (tenant_id);

-- Row-Level Security (RLS) — دفاع دوم پس از فیلتر tenant_id در لایه برنامه (بخش ۹/۱۱/۴۲).
-- app.core.database.get_session قبل از هر کوئری، app.current_tenant_id را برای این جلسه
-- تنظیم می‌کند؛ اگر برنامه به هر دلیلی فیلتر tenant_id را در یک کوئری فراموش کند، خود
-- Postgres مانع دیدن/نوشتن رکوردهای مستأجر دیگر می‌شود.
DO $$
DECLARE
    t TEXT;
BEGIN
    FOREACH t IN ARRAY ARRAY[
        'problems', 'actions', 'learning_candidates', 'sources', 'claims',
        'formula_registry_entries', 'audit_events', 'roles', 'users'
    ]
    LOOP
        EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
        EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
        EXECUTE format(
            'CREATE POLICY tenant_isolation_%1$s ON %1$s
                USING (tenant_id = current_setting(''app.current_tenant_id'', true))
                WITH CHECK (tenant_id = current_setting(''app.current_tenant_id'', true))',
            t
        );
    END LOOP;
END $$;
